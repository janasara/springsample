import ActionTypes from '../constants/actionTypes';


export default function notes(state = [], action) {
  switch (action.type) {
    
    case ActionTypes.LOAD_NOTES_SUCCESS:
            return action.notes; 
    
    case ActionTypes.CREATE_NOTE_SUCCESS:

      return [
                ...state,
                Object.assign({}, action.note)
            ];
   
    case ActionTypes.UPDATE_NOTE_SUCCESS:

            return [
                ...state.filter(note => note._id !== action.note._id),
                Object.assign({}, action.note)
            ];    

    case ActionTypes.DELETE_NOTE_SUCCESS:

            return [
                ...state.filter(note => note._id !== action.noteId)
            ];                

    default:
      return state;
  }
}
