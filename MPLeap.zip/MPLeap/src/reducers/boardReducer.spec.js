import expect from 'expect';
import boardReducer from './boardReducer';
import * as actions from '../actions/boardActions';

describe('Board Reducer', () => {
  it('should add board when passed CREATE_BOARD_SUCCESS', () => {
    // arrange
    const initialState = [
      {title: 'Leap Events'},
      {title: 'Hackathon'}
    ];

    const newBoard= {title: 'EVT'};

    const action = actions.createBoardSuccess(newBoard);

    //act
    const newState = boardReducer(initialState, action);

    //assert
    expect(newState.length).toEqual(3);
    expect(newState[0].title).toEqual('Leap Events');
    expect(newState[1].title).toEqual('Hackathon');
    expect(newState[2].title).toEqual('EVT');
  });

  it('should update board when passed UPDATE_BOARD_SUCCESS', () => {
    // arrange
    const initialState = [
      {_id: 'Leap-Events', title: 'Leap Events'},
      {_id: 'Hackathon', title: 'Hackathon'},
      {_id: 'EVT', title: 'EVT'}
    ];

    const board = {_id: 'Hackathon', title: 'New Hackathon'};
    const action = actions.updateBoardSuccess(board);

    // act
    const newState = boardReducer(initialState, action);
    const updatedBoard = newState.find(a => a._id == board._id);
    const untouchedBoard = newState.find(a => a._id == 'EVT');

    // assert
    expect(updatedBoard.title).toEqual('New Hackathon');
    expect(untouchedBoard.title).toEqual('EVT');
    expect(newState.length).toEqual(3);
  });
});