import React from 'react';
import { Link} from 'react-router';
const Header = () => {
  return (
    <div>
    {/*<nav>
      <IndexLink to="/" activeClassName="active">Home</IndexLink>
      {" | "}
      <Link to="/boards" activeClassName="active">Boards</Link>     
    </nav>
    <br></br>
    
    */}
    
    <h3><Link to="/boards" activeClassName="active"><p className="melement" >Kanban Board</p></Link></h3>
    </div>

    
  );
};

export default Header;