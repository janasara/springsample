import React from 'react';


class HomePage extends React.Component {
  render() {
    return (
      <div >
   
        <p>Dashboard</p>

      </div>
    );
  }
}

export default HomePage;
