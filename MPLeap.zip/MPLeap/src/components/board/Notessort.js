import React from 'react';
import {connect} from 'react-redux';
import {Link} from 'react-router';
//import {SortableContainer, SortableElement, arrayMove} from 'react-sortable-hoc';
import {SortableContainer, SortableElement} from 'react-sortable-hoc';

  
const SortableItem = SortableElement(({value}) => <div>{value}</div>);
const SortableList = SortableContainer(({items}) => {
    return (
        <div>
            {items.map((value, index) =>
                <SortableItem key={`item-${index}`} index={index} value={value} />
            )}            
            
        </div>
    );
});

class Notes extends React.Component {
   /*
    
    onSortEnd = ({oldIndex, newIndex}) => {debugger;

        let notes = arrayMove(this.props.notes, oldIndex, newIndex)

           
        
        
    };
    */

 render() {    
  
    
   let items=this.getLaneNotes();
    return (
        <SortableList  items={items}  />        
    );
      
  }
getLaneNotes(){
       return this.props.notes.map(note =>{
             return(  <div className="nlanenote" key={note._id}>
                        <Link to={'/note/' +note.bid +"/"+note._id}>{note.task}</Link>
                    </div>
              );
            });
    }

}
Notes.propTypes = {
  notes: React.PropTypes.object.isRequired   
};

export default connect()(Notes);

