import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as boardActions from '../../actions/boardActions';
import Lanes from './Lanes';

class ManageBoardPage extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.state = {
      board: Object.assign({}, props.board),
      errors: {},
      saving: false
    };

    this.updateBoardState = this.updateBoardState.bind(this);
    //this.saveBoard = this.saveBoard.bind(this);
    this.redirectToAddNotePage = this.redirectToAddNotePage.bind(this);
    this.redirect=this.redirect.bind(this);

  }

  componentWillReceiveProps(nextProps) {
    if (this.props.board._id != nextProps.board._id) {
      // Necessary to populate form when existing board is loaded directly.
      this.setState({ board: Object.assign({}, nextProps.board) });
    }
  }

  updateBoardState(event) {
    const field = event.target.name;
    let board = this.state.board;
    board[field] = event.target.value;
    return this.setState({ board: board });
  }

  boardFormIsValid() {
    let formIsValid = true;
    let errors = {};

    if (this.state.board.title.length < 5) {
      errors.title = 'Title must be at least 5 characters.';
      formIsValid = false;
    }

    this.setState({ errors: errors });
    return formIsValid;
  }
/*

  saveBoard(event) {
    event.preventDefault();

    if (!this.boardFormIsValid()) {
      return;
    }

    this.setState({ saving: true });

    this.props.actions.saveBoard(this.state.board)
      .then(() => this.redirect())
      .catch(error => {
        throw (error);
        this.setState({ saving: false });
      });
  }
*/
  redirect() {
    this.setState({ saving: false });

    this.context.router.push('/boards');
  }

  redirectToAddNotePage() {
    this.context.router.push('/note/' + this.state.board._id);
  }
  
  render() {

    return (
      <div className="bcontainer">
         <div className="form-header"><label> {this.state.board.title} </label></div>
         <div>
            <input type="button" value="Add Task" className="btn btn-primary btn-xs  bbtn" onClick={this.redirectToAddNotePage} />
            <input type="button" value="Back" className="btn btn-primary btn-xs  bbtn" onClick={this.redirect} />

        </div>
        <Lanes lanes={this.state.board.lanes} />

      </div>
    );
  }
}

ManageBoardPage.propTypes = {
  board: PropTypes.object.isRequired,

  actions: PropTypes.object.isRequired
};

//Pull in the React Router context so router is available on this.context.router.
ManageBoardPage.contextTypes = {
  router: PropTypes.object
};

function getBoardById(boards, id) {
  const board = boards.filter(board => board._id == id);
  if (board) return board[0]; //since filter returns an array, have to grab the first.
  return null;
}

function mapStateToProps(state, ownProps) {
  const boardId = ownProps.params.id; // from the path `/board/:id`

  let board = { _id: '', title: '',  lanes: [] };

  if (boardId && state.boards.length > 0) {
    board = getBoardById(state.boards, boardId);
  }

  return {
    board: board

  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(boardActions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(ManageBoardPage);
