import React from 'react';


const RefList = ({noterefs,onEdit}) => { 
  return (
            <div>
                {noterefs.map(noteref =>
                    <div className="telement" key={noteref.id}> 
                        <div className="telementn"><a href={noteref.link} target="_blank">{noteref.title}</a> </div>
                        <input type="button" id={noteref.id} className="btn btn-link" value="Edit" onClick={onEdit} />
                    </div>  
                    
                )}
             </div>

     );
};

RefList.propTypes = {
  noterefs: React.PropTypes.object.isRequired,
  onEdit: React.PropTypes.func.isRequired
 
  
};

export default RefList;
