import React from 'react';


const LaneList = ({boardlanes,onEdit}) => { 
  return (
                 <div >
            
                {boardlanes.map(boardlane =>
                    <div className="telement"  key={boardlane.id}>
                        <div className="telementn"> {boardlane.name} </div>
                        <input type="button" id={boardlane.id} className="btn btn-link telemente" value="Edit" onClick={onEdit} />
                     </div>   
                    
                )}
            </div>
  );
};

LaneList.propTypes = {
  boardlanes: React.PropTypes.array.isRequired,
  onEdit: React.PropTypes.func.isRequired
 
  
};

export default LaneList;
