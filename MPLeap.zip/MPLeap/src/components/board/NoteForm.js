import React from 'react';
import TextInput from '../common/TextInput';
import SelectInput from '../common/SelectInput';
import Datepicker from 'react-bootstrap-date-picker';

const NoteForm = ({note, onChange,onEChange, allLanes, errors}) => {

  return (
    <form>
      
      <TextInput
        name="task"
        label="Task "
        value={note.task}
        onChange={onChange}
        error={errors.task} />
      <SelectInput
        name="lid"
        label="Lane"
        value={note.lid}
        defaultOption="Select Lane"
        options={allLanes}
        onChange={onChange} error={errors.laneid} />
      <TextInput
        name="desc"
        label="Description  "
        value={note.desc}
        onChange={onChange}
        error={errors.desc} />
       <div className="telement">
        <label className="telementl">Event Date</label>
       <div className="telementn telementdt"> <Datepicker id="event-date" name="edate" value={note.edate} onChange={onEChange}  /> </div>     
       </div>      

    </form>
  );
};

NoteForm.propTypes = {
  note: React.PropTypes.object.isRequired,
  onChange: React.PropTypes.func.isRequired,
  onEChange:React.PropTypes.func.isRequired,
  errors: React.PropTypes.object,
  allLanes: React.PropTypes.array
};

export default NoteForm;
