import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as noteActions from '../../actions/noteActions';
import NoteForm from './NoteForm';
import * as boardActions from '../../actions/boardActions';
import RefList from './RefList';
import RefForm from './RefForm';
import toastr from 'toastr';

//import Progressbar from 'simple-react-progress-bar';

class ManageNotePage extends React.Component {
  constructor(props, context) {
    super(props, context);
    this.state = {

      note: Object.assign({}, props.note),
      nrefer: props.nrefer,
      boardtitle: props.boardtitle,
      boardid: props.boardid,
      errors: {},
      saving: false,
      board: props.board,
      elaneid: props.note.lid,
      showref: true,
      notes:props.notes,
      startSaving:false,
      endSaving:false,
      deleteEnable: props.deleteEnable

    };
    this.updateNoteState = this.updateNoteState.bind(this);
    this.saveNote = this.saveNote.bind(this);
    this.backManageBoard = this.backManageBoard.bind(this);
    this.AddrefSection = this.AddrefSection.bind(this);
    this.RemoverefSection = this.RemoverefSection.bind(this);
    this.saveRef = this.saveRef.bind(this);
    this.updateRefState = this.updateRefState.bind(this);
    this.cancelRef = this.cancelRef.bind(this);
    this.noteRefEdit = this.noteRefEdit.bind(this);
    this.updateNoteEState=this.updateNoteEState.bind(this);
    this.deleteNote=this.deleteNote.bind(this);
   

  }
  
  startSaving(){
    this.setState({startSaving:true});
  }
  endSaving(){
    this.setState({endSaving:true});
  }
  resetSaving(){
    this.setState({startSaving:false, endSaving:false});
  }

  updateNoteState(event) { 
    const field = event.target.name;
    let note = this.state.note;
    note[field] = event.target.value;
    return this.setState({ note: note });
  }
  
  updateNoteEState(event) {    
    let note = this.state.note;
    note["edate"] = event;
    return this.setState({ note: note });
  }

  updateRefState(event) {
    const field = event.target.name;
    let nrefer = this.state.nrefer;
    nrefer[field] = event.target.value;
    return this.setState({ nrefer: nrefer });
  }

  noteFormIsValid() {
    let formIsValid = true;
    let errors = {};

    if (this.state.note.task.length < 3) {
      errors.task = 'Task must be at least 3 characters.';
      formIsValid = false;
    }
    if (this.state.note.task.length > 50) {
      errors.task = 'Task must be not more than 50 characters.';
      formIsValid = false;
    }


    if (this.state.note.task.length>0) {
      const notes= this.state.notes;
      const taskid=this.replaceAll(this.state.note.task, ' ', '-');
      const taskIndex = notes.findIndex(a => a._id == taskid);
      if ((taskIndex >=0) && this.state.note._id.length == 0){
        errors.task = 'Task allready exists.';
        formIsValid = false;
      }
    }
    
    if (this.state.note.lid.length == 0) {
      errors.laneid = 'Select the lane for task';
      formIsValid = false;
    }

    this.setState({ errors: errors });
    return formIsValid;
  }

  refFormIsValid() {
    let rformIsValid = true;
    let errors = {};

    if (this.state.nrefer.title.length < 3) {
      errors.reftitle = 'Reference title must be at least 3 characters.';
      rformIsValid = false;
    }
    if (this.state.nrefer.title.length > 50) {
      errors.reftitle = 'Reference title must not be more than 50 characters.';
      rformIsValid = false;
    }
    this.setState({ errors: errors });
    return rformIsValid;
  }

  replaceAll(str, find, replace) {
    return str.replace(new RegExp(find, 'g'), replace);
  }
  
  ModifyBoardWithDeleteNote(board, elid) {
    if (elid.length > 0) {  
      const elaneindex = board.lanes.findIndex(a => a.id == elid);
      let elane = board.lanes[elaneindex];
      const index = elane.notes.indexOf(this.state.note._id);
      elane = Object.assign({}, elane, {
        notes: elane.notes.length > 1 ? elane.notes.slice(0, index).concat(
          elane.notes.slice(index + 1)) : []
      });
      board.lanes[elaneindex] = elane;
      this.setState({ board: board });

      return [this.state.board];

    }
  }


  ModifyBoardWithNote(board, elid) { 


    if (elid.length > 0 && elid !== this.state.note.lid) {
      const elaneindex = board.lanes.findIndex(a => a.id == elid);

      let elane = board.lanes[elaneindex];
      const index = elane.notes.indexOf(this.state.note._id);
      elane = Object.assign({}, elane, {
        notes: elane.notes.length > 1 ? elane.notes.slice(0, index).concat(
          elane.notes.slice(index + 1)) : []
      });


      board.lanes[elaneindex] = elane;

    }
    const laneindex = board.lanes.findIndex(a => a.id == this.state.note.lid);

    let lanel = board.lanes[laneindex];

    

    if (this.state.note._id.length > 0) {
      const nodeIndex=lanel.notes.indexOf(this.state.note._id);
      if (nodeIndex < 0){
          lanel = Object.assign({}, lanel, {
            notes: [...lanel.notes, this.state.note._id]
          });
      }
    } else {
      lanel = Object.assign({}, lanel, {
        notes: [...lanel.notes, this.replaceAll(this.state.note.task, ' ', '-')]
      });

    }


    board.lanes[laneindex] = lanel;

    //     let lanes= [ ...board.lanes.filter(lane => lane._id !== lanel._id),
    //   Object.assign({}, lanel)];            

    this.setState({ board: board });

    return [this.state.board];
  }

  saveNote(event) {
    event.preventDefault();

    if (!this.noteFormIsValid()) {
      return;
    }

    this.setState({ saving: true });
    this.startSaving();
    let note = this.state.note;
    note["bid"] = this.state.boardid;
    this.setState({ note: note });
   
    this.props.actions.saveNote(this.state.note)
      .then(this.props.actions.saveBoard(this.ModifyBoardWithNote(this.state.board, this.state.elaneid)[0]))
      .then(() => this.redirect())
      .catch(error => {
        toastr.error(error);
        this.setState({ saving: false });
        this.endSaving();
        
      });
  }

  deleteNote(event) {
    event.preventDefault();
    if ((this.state.note._id).length==0){
      return;
    }
    this.props.actions.deleteNote(this.state.note._id)
      .then(this.props.actions.saveBoard(this.ModifyBoardWithDeleteNote(this.state.board, this.state.elaneid)[0]))
      .then(() => this.redirect())
      .catch(error => {
        toastr.error(error);
        
      });
  }

  saveRef(event) {
   
    event.preventDefault();
    
    if ((!this.noteFormIsValid()) || (!this.refFormIsValid())) {
      return;
    }


    let nrefer = this.state.nrefer;
    let note = this.state.note;
    if ((nrefer.id.length) == 0) {
      nrefer["id"] = this.replaceAll(nrefer.title, ' ', '-');
      this.setState({ nrefer: nrefer });
      const lnrefer = this.state.nrefer;
      const lnote = Object.assign({}, note, {
        rlinks: [...note.rlinks, lnrefer]
      });
      note["rlinks"] = lnote.rlinks;
    }
    let data = { id: '', title: '', link: '' };
    this.setState({ nrefer: data });

    this.setState({ note: note });
    this.props.actions.saveNote(this.state.note)
      .then(() => this.RemoverefSection(true))
      .catch(error => {
         toastr.error(error);
      });


  }

  cancelRef() {
    let data = { id: '', title: '', link: '' };
    let errors = {};
    this.setState({ errors: errors });
    this.setState({ nrefer: data });
    this.RemoverefSection(false);


  }

  redirect() {
    this.setState({ saving: false });
    this.endSaving();
    toastr.success('Task changes saved');
    this.context.router.push('/board/' + this.state.boardid);
  }

  backManageBoard() {

    this.context.router.push('/board/' + this.state.boardid);
  }
  RemoverefSection(fromSaveRef) {
    this.setState({ showref: true });
    if (fromSaveRef){ toastr.success('Task Reference saved');}
    if ((this.state.note._id).length > 0) {
      this.context.router.push('/note/' + this.state.note.bid + "/" + this.state.note._id);
    } else {
      this.context.router.push('/note/' + this.state.boardid);
    }


  }

  AddrefSection() {
    this.setState({ showref: false });
   
    if ((this.state.note._id).length > 0) {
      this.context.router.push('/note/' + this.state.note.bid + "/" + this.state.note._id);
    } else {
      this.context.router.push('/note/' + this.state.boardid);
    }
  }

  noteRefEdit(event) {
    event.preventDefault();
    const field = event.target.id;
    const nrefs = this.state.note.rlinks;
    const refindex = nrefs.findIndex(a => a.id == field);
    let lnrefer = nrefs[refindex];
    this.setState({ nrefer: lnrefer });

    this.AddrefSection();

  }


  render() {


    return (
      <div className="bcontainer">
         <div className="form-header"><label> {this.state.board.title} </label></div>
        {
         // <Progressbar completed={this.state.endSaving} loading={this.state.startSaving} resetLoading={this.resetSaving}/>
         //
        }
        

       
       <input type="button" value="Back" className="btn btn-primary btn-xs  bbtn" onClick={this.backManageBoard} />
       

        <NoteForm
          allLanes={this.props.allLanes}
          onChange={this.updateNoteState}
          onEChange={this.updateNoteEState}          
          note={this.state.note}
          errors={this.state.errors}
          />
          <br></br>
        <div><label className="telementrl">  Reference Artifacts</label></div>
        <input type="button" value="Add New" className="btn btn-primary btn-xs  bbtn" onClick={this.AddrefSection} />
        <div hidden={this.state.showref}>

          <RefForm
            onChange={this.updateRefState}
            nrefer={this.state.nrefer}
            errors={this.state.errors}
            onSave={this.saveRef}
            onCancel={this.cancelRef}
            />

        </div>

        <br></br>
        <RefList

          noterefs={this.state.note.rlinks}
          onEdit={this.noteRefEdit}

          />

        <div className=" telement">
      
          <input
            type="submit"
            disabled={this.state.saving}
            value={this.state.saving ? 'Saving...' : 'Save'}
            className="btn btn-primary btn-xs  bbtn"
            onClick={this.saveNote} /> &nbsp; &nbsp;
         
 
          <input type="button"
            value="Delete"  
            disabled={this.state.deleteEnable}
            className="btn btn-primary btn-xs  bbtn"
            onClick={this.deleteNote} />
        </div>


      </div>
    );
  }
}

ManageNotePage.propTypes = {
  note: PropTypes.object.isRequired,
  actions: PropTypes.object.isRequired,
  lanes: PropTypes.array.isRequired,
  nrefer: PropTypes.object.isRequired,
  board:PropTypes.object.isRequired,
  boardtitle:PropTypes.string.isRequired,
  boardid:PropTypes.string.isRequired,
  notes: PropTypes.object.isRequired,
  deleteEnable:PropTypes.bool.isRequired,
  allLanes: PropTypes.object.isRequired
};


//Pull in the React Router context so router is available on this.context.router.
ManageNotePage.contextTypes = {
  router: PropTypes.object
};

function getNoteById(notes, id) {
  const note = notes.filter(note => note._id == id);
  if (note) return note[0]; //since filter returns an array, have to grab the first.
  return null;
}

function lanesFormattedForDropdown(lanes) {
  return lanes.map(lane => {
    return {
      value: lane.id,
      text: lane.name
    };
  });
}

function mapStateToProps(state, ownProps) {
  const boardId = ownProps.params.bid;
  const board = state.boards.filter(board => board._id == boardId)[0];
  const boardTitle = board.title;
  const boardLanes = board.lanes;
  const notes = state.notes;
  const noteId = ownProps.params.id; // from the path `/board/:id`

  let note = { _id: '', task: '', desc: '', edate: '2017-02-07T12:00:00.000Z', rlinks: [],  lid: '', bid: '' };
  let nrefer = { id: '', title: '', link: '' };
  let deleteEnable=true;

  if (noteId && state.notes.length > 0) {
    note = getNoteById(state.notes, noteId);
    deleteEnable=false;
  }

  return {
    note: note,
    nrefer: nrefer,
    boardtitle: boardTitle,
    boardid: boardId,
    allLanes: lanesFormattedForDropdown(boardLanes),
    board: board,
    notes:notes,
    deleteEnable:deleteEnable


  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({ ...noteActions, ...boardActions }, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(ManageNotePage);
