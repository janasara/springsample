import expect from 'expect';
import React from 'react';
import {shallow} from 'enzyme';

import LaneForm from './LaneForm';

function setup() {
  const props = {
    lane: {},  
    errors: {},
    onSave: () => {},
    onChange: () => {},
    onCancel:()=>{}
  };

  return shallow(<LaneForm {...props} />);
}

describe('Laneform Test',()=>{  
    it('renders form ', () => {
    const wrapper = setup();
    expect(wrapper.find('form').length).toBe(1);
   
  });

});