import React from 'react';
import Lane from './Lane';

const Lanes = ({lanes}) => {
  return (
    <div className="lanes">{lanes.map((lane) =>
      <Lane className="laneflex" key={lane._id} lane={lane} />
    )}</div>
  );
};

Lanes.propTypes = {
  lanes: React.PropTypes.object.isRequired   
};

export default Lanes;

