import React from 'react';
import TextInput from '../common/TextInput';


const RefForm = ({nrefer, onChange, errors, onSave, onCancel}) => {

  return (
    <form>
        <div>
          <TextInput
            name="title"
            label="Ref Title "
            value={nrefer.title}
            onChange={onChange}
            error={errors.reftitle}
            />


          <TextInput
            name="link"
            label="Ref Link "
            value={nrefer.link}
            onChange={onChange}
            error={errors.reflink}
            />
            <input
            type="submit"
            value="Save"
            className="btn btn-primary btn-xs  bbtn"
            onClick={onSave} /> 
            
            <input
            type="button"
            value="Cancel"
            className="btn btn-primary btn-xs  bbtn"
            onClick={onCancel} />
            

        </div>


    
    </form>
  );
};

RefForm.propTypes = {
  nrefer: React.PropTypes.object.isRequired,
  onChange: React.PropTypes.func.isRequired,
  onCancel: React.PropTypes.func.isRequired,
  onSave: React.PropTypes.func.isRequired,
  errors: React.PropTypes.object  
};

export default RefForm;