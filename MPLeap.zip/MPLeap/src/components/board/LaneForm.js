import React from 'react';
import TextInput from '../common/TextInput';


const LaneForm = ({lane, onChange, errors, onSave, onCancel}) => {

  return (
    <form>
        <div >
          <TextInput
            name="name"
            label="Name"
            value={lane.name}
            onChange={onChange}
            error={errors.name}
            />
            <div>
            <input
            type="submit"
            value="Save"
            className="btn btn-primary btn-xs  bbtn"
            onClick={onSave} /> &nbsp; &nbsp;
            
            <input
            type="button"
            value="Cancel"
            className="btn btn-primary btn-xs  bbtn"
            onClick={onCancel} />
            
            </div>
        </div>


    
    </form>
  );
};

LaneForm.propTypes = {
  lane: React.PropTypes.object.isRequired,
  onChange: React.PropTypes.func.isRequired,
  onCancel: React.PropTypes.func.isRequired,
  onSave: React.PropTypes.func.isRequired,
  errors: React.PropTypes.object  
};

export default LaneForm;