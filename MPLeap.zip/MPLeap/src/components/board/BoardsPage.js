import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as boardActions from '../../actions/boardActions';
import BoardList from './BoardList';


class BoardsPage extends React.Component {

  constructor(props, context) {
    super(props, context);
   
   this.AddNewBoard=this.AddNewBoard.bind(this);

  }


AddNewBoard(){
this.context.router.push('/boardf');

}
 

  render() {
    const {boards} = this.props;
    return (
      
         <div className="bcontainer" >
            <div className="form-header" >   
               <label className="lane-name"> Boards</label>
            </div> 
        
        <input type="button" value="New Board" className="btn btn-primary btn-xs  bbtn" onClick={this.AddNewBoard} />
        
        <BoardList boards={boards} />
      </div>
    );
  }

}

BoardsPage.propTypes = {
  boards: PropTypes.array.isRequired,
  actions: PropTypes.object.isRequired
};
//Pull in the React Router context so router is available on this.context.router.
BoardsPage.contextTypes = {
  router: PropTypes.object
};

function mapStateToProps(state) {
  return {
    boards: state.boards
  };

}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(boardActions, dispatch)
  };
}
export default connect(mapStateToProps, mapDispatchToProps)(BoardsPage);