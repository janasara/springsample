import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as boardActions from '../../actions/boardActions';
import TextInput from '../common/TextInput';
import LaneList from './LaneList';
import LaneForm from './LaneForm';
import toastr from 'toastr';

export class BoardForm extends React.Component {
    constructor(props, context) {
        super(props, context);

        this.state = {
            board:  props.board,
            lane: props.lane,
            errors: {},
            saving: false,
            showlane: true,
            deleteEnable: props.deleteEnable
        };

        this.updateBoardState = this.updateBoardState.bind(this);
        this.addLaneSection=this.addLaneSection.bind(this);
        this.removeLaneSection=this.removeLaneSection.bind(this);
        this.updateLaneState=this.updateLaneState.bind(this);
        this.addLaneSection=this.addLaneSection.bind(this);
        this.saveBoard=this.saveBoard.bind(this);
        this.saveLane=this.saveLane.bind(this);
        this.cancelLane=this.cancelLane.bind(this);
        this.boardlaneEdit=this.boardlaneEdit.bind(this);
        this.deleteBoard=this.deleteBoard.bind(this);
        this.backBoards=this.backBoards.bind(this);

    }

   updateBoardState(event) {
        const field = event.target.name;
        let board = this.state.board;
        board[field] = event.target.value;
        return this.setState({ board: board });
    }
    
  addLaneSection() {
    this.setState({ showlane: false });
   
    if ((this.state.board._id).length > 0) {
      this.context.router.push('/boardf/' + this.state.board._id);
    } else {
      this.context.router.push('/boardf' );
    }
  }
  
  removeLaneSection() {
    this.setState({ showlane: true });
   
    if ((this.state.board._id).length > 0) {
      this.context.router.push('/boardf/' + this.state.board._id);
    } else {
      this.context.router.push('/boardf' );
    }
  }

  updateLaneState(event) {
    const field = event.target.name;
    let lane = this.state.lane;
    lane[field] = event.target.value;
    return this.setState({ lane: lane });
  }
  
  cancelLane() {
    let data = { id: '', name: '', notes:[] };
    let errors = {};
    this.setState({ errors: errors });
    this.setState({ lane: data });
    this.removeLaneSection();
  }
   
 boardFormIsValid() {
    let formIsValid = true;
    let errors = {};

    if (this.state.board.title.length < 3) {
      errors.title = 'Board title be at least 3 characters.';
      formIsValid = false;
      this.setState({ errors: errors });
      return formIsValid;
    }
    if (this.state.board.title.length > 50) {
      errors.title = 'Board title not be more than 50 characters.';
      formIsValid = false;
      this.setState({ errors: errors });
      return formIsValid;
    }


    if (this.state.board.lanes.length==0) {
      let errMsg = 'Click Add Lanes. Minimum 1 lane is require for define a board.';
      toastr.error(errMsg);
      formIsValid = false;
    }
    this.setState({ errors: errors });
    return formIsValid;
  }
  
  laneFormIsValid() {
    let lformIsValid = true;
    let errors = {};

    if (this.state.lane.name.length < 3) {
      errors.name = 'Lane name must be at least 3 characters.';
      lformIsValid = false;
    }
    if (this.state.lane.name.length > 50) {
      errors.name = 'Lane name must not be more than 50 characters.';
      lformIsValid = false;
    }
    this.setState({ errors: errors });
    return lformIsValid;
  }
 
  replaceAll(str, find, replace) {
    return str.replace(new RegExp(find, 'g'), replace);
  }

  saveLane(event) {

   
    event.preventDefault();
    
    if (!this.laneFormIsValid()) {
      return;
    }


    let lane = this.state.lane;
    let board = this.state.board;
    if ((lane.id.length) == 0) {
      lane["id"] = this.replaceAll(lane.name, ' ', '-');
      this.setState({ lane: lane });
      const blane = this.state.lane;
      const lboard = Object.assign({}, board, {
        lanes: [...board.lanes,blane]
      });
      board["lanes"] = lboard.lanes;
    }
    
    let data = { id: '', name: '', notes:[] };
    this.setState({ lane: data });
    this.setState({ board: board });
    this.removeLaneSection();

  }
  redirect() {
    this.setState({ saving: false });
    
    toastr.success('Board changes saved');
    this.context.router.push('/boards');
  }
  
  backBoards(){
    this.context.router.push('/boards');
  }

  saveBoard(event) {
    event.preventDefault();

    if (!this.boardFormIsValid()) {
      return;
    }

    this.setState({ saving: true });


    this.props.actions.saveBoard(this.state.board)    
      .then(() => this.redirect())
      .catch(error => {
        toastr.error(error);
         this.setState({ saving: false });

        
      });
  }
   boardlaneEdit(event) {
    event.preventDefault();
    const field = event.target.id;
    const lanes = this.state.board.lanes;
    const laneindex = lanes.findIndex(a => a.id == field);
    let llane = lanes[laneindex];
    this.setState({ lane: llane });

    this.addLaneSection();

  }
  deleteBoard(event) {
    event.preventDefault();
    if ((this.state.board._id).length==0){
      return;
    }
    this.props.actions.deleteBoard(this.state.board._id)      
      .then(() => this.redirect())
      .catch(error => {
        toastr.error(error);        
      });
  }



    render() {

        return (
                <div className="bcontainer">
                    <div className="form-header"><label> {this.state.board.title?this.state.board.title:"New Board"} </label></div>
                <div>
                <input type="button" value="Back" className="btn btn-primary btn-xs  bbtn" onClick={this.backBoards} />
            
                </div>
                
            
                <TextInput
                    name="title"
                    label="Title "
                    value={this.state.board.title}
                    onChange={this.updateBoardState}
                    error={this.state.errors.title}
                    
                    />
                <div><label className="telementrl">Lanes</label></div>
                <input type="button" value="Add Lanes" className="btn btn-primary btn-xs  bbtn" onClick={this.addLaneSection} />
              
                <div hidden={this.state.showlane}> 
                    <LaneForm
                        onChange={this.updateLaneState}
                        lane={this.state.lane}
                        errors={this.state.errors}
                        onSave={this.saveLane}
                        onCancel={this.cancelLane}
                        />

                </div>

               
                <LaneList

                    boardlanes={this.state.board.lanes}
                    onEdit={this.boardlaneEdit}

                    />
                  
                <div className=" telement">

                    <input
                        name="brnBoard"
                        id="brnBoard"
                        type="submit"
                        disabled={this.state.saving}
                        value={this.state.saving ? 'Saving...' : 'Save'}
                        className="btn btn-primary btn-xs  bbtn"
                        onClick={this.saveBoard} />


                    <input type="button"
                        value="Delete"
                        disabled={this.state.deleteEnable}
                        className="btn btn-primary btn-xs  bbtn"
                        onClick={this.deleteBoard} />
                </div>           
              </div>      
    );
  }
}

BoardForm.propTypes = {
    board: PropTypes.object.isRequired,
    lane: PropTypes.object.isRequired,
    actions: PropTypes.object.isRequired,
    deleteEnable:PropTypes.bool.isRequired
};

function getBoardById(boards, id) {
  const board = boards.filter(board => board._id == id);
  if (board) return board[0]; //since filter returns an array, have to grab the first.
  return null;
}
//Pull in the React Router context so router is available on this.context.router.
BoardForm.contextTypes = {
  router: PropTypes.object
};

function mapStateToProps(state, ownProps) {
    const boardId = ownProps.params.id;
    let board = { _id: '', title: '', lanes: [] };
    let lane = { id: '', name: '', notes: [] };
    let deleteEnable=true;
    if (boardId && state.boards.length > 0) {
        board = getBoardById(state.boards, boardId);
    
        deleteEnable=false;
    }
    return {
        board: board,
        lane: lane,
        deleteEnable:deleteEnable
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(boardActions, dispatch)
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(BoardForm);