import React from 'react';
import expect from 'expect';
import {mount} from 'enzyme';
import {BoardForm} from './BoardForm';


describe ('Board Page Test', () => {
  it('sets error message when trying to save empty title', () => {
  
    const props = {
      
      actions: { saveBoard: () => { return Promise.resolve(); }},
      
      board: { _id: '', title: '', lanes: [] },
      lane :{ id: '', name: '', notes: [] },
      
      deleteEnable:false
    };
  
    const wrapper = mount(<BoardForm {...props}/>);
    
    const saveButton = wrapper.find("#brnBoard");
   
    expect(saveButton.prop('type')).toBe('submit');
    
    saveButton.simulate('click');
    expect(wrapper.state().errors.title).toBe('Board title be at least 3 characters.');
    

  });
});