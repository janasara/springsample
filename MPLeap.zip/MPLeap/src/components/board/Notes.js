import React from 'react';
import {connect} from 'react-redux';
import {Link} from 'react-router';

class Notes extends React.Component {
  render() {
    const {notes} = this.props;

    return (
            <div className="nlaneflex" >
                {notes.map(note =>
                    <div className="nlanenote" key={note._id}>
                        <Link to={'/note/' +note.bid +"/"+note._id}>{note.task}</Link>
                    </div>
                )}
             </div>   
    );
  }
}
Notes.propTypes = {
  notes: React.PropTypes.object.isRequired   
};

export default connect()(Notes);

