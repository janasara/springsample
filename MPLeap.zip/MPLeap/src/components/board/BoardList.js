import React, { PropTypes } from 'react';
import { Link } from 'react-router';

const BoardList = ({boards}) => {
    return ( 
      
                <div>
                {boards.map(board =>              

                    <div className="belement" key={board._id}>
                        <Link className="belementn" to={'/board/' + board._id}>{board.title}</Link>
                        <Link className="belemente" to={'/boardf/' + board._id}>Edit Config</Link>
                    </div>
              
                )}
                </div>
                
    );
};

BoardList.propTypes = {
    boards: PropTypes.array.isRequired
};

export default BoardList;