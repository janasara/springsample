import React , { PropTypes } from 'react';
import {compose} from 'redux';
import {connect} from 'react-redux';
import Notes from './Notes';
import * as noteActions from '../../actions/noteActions';


class Lane extends React.Component {
  render() {
    const {lane, laneNotes, ...props} = this.props;
  
    return (
      <div {...props}>
        <div className="lane-header" >   
        <label className="lane-name"> {lane.name}</label>
         </div>
          <Notes
          notes={laneNotes}
           />
      </div>
    );
  }

}

Lane.propTypes = {
  lane: PropTypes.object.isRequired,
  laneNotes: PropTypes.object.isRequired
};

export default compose(
  // If you want to memoize this (more performant),
  // use https://www.npmjs.com/package/reselect
  connect((state, props) => ({
    laneNotes: props.lane.notes.map(id => state.notes[
      state.notes.findIndex(note => note._id === id)
    ]).filter(note => note)
  }), {    
    ...noteActions
  }),

)(Lane);
