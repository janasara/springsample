import ActionTypes from '../constants/actionTypes';


import axios from 'axios';

export function loadBoardsSucess(boards) {
  return { type: ActionTypes.LOAD_BOARDS_SUCCESS, boards };

}

export function reorderBoardLane(notes) {
  return { type: ActionTypes.REORDER_BOARD_LANE, notes };

}

export function createBoardSuccess(board) {
  return { type: ActionTypes.CREATE_BOARD_SUCCESS, board };
}

export function updateBoardSuccess(board) {
  return { type: ActionTypes.UPDATE_BOARD_SUCCESS, board };
}

export function deleteBoardSuccess(boardId) {
  return { type: ActionTypes.DELETE_BOARD_SUCCESS, boardId };
}

export function loadBoards() {
  return function (dispatch) {
    return axiosCall().then(boards => {
      dispatch(loadBoardsSucess(boards));
    }).catch(error => {
      throw (error);
    });
  };
}

export function axiosCall(){ 
   return axios.get( ActionTypes.API_CALL+"boards").then(response => response.data);
}

export function saveBoard(board) {
 
  return function (dispatch) {
    if ((board._id).length>0 ){
        return axiosSaveBoard(board).then(board => {
          dispatch(updateBoardSuccess(board));            
        }).catch(error => {
          throw (error);
        });
      
    } else {
        return axiosSaveBoard(board).then(board => {
          dispatch(createBoardSuccess(board));            
        }).catch(error => {
          throw (error);
        });
    }  

  };
}

export function axiosSaveBoard(board){ 

 if ((board._id).length>0 ){

   return axios.put(ActionTypes.API_CALL+"board/"+board._id, board).then(() => board);

 } else {
   board._id=replaceAll(board.title, ' ', '-');
   return axios.post(ActionTypes.API_CALL+"board",board).then(() => board);
 }
}

function replaceAll(str, find, replace) {
  return str.replace(new RegExp(find, 'g'), replace);
}

export function deleteBoard(boardId) {
  return function (dispatch) {
    return  axiosDeleteBoard(boardId).then(boardId => {
      dispatch(deleteBoardSuccess(boardId));
    }).catch(error => {
      throw (error);
    });
  };
}

export function axiosDeleteBoard(boardId){ 
   return axios.delete(ActionTypes.API_CALL+"board/"+boardId).then(() => boardId);
}
