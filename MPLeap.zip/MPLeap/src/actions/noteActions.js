import ActionTypes from '../constants/actionTypes';
import axios from 'axios';


export function loadNotesSuccess(notes) {
  return { type: ActionTypes.LOAD_NOTES_SUCCESS, notes };

}

export function createNoteSuccess(note) {
  return { type: ActionTypes.CREATE_NOTE_SUCCESS, note };
}

export function updateNoteSuccess(note) {
  return { type: ActionTypes.UPDATE_NOTE_SUCCESS, note };
}

export function deleteNoteSuccess(noteId) {
  return { type: ActionTypes.DELETE_NOTE_SUCCESS, noteId };
}

export function loadNotes() {
  return function (dispatch) {
    return axiosCall().then(notes => {
      dispatch(loadNotesSuccess(notes));
    }).catch(error => {
      throw (error);
    });
  };
}

export function axiosCall(){ 
   return axios.get( ActionTypes.API_CALL+"notes").then(response => response.data);
}

export function saveNote(note) {
  return function (dispatch) {
    if ((note._id).length>0 ){
        return axiosSaveNote(note).then(note => {
          dispatch(updateNoteSuccess(note));            
        }).catch(error => {
          throw (error);
        });
      
    } else {
        return axiosSaveNote(note).then(note => {
          dispatch(createNoteSuccess(note));            
        }).catch(error => {
          throw (error);
        });
    }  
  };
}

export function axiosSaveNote(note){

 if ((note._id).length>0 ){

   return axios.put(ActionTypes.API_CALL+"note/"+note._id, note).then(() => note);

 } else {
   note._id=replaceAll(note.task, ' ', '-');
   return axios.post(ActionTypes.API_CALL+"note", note).then(() => note);
 }
}

function replaceAll(str, find, replace) {
  return str.replace(new RegExp(find, 'g'), replace);
}

export function deleteNote(noteId) {
  return function (dispatch) {
    return  axiosDeleteNote(noteId).then(noteId => {
      dispatch(deleteNoteSuccess(noteId));
    }).catch(error => {
      throw (error);
    });
  };
}

export function axiosDeleteNote(noteId){ 
   return axios.delete(ActionTypes.API_CALL+"note/"+noteId).then(() => noteId);
}

