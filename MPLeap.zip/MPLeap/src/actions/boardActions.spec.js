import expect from 'expect';
import * as boardActions from './boardActions';
import ActionTypes from '../constants/actionTypes';
/*
import thunk from 'redux-thunk';
import nock from 'nock';
import configureMockStore from 'redux-mock-store';
*/

describe('Board Actions', () => {
  describe('createBoardSuccess', () => {
    it('should create a CREATE_BOARD_SUCCESS action', () => {
      //arrange
      const board = {_id: 'Hackathon-Event', title: 'Hackathon Event'};
      const expectedAction = {
        type: ActionTypes.CREATE_BOARD_SUCCESS,
        board: board
      };

      //act
      const action = boardActions.createBoardSuccess(board);

      //assert
      expect(action).toEqual(expectedAction);
    });
  });
});

/*
const middleware = [thunk];
const mockStore = configureMockStore(middleware);

describe('Async Actions', () => {
  afterEach(() => {
    nock.cleanAll();
  });

  it('should create LOAD_BOARD_SUCCESS when loading boards', (done) => {
    // Here's an example call to nock.
     nock(ActionTypes.API_CALL)
      .get('boards')
     .reply(200, { body: { boards: [{ _id: 'Leap-Events', title: 'Leap Events'}] }});

    const expectedActions = [
       {type: ActionTypes.LOAD_BOARDS_SUCCESS, body: {boards: [{_id: 'Leap-Events', title: 'Leap Events'}]}}
    ];

    const store = mockStore({boards: []}, expectedActions, done);
    store.dispatch(boardActions.loadBoards()).then(() => {
      const actions = store.getActions();
      expect(actions[0].type).toEqual(ActionTypes.LOAD_BOARDS_SUCCESS);
      done();
    });
  });
  
});

*/