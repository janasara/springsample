import expect from 'expect';
import { createStore } from 'redux';
import rootReducer from '../reducers';
import * as boardActions from '../actions/boardActions';

describe('Store', function() {
  it('Should handle creating board', function() {
    // arrange
  const store = createStore(rootReducer,{boards:[]} );
    const board = {
      title: "Hackathon"
    };

    // act
    const action = boardActions.createBoardSuccess(board);
    store.dispatch(action);

    // assert
    const actual = store.getState().boards[0];
    const expected = {
      title: "Hackathon"
    };

    expect(actual).toEqual(expected);
  });
});
