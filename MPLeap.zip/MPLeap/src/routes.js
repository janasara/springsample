import React from 'react';
import { Route, IndexRoute } from 'react-router';
import App from './components/App';
import BoardsPage from './components/board/BoardsPage';
import ManageNotePage from './components/board/ManageNotePage';
import ManageBoardPage from './components/board/ManageBoardPage';
import BoardForm from './components/board/BoardForm';//eslint-disable-line import/no-named-as-default


export default (
  <Route path="/" component={App}>
    <IndexRoute component={BoardsPage} />
    <Route path="boards" component={BoardsPage} />
    <Route path="boardf" component={BoardForm} />
    <Route path="boardf/:id" component={BoardForm} />
    <Route path="board/:id" component={ManageBoardPage} />
    <Route path="note/:bid" component={ManageNotePage} />
    <Route path="note/:bid/:id" component={ManageNotePage} />
  </Route>
);