import { Router } from 'express';
import fs from 'fs';
import path from 'path';

const router = new Router();

// /mock/api/edeliveryv2
router.post('/', (req, res) => {

    // just send this dude back
    const mockDataFileName = './json/postSuccess.json';

    // send that file back
    const mockDataJson = fs.readFileSync(path.join(__dirname, mockDataFileName), 'utf8');

    res.setHeader('Content-Type', 'application/json');
    return res.send(mockDataJson);
});

router.get('/', (req, res) => {

    // just send this dude back
    const mockDataFileName = './json/statusEnrolled.json'; //1SD8MW52AV

    // send that file back
    const mockDataJson = fs.readFileSync(path.join(__dirname, mockDataFileName), 'utf8');

    res.setHeader('Content-Type', 'application/json');
    return res.send(mockDataJson);
});

export default router;
