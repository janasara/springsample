import express from 'express';
import jsonServer from 'json-server';

import actions from './actions.json';
import billing from './billing/direct-due-has-loan.json';
import edelivery from './edelivery.json';
import edeliveryv2 from './edeliveryv2';
import accounts from './accounts.json';
import features from './features.json';
import folders from './folders.json';
import footnote from './footnote.json';
import frsummary from './frsummary.json';
import message from './message.json';
import supporthours from './supporthours.json';
import terms from './terms.json';
import termsDocumentDelivery from './termsDocumentDelivery.json';
import transactions from './transactions.json';
import groups from './groups.json';
import groupAccounts from './group-accounts.json';
import nonGroupAccounts from './nongroup-accounts.json';

const PORT = process.env.PORT || 8090;
const app = express();
const db = {
    actions,
    accounts,
    billing,
    edelivery,
    features,
    folders,
    footnote,
    frsummary,
    message,
    supporthours,
    terms,
    termsDocumentDelivery,
    transactions,
    groups,
    groupAccounts,
    nonGroupAccounts
};

// don't actaully want to save anything here and json server doesn't handle responses of post operations super great
// build our routes for this by hand
app.use('/mock/api/edeliveryv2', edeliveryv2);

app.use(jsonServer.defaults());

app.use(jsonServer.rewriter({
    '/mock/api/field/client/:id': '/mock/api/frsummary',
    '/mock/api/accounts/client/:id?': '/mock/api/accounts',
    '/mock/api/networth/:id?': '/mock/api/networth',
    '/mock/api/profile/:id': '/mock/api/profile',
    '/mock/api/termsconditions/:termsType': '/mock/api/termsDocumentDelivery',
    '/mock/api/TermsAndConditions/getTermsJson': '/mock/api/terms',
    '/mock/api/v1/admin/supporthours/CustomerService': '/mock/api/supporthours',
    '/mock/api/business/groups/:id': '/mock/api/groups'
}));

app.use('/mock/api', jsonServer.router(db));


const httpServer = app.listen(PORT, () => {
    console.log(`Mock API on http://localhost:${PORT} [${app.settings.env}]`);
});

process.on('SIGTERM', () => {
    httpServer.close(() => {
        process.exit(0);
    });
});
