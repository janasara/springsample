import { Router } from 'express';
import IS_DEV from './../../utils/isDev';
import IS_PROD from './../../utils/isProd';

import premiumDueLarge from './../../mock/billing/premium/large-quarterly-due.json';
import premiumRecurring from './../../mock/billing/premium/recurring.json';
import premiumLoanDue from './../../mock/billing/premium/premium-loan-due.json';
import premiumPaid from './../../mock/billing/premium/premium-paid.json';
import loanDue from './../../mock/billing/loan/loan-in-window.json';
import loanOutWindow from './../../mock/billing/loan/loan-out-window.json';
import annuityDirect from './../../mock/billing/annuity/annuity-direct.json';
import annuityDirectScheduled from './../../mock/billing/annuity/annuityDirectScheduled.json';
import scheduledPayment from './../../mock/billing/premium/scheduled-payment.json';
import premiumAndShortageDueNow from './../../mock/billing/premium/premiumShortageDueNow.json';
import premiumLoanBasicDue from './../../mock/billing/premium/premiumLoanBasicDue.json';
import directShortageInWindow from './../../mock/billing/additionalPayments/direct-shortage-due.json';
import directDueMonthlyPastDue from './../../mock/billing/premium/directDueMonthlyPastDue.json';
import recurringShortageDue from './../../mock/billing/additionalPayments/recurringShortageDue.json';
import additionalDue from './../../mock/billing/additionalPayments/additionalDue.json';
import annuityRecurringAddlContribution from './../../mock/billing/annuity/annuityRecurringAddlContribution.json';
import annuityRecurring from './../../mock/billing/annuity/annuityRecurring.json';
import paidByDividend from './../../mock/billing/zeroDue/premium-paid-dividend.json';
import noISA from './../../mock/billing/noISA.json';
import notOnISA from './../../mock/billing/notOnISA.json';
import onlineIneligible from './../../mock/billing/onlineIneligible.json';
import hoCaseLock from './../../mock/billing/hoCaseLock.json';
import changePending from './../../mock/billing/changePending.json';
import { fetchBilling } from './../../models/billing';
// QA Specific Query Params
import NotAPayer_QA from './../../mock/billing/qa/NotAPayer_QA.json'; // eslint-disable-line
import PayerButNotOnIsa_QA from './../../mock/billing/qa/PayerButNotOnIsa_QA.json'; // eslint-disable-line
import ChangePending_QA from './../../mock/billing/qa/ChangePending_QA.json'; // eslint-disable-line
import HOCaseLock_QA from './../../mock/billing/qa/HOCaseLock_QA.json'; // eslint-disable-line
import OnlinePaymentIneligible_QA from './../../mock/billing/qa/OnlinePaymentIneligible_QA.json'; // eslint-disable-line
import PremiumDirectSplitPaymentPastDue_QA from './../../mock/billing/qa/PremiumDirectSplitPaymentPastDue_QA.json'; // eslint-disable-line
import DirectAdditionalPaymentDue_QA from './../../mock/billing/qa/DirectAdditionalPaymentDue_QA.json'; // eslint-disable-line
import RecurringAdditionalPaymentDue_QA from './../../mock/billing/qa/RecurringAdditionalPaymentDue_QA.json'; // eslint-disable-line
import AnnuityFrozen_QA from './../../mock/billing/qa/AnnuityFrozen_QA.json'; // eslint-disable-line
import PremiumFrozen_QA from './../../mock/billing/qa/PremiumFrozen_QA.json'; // eslint-disable-line
import PremiumPaidByDivAnd1035_QA from './../../mock/billing/qa/PremiumPaidByDivAnd1035_QA.json'; // eslint-disable-line
import PremiumPaidBy1035_QA from './../../mock/billing/qa/PremiumPaidBy1035_QA.json'; // eslint-disable-line
import LoanPaidOff_QA from './../../mock/billing/qa/LoanPaidOff_QA.json'; // eslint-disable-line
import LoanRecurring_QA from './../../mock/billing/qa/LoanRecurring_QA.json'; // eslint-disable-line
import LoanOnlyFrozen_QA from './../../mock/billing/qa/LoanOnlyFrozen_QA.json'; // eslint-disable-line
import LoanScheduledPayment_QA from './../../mock/billing/qa/LoanScheduledPayment_QA.json'; // eslint-disable-line
import PremiumPaid_QA from './../../mock/billing/qa/PremiumPaid_QA.json'; // eslint-disable-line
import PremiumPaidByDividend_QA from './../../mock/billing/qa/PremiumPaidByDividend_QA.json'; // eslint-disable-line
import ScheduledPayment_QA from './../../mock/billing/qa/ScheduledPayment_QA.json'; // eslint-disable-line
import PremiumDirectOutOfWindow_QA from './../../mock/billing/qa/PremiumDirectOutOfWindow_QA.json'; // eslint-disable-line
import PremiumDirectMonthlyPastDue_QA from './../../mock/billing/qa/PremiumDirectMonthlyPastDue_QA.json'; // eslint-disable-line
import DirectShortagePastDue_QA from './../../mock/billing/qa/DirectShortagePastDue_QA.json'; // eslint-disable-line
import DirectShortageDue_QA from './../../mock/billing/qa/DirectShortageDue_QA.json'; // eslint-disable-line
import PremiumDirectPastDue_QA from './../../mock/billing/qa/PremiumDirectPastDue_QA.json'; // eslint-disable-line
import PremiumDirectDue_QA from './../../mock/billing/qa/PremiumDirectDue_QA.json'; // eslint-disable-line
import AnnuityDirectScheduled_QA from './../../mock/billing/qa/AnnuityDirectScheduled_QA.json'; // eslint-disable-line
import AnnuityRecurringAddlContributionScheduled_QA from './../../mock/billing/qa/AnnuityRecurringAddlContributionScheduled_QA.json'; // eslint-disable-line
import AnnuityRecurringInOrOutOfWindow_QA from './../../mock/billing/qa/AnnuityRecurringInOrOutOfWindow_QA.json'; // eslint-disable-line
import AnnuityDirectInOrOutOfWindow_QA from './../../mock/billing/qa/AnnuityDirectInOrOutOfWindow_QA.json'; // eslint-disable-line
import LoanDue_QA from './../../mock/billing/qa/LoanDue_QA.json'; // eslint-disable-line
import LoanOutOfWindow_QA from './../../mock/billing/qa/LoanOutOfWindow_QA.json'; // eslint-disable-line
import NoISA_QA from './../../mock/billing/qa/NoISA_QA.json'; // eslint-disable-line
import PaymentAdditionalDue_QA from './../../mock/billing/qa/PaymentAdditionalDue_QA.json'; // eslint-disable-line
import PremiumRecurring_QA from './../../mock/billing/qa/PremiumRecurring_QA.json'; // eslint-disable-line
import RecurringShortageDue_QA from './../../mock/billing/qa/RecurringShortageDue_QA.json'; // eslint-disable-line

const router = Router();

router.get('/', (req, res, next) => {
    if (!IS_PROD && !IS_DEV && req.query.isa) {
    // if (IS_DEV && req.query.isa) {
        if (req.query.isa) {
            switch (req.query.isa) {
                case 'premiumDueLarge':
                case 'nancyneinrichnmc':
                    res.json(premiumDueLarge);
                    break;
                case 'premiumRecurring':
                case 'rosalindkinneynmc':
                    res.json(premiumRecurring);
                    break;
                case 'premiumLoanBasicDue':
                case 'chadcoltontinmc':
                    res.json(premiumLoanBasicDue);
                    break;
                case 'premiumLoanDue':
                case 'martinvillanuevanmc':
                    res.json(premiumLoanDue);
                    break;
                case 'premiumPaid':
                case 'marycampbellnmc':
                    res.json(premiumPaid);
                    break;
                case 'directShortageInWindow':
                    res.json(directShortageInWindow);
                    break;
                case 'premiumAndShortageDueNow':
                case 'brianfarrarnmc':
                    res.json(premiumAndShortageDueNow);
                    break;
                case 'recurringShortageDue':
                case 'anaboracchianmc':
                    res.json(recurringShortageDue);
                    break;
                case 'additionalDue':
                case 'johnrobinsonnmc':
                    res.json(additionalDue);
                    break;
                case 'directDueMonthlyPastDue':
                case 'lauradelgadonmc':
                    res.json(directDueMonthlyPastDue);
                    break;
                case 'scheduledPayment':
                    res.json(scheduledPayment);
                    break;
                case 'loanDue':
                case 'charlespeltzernmc':
                    res.json(loanDue);
                    break;
                case 'loanOutWindow':
                case 'garykleinrichertnmc':
                    res.json(loanOutWindow);
                    break;
                case 'annuityDirect':
                case 'allisonhsunmc':
                    res.json(annuityDirect);
                    break;
                case 'annuityDirectScheduled':
                    res.json(annuityDirectScheduled);
                    break;
                case 'annuityRecurring':
                case 'gwenpaventynmc':
                    res.json(annuityRecurring);
                    break;
                case 'annuityRecurringAddlContribution':
                    res.json(annuityRecurringAddlContribution);
                    break;
                case 'paidByDividend':
                    res.json(paidByDividend);
                    break;
                case 'onlineIneligible':
                    res.json(onlineIneligible);
                    break;
                case 'changePending':
                    res.json(changePending);
                    break;
                case 'hoCaseLock':
                    res.json(hoCaseLock);
                    break;
                case 'noISA':
                    res.json(noISA);
                    break;
                case 'notOnISA':
                    res.json(notOnISA);
                    break;
                case 'NotAPayer_QA' :
                    res.json(NotAPayer_QA);
                    break;
                case 'PayerButNotOnIsa_QA':
                    res.json(PayerButNotOnIsa_QA);
                    break;
                case 'ChangePending_QA':
                    res.json(ChangePending_QA);
                    break;
                case 'HOCaseLock_QA':
                    res.json(HOCaseLock_QA);
                    break;
                case 'OnlinePaymentIneligible_QA':
                    res.json(OnlinePaymentIneligible_QA);
                    break;
                case 'PremiumDirectSplitPaymentPastDue_QA':
                    res.json(PremiumDirectSplitPaymentPastDue_QA);
                    break;
                case 'DirectAdditionalPaymentDue_QA':
                    res.json(DirectAdditionalPaymentDue_QA);
                    break;
                case 'RecurringAdditionalPaymentDue_QA':
                    res.json(RecurringAdditionalPaymentDue_QA);
                    break;
                case 'AnnuityFrozen_QA':
                    res.json(AnnuityFrozen_QA);
                    break;
                case 'PremiumFrozen_QA':
                    res.json(PremiumFrozen_QA);
                    break;
                case 'PremiumPaidByDivAnd1035_QA':
                    res.json(PremiumPaidByDivAnd1035_QA);
                    break;
                case 'PremiumPaidBy1035_QA':
                    res.json(PremiumPaidBy1035_QA);
                    break;
                case 'LoanPaidOff_QA':
                    res.json(LoanPaidOff_QA);
                    break;
                case 'LoanRecurring_QA':
                    res.json(LoanRecurring_QA);
                    break;
                case 'LoanOnlyFrozen_QA':
                    res.json(LoanOnlyFrozen_QA);
                    break;
                case 'LoanScheduledPayment_QA':
                    res.json(LoanScheduledPayment_QA);
                    break;
                case 'PremiumPaid_QA':
                    res.json(PremiumPaid_QA);
                    break;
                case 'PremiumPaidByDividend_QA':
                    res.json(PremiumPaidByDividend_QA);
                    break;
                case 'ScheduledPayment_QA':
                    res.json(PremiumPaidByDividend_QA);
                    break;
                case 'PremiumDirectOutOfWindow_QA':
                    res.json(PremiumDirectOutOfWindow_QA);
                    break;
                case 'PremiumDirectMonthlyPastDue_QA':
                    res.json(PremiumDirectMonthlyPastDue_QA);
                    break;
                case 'DirectShortagePastDue_QA':
                    res.json(DirectShortagePastDue_QA);
                    break;
                case 'DirectShortageDue_QA':
                    res.json(DirectShortageDue_QA);
                    break;
                case 'PremiumDirectPastDue_QA':
                    res.json(PremiumDirectPastDue_QA);
                    break;
                case 'PremiumDirectDue_QA':
                    res.json(PremiumDirectDue_QA);
                    break;
                case 'AnnuityDirectScheduled_QA':
                    res.json(AnnuityDirectScheduled_QA);
                    break;
                case 'AnnuityRecurringAddlContributionScheduled_QA':
                    res.json(AnnuityRecurringAddlContributionScheduled_QA);
                    break;
                case 'AnnuityRecurringInOrOutOfWindow_QA':
                    res.json(AnnuityRecurringInOrOutOfWindow_QA);
                    break;
                case 'AnnuityDirectInOrOutOfWindow_QA':
                    res.json(AnnuityDirectInOrOutOfWindow_QA);
                    break;
                case 'LoanDue_QA':
                    res.json(LoanDue_QA);
                    break;
                case 'LoanOutOfWindow_QA':
                    res.json(LoanOutOfWindow_QA);
                    break;
                case 'NoISA_QA':
                    res.json(NoISA_QA);
                    break;
                case 'PaymentAdditionalDue_QA':
                    res.json(PaymentAdditionalDue_QA);
                    break;
                case 'PremiumRecurring_QA':
                    res.json(PremiumRecurring_QA);
                    break;
                case 'RecurringShortageDue_QA':
                    res.json(RecurringShortageDue_QA);
                    break;
                default :
                    res.json(noISA);
                    break;
            }
        }
    } else {
        fetchBilling(req)
            .then(data => res.json(data))
            .catch(err => next(err));
    }
});


export default router;
