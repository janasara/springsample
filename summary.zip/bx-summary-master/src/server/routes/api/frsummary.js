import { Router } from 'express';
import { fetchFrsummary } from './../../models/frsummary';

const router = Router();

router.get('/', (req, res, next) => {
    fetchFrsummary(req)
        .then(data => res.json(data))
        .catch(err => next(err));
});

export default router;
