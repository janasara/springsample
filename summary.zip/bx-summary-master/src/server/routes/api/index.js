import billing from './billing';
import accounts from './accounts';
import frsummary from './frsummary';
import paperlessEnroll from './paperless/enroll';
import paperlessStatus from './paperless/status';
import supporthours from './supporthours';
import groups from './groups';

export {
    billing,
    accounts,
    frsummary,
    paperlessEnroll,
    paperlessStatus,
    supporthours,
    groups
};
