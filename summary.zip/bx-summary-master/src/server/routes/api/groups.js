import { Router } from 'express';
import { fetchGroups } from './../../models/groups';

const router = Router();

router.get('/', (req, res, next) => {
    fetchGroups(req)
        .then(data => res.json(data))
        .catch(err => next(err));
});

export default router;
