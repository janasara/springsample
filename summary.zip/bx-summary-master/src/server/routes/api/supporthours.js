import { Router } from 'express';
import fetch from 'isomorphic-fetch';
import config from 'config';
import { getHeaders } from './../../utils/headersUtils';
import { parseResponse, checkStatus, normalizeJSON } from './../../utils/apiUtils';

const router = Router();

function createUrl() {
    const NMLV_HUB_URL = config.domains.nmlvhub;
    return `${NMLV_HUB_URL}/v1/admin/supporthours/CustomerService`;
}

router.get('/', (req, res, next) => {
    const headers = getHeaders(req);
    const url = createUrl();

    fetch(url, { headers })
        .then(parseResponse)
        .then(checkStatus)
        .then(normalizeJSON)
        .then(data => res.json(data))
        .catch(err => next(err));
});

export default router;
