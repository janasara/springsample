import { Router } from 'express';
import { fetchAccounts } from './../../models/accounts';

const router = Router();

router.get('/', (req, res, next) => {
    fetchAccounts(req)
        .then(data => res.json(data))
        .catch(err => next(err));
});

export default router;
