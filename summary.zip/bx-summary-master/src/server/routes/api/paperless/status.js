import { domains } from 'config';
import { Router } from 'express';
import fetch from 'isomorphic-fetch';

import fetchTerms from './../../../modules/fetchTerms';
import { checkStatus, normalizeJSON, parseResponse } from './../../../utils/apiUtils';
import { getHeaders, getUniqueId } from './../../../utils/headersUtils';

const router = Router();

export function createUrl(req) {
    // service needs login id of the user and nm unique id of the client you want the edelivery preferences for
    // on CX this is the same person, but on PX it isn't.  That's why the service can't rely on the http header for nmuid
    const uniqueId = getUniqueId(req);
    return `${domains.nmlvhub}/edeliveryv2`;
}

router.get('/', (req, res, next) => {

    const headers = getHeaders(req);
    const url = createUrl(req);

    fetch(url, {headers})
        .then(parseResponse)
        .then(checkStatus)
        .then(normalizeJSON)
        .then((json) => {
            /*
                SAMPLE SERVICE RESPONSE
                service will only return active prefence relationships (filters/ClntPrefRelStsCde = 1) otherwise the array with be blank

                [
                  {
                    "clntprefnum": "6764",
                    "clntpreftypecde": "2", // type code 2 is eDelivery
                    "clntpreftypetxt": "eDelivery",
                    "clntprefsubjprvcde": "4",      // provisioning code
                    "clntprefstrdte": "2014-12-05 16:28:07.266", // start date
                    "clntprefownlenum": "31758239",  // relationship owner LEID
                    "clntprefownlesrccde": "1",
                    "clntprefownbaselegalentityid": "62320148",
                    "personfirstnam": "Peyton",
                    "personlastnam": "Cooney"
                  }
                ]
            */

            const response = {
                enrolled: json.length > 0 && !json[0].isPaperless ? false : true
            }

            // now if we aren't enrolled, just go get the terms right away
            if (!response.enrolled) {
                return fetchTerms(response, headers);
            }

            return Promise.resolve(response);
        })
        .then((response) => {
            res.json(response);
        })
        .catch(err => next(err));
});

export default router;
