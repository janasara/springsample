import { domains } from 'config';
import { Router } from 'express';
import fetch from 'isomorphic-fetch';
import bodyParser from 'body-parser';

import { checkStatus, normalizeJSON, parseResponse } from './../../../utils/apiUtils';
import { getHeaders, getUniqueId } from './../../../utils/headersUtils';

const router = Router();
// parse application/x-www-form-urlencoded
router.use(bodyParser.urlencoded({ extended: false }));
// parse application/json
router.use(bodyParser.json('application/json'));

export function createUrl(req) {
    const uniqueId = getUniqueId(req);
    return `${domains.nmlvhub}/edeliveryv2`;
}

router.post('/', (req, res, next) => {
    // if this isn't set, we probably wouldn't get this far, BUT check it anyway.  Safety first.
    if (!req.query && !req.headers['x-nm-nm_uid']) {
        const err = new Error('Error api/paperless/status: missing nmuniqueid header');
        next(err);
    }

    /*
        ENROLL POST BODY OPTIONS
        {
            clientPrefNum: [empty for new preference record],
            InvitationCde: [pulled from link],
            LeId: [If empty it will take the leid that is tied to the nmuniqueid in the clt_legal_entity table in biip cloud],
            LeSrcCde: [same rule as the LeId above]
            Global: [true – we only support global today however there are talks about supporting other types as well so just include it to be safe],
            TaCAcptInd:  true,
            TaCTypeCde: 2, [type code 2 = paperless]
            TaCAcptMajorVersionNun: [the major version of the current T&C for edelivery that the client accepted as part of the enrollment process]
            TaCAcptMinorVersionNum: [the minor version of the current T&C for edelivery that the client accepted as part of the enrollment process]
        }
    */

    // tryin to be null safe
    const enrollPostBody = {
        Global: true,
        InvitationCde: req.body['inviteCode'] || undefined,
        TaCAcptInd: true,
        TaCAcptMajorVersionNum: req.body['termsMajorVersion'],
        TaCAcptMinorVersionNum: req.body['termsMinorVersion'],
        TaCTypeCde: 2
    }

    const init = {
        body: enrollPostBody,
        method: 'post',
        headers: getHeaders(req)
    };
    const url = createUrl(req);

    fetch(url, init)
        .then(parseResponse)
        .then(checkStatus)
        .then(normalizeJSON)
        .then((json) => {
            /*
                SAMPLE SERVICE RESPONSE

                {
                  "clientPrefNum": 12345
                }
            */

            if (json.clientPrefNum && json.clientPrefNum > 0) {
                const response = {
                    preferenceId: json.clientPrefNum
                };

                res.json(response);
            } else {
                return Promise.reject('edeliveryv2 did not return a preference id');
            }
        })
        .catch(err => next(err));

});

export default router;
