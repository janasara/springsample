import config from 'config';
import { Router } from 'express';
import fs from 'fs';
import React from 'react';
import newrelic from 'newrelic';
import { renderToString } from 'react-dom/server';

import { fetchFinancialreps, fetchAccounts, fetchPaperlessStatus, fetchSupportHours, fetchGroups } from './../../client/js/actions/ApiActions';
import Root from '../../client/js/components/Root';
import createStore from '../../client/js/store/createStore';
import { initialState as paperlessInitialState } from './../../client/js/reducers/paperless';

import AppShell from '../components/AppShell';
import clientConfig from './../utils/clientConfig';
import { getBrowser, getHeaders, getLoginId, getUniqueId, getIdHash } from './../utils/headersUtils';
import IS_DEV from './../utils/isDev';

const router = Router();

let assets;
function readSyncAssetManifest() {
    if (!assets) {
        const assetManifest = JSON.parse(fs.readFileSync('./build/assets/asset-manifest.json', 'utf8'));
        assets = {
            mainJS: assetManifest['main.js'],
            mainCSS: (IS_DEV) ? null : assetManifest['main.css'],
            inlineCSS: (IS_DEV) ? null : fs.readFileSync(`./build/assets/${assetManifest['criticalpath.css']}`, 'utf8')
        };
    }
    return assets;
}

function getMeta(idHash, ua, uniqueId, loginId) {
    return {
        title: 'Summary',
        idHash,
        loginId,
        uniqueId,
        ua
    };
}

function getPaperlessState(req, res) {
    const paperState = paperlessInitialState;
    if (req.query && req.query.ic) {
        paperState.inviteCode = req.query.ic;
        paperState.isDismissed = false;
        res.clearCookie('goPaperless', { domain: config.domains.cookie });
    } else {
        paperState.inviteCode = undefined;
        paperState.isDismissed = req.cookies.goPaperless === 'isDismissed';
    }
    paperState.featureActive = config.workInProgress && config.workInProgress.project24;
    return paperState;
}

function fetchPaperless(store, options) {
    // check if this feature is active...
    if (config.workInProgress && config.workInProgress.project24) {
        // TODO: the getting terms could probably be done more efficiently
        // this checks the status and then gets the terms if status is "not enrolled"
        return store.dispatch(fetchPaperlessStatus(options));
    }

    return Promise.resolve();
}

router.get('/', (req, res) => {
    const nreumJS = newrelic.getBrowserTimingHeader();
    const idHash = getIdHash(req);
    const loginId = getLoginId(req);
    const ua = getBrowser(req);
    const uniqueId = getUniqueId(req);
    const assetManifest = readSyncAssetManifest();
    const store = createStore({
        meta: getMeta(idHash, ua, uniqueId, loginId),
        paperless: getPaperlessState(req, res)
    });
    const options = {
        headers: getHeaders(req)
    };

    Promise.all([
        fetchPaperless(store, options),
        store.dispatch(fetchFinancialreps(options)),
        store.dispatch(fetchAccounts(options)),
        store.dispatch(fetchSupportHours(options)),
        store.dispatch(fetchGroups(options))
    ]).catch((err) => {
        console.log('Error hydrating state from server: ', err);
    }).then(() => {
        const currentState = store.getState();
        const rootHtml = renderToString(<Root store={store} />);
        const htmlReponse = AppShell(assetManifest, ua, clientConfig, rootHtml, currentState, nreumJS);
        res.send(htmlReponse);
    });
});

export default router;
