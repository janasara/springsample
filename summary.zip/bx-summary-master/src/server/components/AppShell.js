/*eslint-disable*/
import { minify } from 'html-tagged-literals';
import { assetPath } from 'config';

import { name, version } from '../../../package'

const AppShell = ({ mainJS, mainCSS, inlineCSS}, ua, clientConfig, rootHtml, initialState, nreumJS) => {
    return minify`
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>${initialState.meta.title}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="dns-prefetch" href="${clientConfig.nmcDomain}">
        ${(ua.chrome) ? `
          ${mainCSS ? `<link rel="preload" href="${assetPath}/${mainCSS}" as="style">` : ''}
        ` : `
          ${mainCSS ? `<link rel="prefetch" href="${assetPath}/${mainCSS}">` : ''}
        `}
        ${nreumJS}
        ${inlineCSS ? `<style>${inlineCSS}</style>` : ''}
        ${mainCSS ? `<link rel="stylesheet" href="${assetPath}/${mainCSS}">` : ''}
        <link rel="icon" href="${clientConfig.basePath}/favicon/favicon.ico">
      </head>
      <body>
        <!--# include virtual="/header" -->
        <div id="root">${rootHtml}</div>
        <!--# include virtual="/footer?name=${name}&version=${version}" -->
        <script>
            window.__STATE__ = ${JSON.stringify(initialState)};
            window.__CONFIG__ = ${JSON.stringify(clientConfig)};
        </script>
        <script src="${assetPath}/${mainJS}"></script>
      </body>
    </html>`;
};

export default AppShell;
//
// <script>
// navigator.serviceWorker.register('/summary/sw.js').then(function(reg) {
//   console.log('◕‿◕', reg);
// }, function(err) {
//   console.log('ಠ_ಠ', err);
// });
// </script>
