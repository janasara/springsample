import newrelic from 'newrelic';

import IS_DEV from './../utils/isDev'

export default () => (err, req, res, next) => { // eslint-disable-line no-unused-vars
    newrelic.noticeError(err);
    console.log(err.stack);
    res.status(500).send((IS_DEV) ? err.stack : 'Internal application error');
}
