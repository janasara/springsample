export default () => (req, res) => {
  const err = `Not found: ${req.originalUrl}`
  console.log(err)
  res.status(404).send(err)
}
