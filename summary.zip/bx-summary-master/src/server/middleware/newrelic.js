import newrelic from 'newrelic';
export default () => (req, res, next) => {
    newrelic.setTransactionName(req.originalUrl.replace(/^\//, ''));
    newrelic.addCustomParameter('nmUniqueId', req.headers['x-nm-nm_uid'] ? req.headers['x-nm-nm_uid'] : 'no_user');
    newrelic.addCustomParameter('env', `${process.env.NODE_ENV}${process.env.NODE_APP_INSTANCE ? `-${process.env.NODE_APP_INSTANCE}` : ''}`);
    next();
};
