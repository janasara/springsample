import { domains } from 'config';
import fetch from 'isomorphic-fetch';

import { parseResponse, checkStatus, normalizeJSON } from './../utils/apiUtils';
import { getHeaders, getUniqueId } from './../utils/headersUtils';

export function createUrl(req) {
    const uniqueId = getUniqueId(req);
    return `${domains.nmlvhub}/field/client/${uniqueId}`;
}

export function fetchFrsummary(req) {
    const headers = getHeaders(req);
    const url = createUrl(req);

    return fetch(url, { headers })
        .then(parseResponse)
        .then(checkStatus)
        .then(normalizeJSON);
}
