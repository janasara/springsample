import fetch from 'isomorphic-fetch';
import config from 'config';
import _ from 'lodash';
import newrelic from 'newrelic';
import formatDateMMDDYYY from '../utils/dateUtils';
import formatAsDollars from '../utils/stringUtils';
import * as ROLE_CODES from './../constants/ClientRoleCodes';
import * as CODES from './../constants/ProductCodes';
import { getHeaders } from './../utils/headersUtils';
import { parseResponse, checkStatus, normalizeJSON } from './../utils/apiUtils';
import IS_DEV from './../utils/isDev';

// todo: should be converted to es6 class
const Accounts = function accounts() {
    const defaults = {
        annuityData: [],
        insuranceData: [],
        investmentData: [],
        accessFundsData: []
    };
    return _.defaults(this, defaults);
};

Accounts.prototype.getKeyForRole = function getKey(account, typeCode) {
    let key = '';
    let primaries = [];

    _.forEach(account.roles, (role) => {
        if (role.clientRoleCode === typeCode) {
            key = key + role.nmUniqueID;
            primaries.push(role);
        }
    });

    // strip any characters and spaces from each name.
    primaries = _.sortBy(primaries, ['roleSequenceNumber']);

    let sortKey = '';
    _.forEach(primaries, (primary) => {
        if (primary.related.lastName && primary.related.firstName) {
            sortKey = `${sortKey} ${primary.related.lastName} ${primary.related.firstName} ${primary.related.middleName ?
                            primary.related.middleName : ''}`;
        } else if (primary.related.organizationName) {
            sortKey = `${sortKey} ${primary.related.organizationName}`;
        } else {
            sortKey = `${sortKey} `;
        }
    });

    return sortKey;
};

Accounts.prototype.mapApi = function map(accounts) {
    const self = this;
    const formattedAccounts = _.map(accounts, account => self.mapDataToObject(account));

    if (formattedAccounts && formattedAccounts.length > 0) {
        // 1 = Life Insurance 2 = Disability Insurance 3 = Long Term Care 4 = Income Plan
        // 5 = Access Fund 6 = Fixed Annuity 7 = Investment Product 8 = Variable Annuity

        const annuityData = _.filter(formattedAccounts, account => account.accountTypeCde === 6
        || account.accountTypeCde === 8);
        if (annuityData.length > 0) {
            self.annuityData = _.sortBy(annuityData, ['sortKey']);
        }
        const incomePlanData = _.filter(formattedAccounts, account => account.accountTypeCde === 4);
        if (incomePlanData.length > 0) {
            self.incomePlanData = _.sortBy(incomePlanData, ['sortKey']);
        }

        const investmentData = _.filter(formattedAccounts, account => account.accountTypeCde === 7);
        if (investmentData.length > 0) {
            self.investmentData = _.sortBy(investmentData, ['sortKey']);
        }

        const accessFundsData = _.filter(formattedAccounts, { accountTypeCde: 5 });
        if (accessFundsData.length > 0) {
            self.accessFundsData = _.sortBy(accessFundsData, ['sortKey']);
        }

        const lifeData = _.filter(formattedAccounts, account => account.accountTypeCde === 1);
        if (lifeData.length > 0) {
            self.lifeData = _.sortBy(lifeData, ['sortKey']);
        }

        const varLifeData = _.filter(formattedAccounts, account => account.accountTypeCde === 9);
        if (varLifeData.length > 0) {
            self.varLifeData = _.sortBy(varLifeData, ['sortKey']);
        }

        const bdiData = _.filter(formattedAccounts, account => account.accountTypeCde === 10);
        if (bdiData.length > 0) {
            self.bdiData = _.sortBy(bdiData, ['sortKey']);
        }
    }
};

Accounts.prototype.mapDataToObject = function mapData(account) {
    const self = this;
    let sortKey = '';

    switch (account.accountTypeCde) {
        case CODES.LifeInsurance:
            sortKey = self.getKeyForRole(account, ROLE_CODES.Insured);
            break;
        case CODES.DisabilityIncome:
            sortKey = self.getKeyForRole(account, ROLE_CODES.Insured);
            break;
        case CODES.LongTermCare:
            sortKey = self.getKeyForRole(account, ROLE_CODES.Insured);
            break;
        case CODES.IncomePlan:
            sortKey = self.getKeyForRole(account, ROLE_CODES.Owner);
            break;
        case CODES.AccessFund:
            sortKey = self.getKeyForRole(account, ROLE_CODES.PaymentRecipient);
            break;
        case CODES.Annuity:
        case CODES.VariableAnnuity:
            sortKey = self.getKeyForRole(account, ROLE_CODES.Annuitant);
            break;
        case CODES.InvestmentProduct:
            sortKey = self.getKeyForRole(account, ROLE_CODES.PlanOwner);
            break;
        case CODES.VariableLife:
            sortKey = self.getKeyForRole(account, ROLE_CODES.Insured);
            break;
        case CODES.BusinessDisabilityInsurance:
            sortKey = self.getKeyForRole(account, ROLE_CODES.Insured);
            break;
        default:
            break;
    }

    if (!sortKey || sortKey == '') {
        console.log('Null sort key found for user ', account.ownerName);
        const sortKeyError = new Error('null sort key found');
        newrelic.noticeError(sortKeyError, [{
            key: 'accountType',
            value: account.accountType
        }]);
    }

    return {
        accountNumberMasked: account.accountNumberMasked,
        accountId: account.accountId,
        accountTypeCde: account.accountTypeCde,
        accountType: account.accountType,
        accountTypeDetail: account.accountTypeDetail,
        benefit: account.benefit ? formatAsDollars(account.benefit) : undefined,
        benefitContext: account.benefitContext,
        insuredName: account.insuredName,
        ownerName: account.ownerName,
        annualizedPremium: account.annualizedPremium ? formatAsDollars(account.annualizedPremium) : undefined,
        paidUp: account.paidUp,
        surrenderValue: account.surrenderValue ? formatAsDollars(account.surrenderValue) : undefined,
        institution: account.institution,
        sortKey,
        value: account.value ? formatAsDollars(account.value) : undefined,
        valueAsOfDate: account.valueAsOfDate ? formatDateMMDDYYY(account.valueAsOfDate) : undefined
    };
};

export function createUrl(headers) {
    const NMLV_HUB_URL = config.domains.nmlvhub;
    const id = (headers['x-nm-nm_uid']) ? headers['x-nm-nm_uid'] : null;
    return (id && !IS_DEV) ? `${NMLV_HUB_URL}/accounts/client/${id}` : `${NMLV_HUB_URL}/accounts`;
}

export function parseAccountsJSON(json) {
    const accounts = new Accounts();
    accounts.mapApi(json);
    return accounts;
}

export function fetchAccounts(req) {
    const headers = getHeaders(req);
    const url = createUrl(headers);

    return fetch(url, { headers })
        .then(parseResponse)
        .then(checkStatus)
        .then(normalizeJSON)
        .then(parseAccountsJSON);
}
