import { domains } from 'config';
import fetch from 'isomorphic-fetch';
import formatAsDollars from '../utils/stringUtils';
import { getHeaders, getUniqueId } from './../utils/headersUtils';
import { parseResponse, checkStatus, normalizeJSON } from './../utils/apiUtils';


export function createUrl(req) {
    const uniqueId = getUniqueId(req);
    return `${domains.nmlvhub}/business/groups/${uniqueId}`;
}

export function parseGroupsJSON(json) {
    return json.map(data => ({
        companyName: data.companyName,
        entitlements: data.entitlements.map(entitlement => ({
            groupType: entitlement.groupType,
            groups: entitlement.groups.map(group => ({
                groupNumber: group.groupNumber,
                groupNumberMasked: group.groupNumberMasked,
                groupName: group.groupName,
                netDeathBenefit: formatAsDollars(group.netDeathBenefit),
                contractFundInvestedAssetsValue: formatAsDollars(group.contractFundInvestedAssetsValue),
                cashSurrenderValue: formatAsDollars(group.cashSurrenderValue),
                costBasisValue: formatAsDollars(group.costBasisValue),
                policyCount: group.policyCount
            }))
        }))
    }));
}

export function fetchGroups(req) {
    const headers = getHeaders(req);
    const url = createUrl(req);

    return fetch(`${url}`, { headers })
        .then(parseResponse)
        .then(checkStatus)
        .then(normalizeJSON)
        .then(parseGroupsJSON);
}
