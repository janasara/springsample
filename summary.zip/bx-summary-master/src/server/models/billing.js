import { clientCrossOriginUrls } from 'config';
import fetch from 'isomorphic-fetch';

import { parseResponse, checkStatus, normalizeJSON } from './../utils/apiUtils';
import { getHeaders } from './../utils/headersUtils';

export function createUrl() {
    return clientCrossOriginUrls.billingUrl;  // this doesn't seem right...
}

export function fetchBilling(req) {
    const headers = getHeaders(req);
    const url = createUrl();

    return fetch(url, { headers })
        .then(parseResponse)
        .then(checkStatus)
        .then(normalizeJSON);
}
