import { domains } from 'config';
import fetch from 'isomorphic-fetch';

import { getHeaders } from './../utils/headersUtils';
import { parseResponse, checkStatus, normalizeJSON } from './../utils/apiUtils';

export function createUrl(feature) {
    const featureBaseUrl = `${domains.nmlvhub}/features`;
    return (feature) ? `${featureBaseUrl}/${feature}` : featureBaseUrl;
}

export function fetchFeatures(req) {
    const headers = getHeaders(req);
    const url = createUrl();

    return fetch(`${url}`, { headers })
        .then(parseResponse)
        .then(checkStatus)
        .then(normalizeJSON)
        .then(features => features
            .filter(feature => feature.featureEnabled)
            .map(feature => feature.featureId));
}

export function fetchFeature(req, feature) {
    const headers = getHeaders(req);
    const url = createUrl(feature);

    return fetch(`${url}`, { headers })
        .then(parseResponse)
        .then(checkStatus)
        .then(normalizeJSON);
}
