import Timezone from 'moment-timezone';

export default function formatDateMMDDYYY(dateString) {
    // const date = Moment(dateString, Moment.ISO_8601);
    const date = Timezone.tz(dateString, 'America/Chicago');
    return date.format('MM/DD/YYYY z');
}
