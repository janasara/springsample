import uniq from 'lodash/uniq';
import * as ProductCodes from '../constants/ProductCodes';
import formatAsDollars from './stringUtils';

export function formatFrequency(value) {
    const key = (value || '').toUpperCase();
    const map = {
        'N/A': 'N/A',
        DAILY: 'day',
        MONTHLY: 'month'
    };
    return map[key] || '';
}

const filterAccountsBy = key => (accounts, ...values) => accounts.filter(account => values.includes(account[key]));
export const filterAccountsByCode = filterAccountsBy('accountTypeCde');
export const filterAccountsByInsured = filterAccountsBy('insuredName');

export const getInsureds = accounts => uniq(accounts.map(account => account.insuredName).filter(Boolean));

// Given a user's nmUniqueID and one or more accounts:
// Return the owner name if the user is the only owner.
// Return "Multiple Owners" if there are multiple owners.
// Otherwise, return an empty string.
export function getOwner(userId, ...accounts) {
    const MULTIPLE_OWNERS = 'Multiple Owners';
    const ROLE_TYPE_OWNER = 15;

    // No accounts to get data from, so return an empty string.
    if (!accounts.length) return '';

    // Map accounts to roles, flatten the array, and get just the owner roles
    const ownerRoles = accounts
        .map(account => account.roles || [])
        .reduce((a, b) => a.concat(b), [])
        .filter(role => role.roleTypeCode === ROLE_TYPE_OWNER);

    // No owner roles were returned,
    // so we don't have nmUniqueIDs to compare with the logged-in user.
    // Just return the owner (or multiple owners if more than one)
    if (!ownerRoles.length) {
        const sameOwner = accounts.every(account => account.ownerName === accounts[0].ownerName);
        return sameOwner ? accounts[0].ownerName : MULTIPLE_OWNERS;
    }

    // Owner roles were returned,
    // so return return owner name if owner and logged-in user have different nmUniqueIDs
    if (ownerRoles.every(owner => owner.nmUniqueID === ownerRoles[0].nmUniqueID)) {
        return ownerRoles[0].nmUniqueID === userId ? '' : accounts[0].ownerName;
    }

    // Owner roles were returned, but there are multiple owners
    return MULTIPLE_OWNERS;
}

const NA = 'N/A';

const getTotalValue = (list, key) => formatAsDollars(
    list.map(item => item[key])
        .filter(Boolean)
        .reduce((total, value) => total + value, 0)
);

const getFormattedTotal = (list, key) => (list.length > 0 ? getTotalValue(list, key) : NA);

const getFormattedTotalAnnualPremium = (list) => {
    if (list.length === 0) return NA;
    const areAllPremiumsPaidUp = list.every(account => account.paidUp === 'Y');
    return areAllPremiumsPaidUp ? 'Paid Up' : getTotalValue(list, 'annualizedPremium');
};

const getTotalBDIData = (list) => {
    let totalBDIBenefit = '';
    let totalBDIFrequency = '';
    switch (list.length) {
        case 1:
            totalBDIBenefit = getTotalValue(list, 'benefit');
            totalBDIFrequency = 'month';
            break;
        case 0:
            totalBDIBenefit = NA;
            totalBDIFrequency = NA;
            break;
        default:
            totalBDIBenefit = 'See Below';
            totalBDIFrequency = '';
            break;
    }
    return [totalBDIBenefit, totalBDIFrequency];
};

const getFrequency = (accounts) => {
    if (accounts.length === 0) return NA;
    const values = accounts.map(account => account.benefitContext);
    return values.every(x => x === values[0]) ? values[0] : 'See Below';
};

export const getTotals = (accounts, loggedIn) => {
    const insuredAccountList = getInsureds(accounts).map(insured => filterAccountsByInsured(accounts, insured));

    const formatAccounts = (accountList) => {
        const totalNetDeathList = filterAccountsByCode(accountList, ProductCodes.LifeInsurance, ProductCodes.VariableLife);
        const netCashList = accountList.filter((account) => {
            const hasNetCashValue = account.valueDescription === 'Net Cash Value' && account.value !== 0;
            // TODO: accounts service should be updated so that VarLife products have a valueDescription
            const isVariableLife = account.accountTypeCde === ProductCodes.VariableLife;
            return hasNetCashValue || isVariableLife;
        });
        const totalAnnualList = accountList.filter(account => account.annualizedPremium != null);
        const totalInvestedList = filterAccountsByCode(accountList, ProductCodes.VariableLife);
        const totalDIList = filterAccountsByCode(accountList, ProductCodes.DisabilityIncome);
        const totalBDIList = filterAccountsByCode(accountList, ProductCodes.BusinessDisabilityInsurance);
        const [totalBDIBenefit, totalBDIFrequency] = getTotalBDIData(totalBDIList);
        const maximumBenefitList = filterAccountsByCode(accountList, ProductCodes.LongTermCare);
        const totalLoan = accountList.filter(account => !!account.totalLoanAmount).length > 0 ?
            getTotalValue(accountList, 'totalLoanAmount') : '';

        return {
            insuredName: accountList[0] ? accountList[0].insuredName : '',
            numProducts: accountList.length,
            owner: getOwner(loggedIn, ...accountList),
            totalNetDeathBenefit: getFormattedTotal(totalNetDeathList, 'benefit'),
            totalNetCashValue: getFormattedTotal(netCashList, 'value'),
            totalAnnualPremium: getFormattedTotalAnnualPremium(totalAnnualList),
            totalInvestedAssets: getFormattedTotal(totalInvestedList, 'totalValueAmount'),
            totalLoan,
            totalDIBenefit: getFormattedTotal(totalDIList, 'benefit'),
            totalBDIBenefit,
            totalLTCMaximumBenefit: getFormattedTotal(maximumBenefitList, 'benefit'),
            totalDIFrequency: totalDIList.length === 0 ? NA : 'month',
            totalBDIFrequency,
            totalLTCFrequency: formatFrequency(getFrequency(filterAccountsByCode(accountList, ProductCodes.LongTermCare)))
        };
    };
    const totalsTotals = formatAccounts(accounts);

    return {
        insureds: insuredAccountList.map(list => formatAccounts(list)),
        totalNetDeathBenefit: totalsTotals.totalNetDeathBenefit,
        totalNetCashValue: totalsTotals.totalNetCashValue,
        totalAnnualPremium: totalsTotals.totalAnnualPremium,
        totalInvestedAssets: totalsTotals.totalInvestedAssets,
        totalLoan: totalsTotals.totalLoan,
        totalDIBenefit: NA,
        totalBDIBenefit: NA,
        totalLTCMaximumBenefit: NA
    };
};

export function parseSection({ accounts, user, code, mapFrequency }) {
    return filterAccountsByCode(accounts, code).map(account => ({
        productNumber: account.accountNumberMasked,
        productType: account.accountTypeDetail,
        owner: getOwner(user, account),
        insured: account.insuredName,
        frequency: mapFrequency(account),
        benefit: formatAsDollars(account.benefit)
    }));
}

export function parseSections({ accounts, user }) {
    const getSection = ({ code, mapFrequency }) => parseSection({ accounts, user, code, mapFrequency });
    return {
        bdiData: getSection({ code: ProductCodes.BusinessDisabilityInsurance, mapFrequency: () => 'month' }),
        diData: getSection({ code: ProductCodes.DisabilityIncome, mapFrequency: () => 'month' }),
        lifeData: getSection({ code: ProductCodes.LifeInsurance, mapFrequency: () => '' }),
        ltcData: getSection({ code: ProductCodes.LongTermCare, mapFrequency: account => formatFrequency(account.benefitContext) }),
        varLifeData: getSection({ code: ProductCodes.VariableLife, mapFrequency: () => '' })
    };
}

export function parseAccounts({ accounts, user }) {
    return {
        ...parseSections({ accounts, user }),
        insuredList: getInsureds(accounts),
        totals: getTotals(accounts, user)
    };
}
