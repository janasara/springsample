import config from 'config';

const createClientConfig = { // only expose stuff that is ok on client
    basePath: config.basePath,
    clientCrossOriginUrls: config.clientCrossOriginUrls,
    splitInsInv: config.workInProgress.splitInsInv,
    netWorth: config.workInProgress.netWorth,
    nmcDomain: config.domains.nmc,
    planDomain: config.domains.plan,  // only used for the contact/fr card
    paperlessCookieDomain: config.domains.cookie
};

export default createClientConfig;
