import _ from 'lodash';
import crypto from 'crypto';
import useragent from 'useragent';
import IS_DEV from './isDev';

export function getHeaders(req) {
    const headers = _.pickBy(req.headers, (value, key) =>
        _.startsWith(key.toLowerCase(), 'x-nm') || _.startsWith(key.toLowerCase(), 'x-auth')
    );

    headers['X-Nm-User-Type'] = 'C';
    headers['X-Auth-Client-Id'] = headers['x-nm-nm_uid']; // wtf

    if (IS_DEV) {
        headers.apikey = 'pls9cBMUq6qSrLkYXBy3z89ufDIaWtS3';
    }

    return headers;
}

export function getUniqueId(req) {
    return req.headers['x-nm-nm_uid'] ? req.headers['x-nm-nm_uid'] : 'no_user';
}

export function getIdHash(req) {
    return req.headers['x-nm-nm_uid'] ?
        crypto.createHash('md5').update(req.headers['x-nm-nm_uid']).digest('hex') : 'no_user';
}

export function getLoginId(req) {
    return req.headers['x-nm-login-id'] ? req.headers['x-nm-login-id'] : 'no_user';
}

export function getUserAgent(req) {
    return useragent.parse(req.headers['user-agent']);
}

export function getBrowser(req) {
    return useragent.is(req.headers['user-agent']);
}
