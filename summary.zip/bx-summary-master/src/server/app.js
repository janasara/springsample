import 'newrelic'
import compression from 'compression';
import { basePath } from 'config';
import cookieParser from 'cookie-parser';
import express from 'express';
import path from 'path';
import { cacheControl, handleErrors, notFound, newrelic } from './middleware';
import { billing, frsummary, accounts, paperlessEnroll,
  paperlessStatus, supporthours, groups
} from './routes/api';
import health from './routes/health';
import root from './routes/root';
import IS_DEV from './utils/isDev';
import IS_PROD from './utils/isProd';
import attachRunMiddleware from 'run-middleware';
const app = express();

attachRunMiddleware(app);

app.use(cookieParser());
app.disable('x-powered-by');
app.use(compression());
app.use(newrelic());
app.use(`${basePath}/assets`, express.static(path.join(__dirname, '/../../build/assets'), {
    maxAge: '365d'
}));
app.use(`${basePath}/whatsnew`, express.static(path.join(__dirname, '/routes/whatsnew'), {
    maxAge: '365d'
}));
app.use(cacheControl());
app.use(`${basePath}`, root);
app.use('/', root);
app.use(`${basePath}/health`, health);
app.use(`${basePath}/api/accounts`, accounts);
app.use(`${basePath}/api/frsummary`, frsummary);
app.use(`${basePath}/api/paperless/status`, paperlessStatus);
app.use(`${basePath}/api/paperless/enroll`, paperlessEnroll);
app.use(`${basePath}/api/supporthours`, supporthours);
app.use(`${basePath}/api/business/groups`, groups);

if (IS_DEV) {
    let times = 0;

    app.use('/checksession', (req, res) => {
        // simulate checksession scenario in dev
        times === 1 ?
            res.status(200).send()
        :
            times++;
        res.status(403).send();
    });
    app.use('/aspping.aspx', (req, res) => {
        res.status(200).send();
    });
    app.use('/clientinit', (req, res) => {
        res.redirect(302, '/summary');
    });
    app.use('/whatsnew/frame.js', (req, res) => {
        res.status(200).send();
    });
}

// use mock route in non prod env for testing purposes
if (!IS_PROD && !IS_DEV) {
    app.use(`${basePath}/api/billing`, billing);
}

app.use(notFound());
app.use(handleErrors());

export default app;
