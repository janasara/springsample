import { domains } from 'config';
import fetch from 'isomorphic-fetch';

import { checkStatus, normalizeJSON, parseResponse } from './../utils/apiUtils';

export function createUrl() {
    // this will only get terms for edelivery, returning the actual terms in html format
    return `${domains.nmlvhub}/termsconditions/2?returnlang=true`;
}

export default function fetchTerms(response, headers) {
    const url = createUrl();

    return new Promise((resolve, reject) => {
        fetch(url, { headers })
            .then(parseResponse)
            .then(checkStatus)
            .then(normalizeJSON)
            .then((json) => {
                /*
                    SAMPLE SERVICE RESPONSE
                    [
                      {
                        "typeCode": "2",
                        "typeText": "Document Delivery",
                        "acceptedAndCurrent": "false",
                        "majorVersion": "3",
                        "minorVersion": "0",
                        "language": "<h3>NEW RULES</h3><ul><li>1. Lilian can not use the phone</li><li>2. Lilian can not go outside ever
                        again</li></ul>"
                      }
                    ]
                */

                // should always return something, but just in case...
                if (json.length > 0) {
                    response.majorVersion = json[0].majorVersion;
                    response.minorVersion = json[0].minorVersion;
                    response.language = json[0].language;
                }
                resolve(response);
            })
            .catch(err => reject(err));
    });
}
