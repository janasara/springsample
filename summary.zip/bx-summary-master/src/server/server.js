import app from './app';

const PORT = 8080;

const httpServer = app.listen(PORT, () => {
    console.log(`Micro-App on http://localhost:${PORT} [${app.settings.env}]`);
});

process.on('SIGTERM', () => {
    httpServer.close(() => {
        process.exit(0);
    });
});
