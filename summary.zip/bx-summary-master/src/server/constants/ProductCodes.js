export const LifeInsurance = 1;
export const DisabilityIncome = 2;
export const LongTermCare = 3;
export const IncomePlan = 4;
export const InvestmentProduct = 7;
export const VariableAnnuity = 8;
export const VariableLife = 9;
export const BusinessDisabilityInsurance = 10;
export const AccessFund = 5;
export const Annuity = 6;


export default [
    LifeInsurance,
    DisabilityIncome,
    LongTermCare,
    IncomePlan,
    InvestmentProduct,
    VariableAnnuity,
    VariableLife,
    BusinessDisabilityInsurance
];
