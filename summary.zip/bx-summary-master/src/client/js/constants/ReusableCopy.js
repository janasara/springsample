const reusableCopy = {

    MY_REUSABLE_COPY: 'import and reuse it'

};


export default reusableCopy;
