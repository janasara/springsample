import keyMirror from 'keymirror';

const ActionTypes = keyMirror({

    GO_PAPERLESS: null,  // click on "go paperless" action item in action card
    PAY_NOW: null,
    EMAIL_FR: null,
    VISIT_FR_WEBSITE: null,
    VISIT_FR_TWITTER: null,
    VISIT_FR_FACEBOOK: null,
    VISIT_FR_LINKEDIN: null,
    VISIT_SERVICE_CENTER: null,
    VISIT_CONTACT: null,
    MANAGE_LOAN_ACTION: null,
    ACTION_COUNT: null,
    GOTO_BILLING: null,

    DISMISS_SYSTEM_MESSAGE: null,
    SELECT_SYSTEM_MESSAGE_CONTACT: null,
    ENGAGE_CARD: null,
    VIEW_ISA_DETAILS: null,
    NAVIGATE_ISA: null,
    VIEW_ISA_LOAN: null,

    SET_SESSION_STORAGE: null,
    SET_TERMSTATE: null,
    DISMISS_ACTION: null,
    DISMISS_ITEM: null,

    ACCEPT_TERMS_REQUEST: null,
    ACCEPT_TERMS_SUCCESS: null,
    ACCEPT_TERMS_FAILURE: null,

    FINANCIALREPS_REQUEST: null,
    FINANCIALREPS_SUCCESS: null,
    FINANCIALREPS_FAILURE: null,
    INVALIDATE_FINANCIALREPS: null,

    SELECT_INSURANCE_TAB: null,

    HOURS_REQUEST: null,
    HOURS_SUCCESS: null,
    HOURS_FAILURE: null,
    INVALIDATE_HOURS: null,

    FOOTNOTES_REQUEST: null,
    FOOTNOTES_SUCCESS: null,
    FOOTNOTES_FAILURE: null,
    INVALIDATE_FOOTNOTES: null,

    MESSAGES_REQUEST: null,
    MESSAGES_SUCCESS: null,
    MESSAGES_FAILURE: null,
    INVALIDATE_MESSAGES: null,

    TERMS_REQUEST: null,
    TERMS_SUCCESS: null,
    TERMS_FAILURE: null,
    INVALIDATE_TERMS: null,

    ACTIONS_REQUEST: null,
    ACTIONS_SUCCESS: null,
    ACTIONS_FAILURE: null,
    INVALIDATE_ACTIONS: null,
    INNER_CIRCLE_ACTION: null,
    INNER_CIRCLE_ENGAGE: null,

    BILLING_REQUEST: null,
    BILLING_SUCCESS: null,
    BILLING_FAILURE: null,
    INVALIDATE_BILLING: null,

    ACCOUNTS_REQUEST: null,
    ACCOUNTS_SUCCESS: null,
    ACCOUNTS_FAILURE: null,
    INVALIDATE_ACCOUNTS: null,


    OPEN_PAPERLESS_MODAL: null,
    CLOSE_PAPERLESS_MODAL: null,
    DISMISS_OR_REMIND: null,

    PAPERLESS_STATUS_SUCCESS: null,
    PAPERLESS_STATUS_FAILURE: null,

    PAPERLESS_ENROLL_REQUEST: null,
    PAPERLESS_ENROLL_SUCCESS: null,
    PAPERLESS_ENROLL_FAILURE: null,

    CLOSE_SUCCESS_MODAL: null,

    GROUPS_REQUEST: null,
    GROUPS_SUCCESS: null,
    GROUPS_FAILURE: null,

    // remove
    NONE: null

});

export default ActionTypes;
