export default (callback) => {
    require.ensure([], (require) => {
        const React = require('react');
        const ReactDom = require('react-dom');
        const Root = require('./../components/Root').default;

        const render = (store) => {
            ReactDom.render(
                <Root store={store} />,
                document.getElementById('root')
            );
        };
        callback(render);
    }, 'render');
};
