import config from './config';
import ajax from './ajax';
import hasStorage from './hasStorage';

export default (callback) => {
    let hasSessionStorage = hasStorage();
    if (hasSessionStorage) {
        var rdrct = sessionStorage.getItem('SUMMARYRDRCT') ? parseInt(sessionStorage.getItem('SUMMARYRDRCT')) : 0;
    } else {
        var rdrct = 0;
    }
    var interval = 15000;
    if (new Date().getTime() > (rdrct + interval)) {
        if (hasSessionStorage) {
            sessionStorage.setItem('SUMMARYRDRCT', new Date().getTime());
        }

        ajax({
            url: `${config.nmcDomain}/aspping.aspx`,
            success: function success(xhr) {
                if (xhr.status === 200) {
                    ajax({
                        url: `${config.nmcDomain}/checksession`,
                        success: function success(xhr) {
                            if (xhr.status === 403) {
                                window.location = `${config.nmcDomain}/clientInit?params=` + encodeURIComponent(window.location.search);
                            } else {
                                callback();
                            }
                        },
                        error: function error() {
                            callback();
                        }
                    });
                } else {
                    callback();
                }
            },
            error: function error() {
                callback();
            }
        });
    } else {
        callback();
    }
};
