import numeral from 'numeral';

export default function formatAsDollars(number) {
    return numeral(number).format('$0,0.00');
}
