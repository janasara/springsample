import loadScript from './loadScript';

export default (version, callback) => {
    if (!version) {
        return false;
    }
    window.whatsnew = {
        version: `${version}`,
        app: 'summary',
        url: `/summary/whatsnew/slides_${version}.json`
    };
    return loadScript('/whatsnew/frame.js', callback);
};
