import isBrowser from './isBrowser';

const OPTIONS = {
    credentials: 'include',
    headers: {
        'Accept': 'application/json', // eslint-disable-line
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest'
    }
};

export function parseResponse(response) {
    return response.json().then(json => ({ json, response })); // provide parsed response and original response
}

export function checkStatus({ json, response }) {
    if (!response.ok) { // status in the range 200-299 or not
        return Promise.reject(new Error(response.statusText || 'Status not OK')); // reject & let catch decide how to handle/throw
    }

    return { json, response };
}

export function normalizeJSON({ json }) {
    return json;
}

// if you don't want to cache fetch, use defaultFetch
export default (url, options) => {
    if (isBrowser) {
        return fetch(url, options || OPTIONS)
            .then(parseResponse)
            .then(checkStatus)
            .then(normalizeJSON);
    } else {
        return serverFetch(url, options || OPTIONS)
            .then(parseResponse)
            .then(checkStatus)
            .then(normalizeJSON);
    }
};

function serverFetch(url, options) {
    const app = require('./../../../server/app').default;
    return new Promise((resolve, reject) => {
        try {
            app.runMiddleware(url, options, (code, data, headers) => {
                const resp = new Response(data, {
                    status: code,
                    headers
                });
                resolve(resp);
            });
        } catch (e) {
            console.log('error in middleware ', e.message);
            reject(e);
        }
    });
}
