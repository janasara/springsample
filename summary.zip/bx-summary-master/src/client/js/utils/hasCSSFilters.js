export default () => {
    const el = document.createElement('div');
    el.style.cssText = ['-webkit-', '-moz-', '-o-', '-ms-'].join('filter:blur(2px); ');
    return !!el.style.length && ((document.documentMode === undefined || document.documentMode > 9));
};
