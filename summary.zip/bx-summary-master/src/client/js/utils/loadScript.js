export default (url, callback) => {
    const script = document.createElement('script');
    callback = callback || function emptyState() {};
    script.type = 'text/javascript';
    if (script.readyState) {
        script.onreadystatechange = function statechange() {
            if (script.readyState === 'loaded' || script.readyState === 'complete') {
                script.onreadystatechange = null;
                callback();
            }
        };
    } else {
        script.onload = function onload() {
            callback();
        };
    }
    script.async = true;
    script.src = url;
    document.getElementsByTagName('head')[0].appendChild(script);
    return script;
};
