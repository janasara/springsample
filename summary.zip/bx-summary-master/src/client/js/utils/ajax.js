export default ({ url, success, error }) => {
    const xhr = new XMLHttpRequest();
    xhr.onload = function load() { success(xhr); };
    xhr.onerror = function err() { error(xhr); };
    xhr.open('GET', url, true);
    xhr.withCredentials = true;
    xhr.send();
    return xhr;
};
