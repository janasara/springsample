const mediaQueries = {

    $mobile: '(max-width: 40em)',
    $mobileAndNotPrint: 'screen and (max-width: 40em)',
    $desktopAndPrint: 'not all and (max-width: 40em), print',
    $desktop: 'not all and (max-width: 40em)'

};

export default mediaQueries;
