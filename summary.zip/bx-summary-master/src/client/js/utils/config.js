// IS_BROWSER is defined in webpack
export default (typeof IS_BROWSER !== 'undefined' && IS_BROWSER) ? window.__CONFIG__ : require('../../../server/utils/clientConfig').default; // eslint-disable-line
