import IS_PROD from './isProd';

export default function addAutomationProp(id) {
    // if (process.env.NODE_APP_INSTANCE === 'int' || process.env.NODE_APP_INSTANCE === 'qa' || process.env.NODE_APP_INSTANCE === 'perf') { // eslint-disable-line
    return { 'data-automation-id': id };
    // }

    // return { 'data-automation-id': null };
}

// export default (id) => ({ 'data-automation-id': (process.env.NODE_APP_INSTANCE === 'int' || process.env.NODE_APP_INSTANCE === 'qa' || process.env.NODE_APP_INSTANCE === 'perf') ? id : null })
