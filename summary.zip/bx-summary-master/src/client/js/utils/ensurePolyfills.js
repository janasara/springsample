export default (callback) => {
    if (!window.Promise || !window.fetch) {
        require.ensure([], (require) => {
            require('imports-loader?this=>window!es6-promise'); // eslint-disable-line
            require('isomorphic-fetch'); // eslint-disable-line
            callback();
        }, 'pollyfills');
    } else {
        callback();
    }
};
