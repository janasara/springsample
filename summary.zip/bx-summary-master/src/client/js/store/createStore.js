import { compose, createStore, applyMiddleware } from 'redux'
import thunk from 'redux-thunk'
import rootReducer from './../reducers/rootReducer'
import IS_CLIENT from './../utils/isBrowser'
import { analyticsReporter, crashReporter, errorReporter } from './middleware/newrelic'
import satellite from './middleware/satellite'
import optimizely from './middleware/optimizely'

const analyticsMiddleware = []
if (IS_CLIENT) {
  if (window.newrelic) {
    analyticsMiddleware.push(crashReporter, analyticsReporter, errorReporter)
  }
  if (window._satellite) {
    analyticsMiddleware.push(satellite)
  }
  if (window.optimizely) {
    analyticsMiddleware.push(optimizely)
  }
}

export default (initialState) => {
  const enhancer = compose(
      applyMiddleware(...[thunk, ...analyticsMiddleware]),
      IS_CLIENT && window.devToolsExtension ? window.devToolsExtension() : (f) => f
  )
  return createStore(rootReducer, initialState, enhancer)
}
