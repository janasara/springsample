import reporter from 'redux-reporter'

export default reporter(({ type, payload }) => {
  try {
    window.optimizely = window.optimizely || []
    window.optimizely.push(['trackEvent', type, payload])
  } catch (err) {}
}, ({ meta = {} }) => meta.experiments)
