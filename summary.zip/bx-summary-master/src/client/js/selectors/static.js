import filter from 'lodash/filter';

export const getTCData = state => state.terms.termsAndConditions;
export const getTermState = state => state.terms.termsState;
export const getVerificationToken = state => state.terms.termsAndConditions.verificationToken;
export const getExceptions = state => state.exceptions;
export const getFRs = state => state.financialreps;
export const getSpending = state => state.spending;
export const getNetworth = state => state.networth;
export const getIsaData = state => state.billing;
export const getActions = state => state.actions;
export const getMessages = state => state.messages.messages;
export const getDismissed = state => state.dismissed;
export const getDismissedSysMessages = state => state.messages.dismissedSysMessages;
export const getAccounts = state => state.accounts;
export const getInsurance = state => state.accounts.insuranceData;
export const getInsuranceFootnotes = state => state.footnotes.insuranceFootnotes;
export const getAccountsHasFetched = state => state.accounts.hasFetched;
export const getInvestments = state => state.accounts.investmentData;
export const getAnnuities = state => state.accounts.annuityData;
export const getIncomePlans = state => state.accounts.incomePlanData;
export const getAccessFunds = state => state.accounts.accessFundsData;
export const getAccessFundFootnotes = state => state.footnotes.accessFundFootnotes;
export const hasSVGFilter = state => !(state.meta.ua && state.meta.ua.ie);
export const getAllAccounts = state => state.accounts.insuranceData.concat(state.accounts.annuityData);

export const getLifeAccounts = state => state.accounts.lifeData;
export const getVarLifeAccounts = state => state.accounts.varLifeData;
export const getBusinessDIAccounts = state => state.accounts.bdiData;
export const getAnnuityData = state => state.accounts.annuityData;
export const getUlifeGroups = state => filter(state.groups.businessAccounts[0].entitlements,
  entitlement => entitlement.groupType === 'ulife')[0].groups;
export const getIncomePlanData = state => state.accounts.incomePlanData;
