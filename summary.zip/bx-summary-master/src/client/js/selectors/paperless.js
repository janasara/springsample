import { createSelector } from 'reselect';

const paperlessState = state => state.paperless;

export const paperlessInviteSelector = createSelector(
    paperlessState,
    paperless => !paperless.enrolled && paperless.isInvite && paperless.featureActive
);

export const paperlessTopDropSelector = createSelector(
    paperlessState,
    paperless => !paperless.isDismissed && !paperless.enrolled && paperless.featureActive
);
