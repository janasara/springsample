import React from 'react';
import ReactDom from 'react-dom';

import Root from './components/Root';
import checkSession from './utils/checkSession';
import loadWhatsnew from './utils/loadWhatsnew';

checkSession(() => {
    const createStore = require('./store/createStore').default; // eslint-disable-line
    const { fetchInitialState, fetchActions } = require('./actions/ApiActions'); // eslint-disable-line
    const persistStore = require('redux-persist').persistStore; // eslint-disable-line
    const ensurePolyfills = require('./utils/ensurePolyfills').default; // eslint-disable-line
    const store = createStore(window.__STATE__); // eslint-disable-line
    const state = store.getState(); // eslint-disable-line

    if (window.newrelic) {
      window.newrelic.setCustomAttribute('nmUniqueId', window.__STATE__.meta.uniqueId)
    }

    ReactDom.render(
        <Root store={store} />,
        document.getElementById('root')
    );

    ensurePolyfills(() => {
        persistStore(store,
            { whitelist: ['dismissed'] },
            (err, persistedState) => {
                store.dispatch(fetchActions(
                    state.meta.idHash,
                    persistedState.dismissed || []
                ));
            }
        );
        store.dispatch(fetchInitialState());
    });

    const whatsnewVersion = '2.3.0';
    loadWhatsnew(whatsnewVersion, () => {
        console.log(`Version ${whatsnewVersion}`);
    });
});
