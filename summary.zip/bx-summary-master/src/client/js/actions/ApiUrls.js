export const BILLING_MOCK_API_URL = '/summary/api/billing';
export const ACCOUNTS_API_URL = '/summary/api/accounts';
export const FR_SUMMARY_API_URL = '/summary/api/frsummary';
export const PAPERLESS_ENROLLMENT_API_URL = '/summary/api/paperless/enroll';
export const PAPERLESS_STATUS_API_URL = '/summary/api/paperless/status';
export const SUPPORT_HOURS_API_URL = '/summary/api/supporthours';
export const GROUPS_API_URL = '/summary/api/business/groups';
