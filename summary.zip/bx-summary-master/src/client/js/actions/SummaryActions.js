import ActionTypes from '../constants/ActionTypes';
import domains from '../utils/config';

export function setSessionStorageData(key, value) {
    if (window.sessionStorage) {
        sessionStorage.setItem(key, JSON.stringify(value));
    }
    const obj = {};
    obj[key] = value;

    return {
        type: ActionTypes.SET_SESSION_STORAGE,
        payload: obj
    };
}

export function getSessionStorageData(key) {
    let value = null;
    if (window.sessionStorage) {
        value = JSON.parse(sessionStorage.getItem(key));
    }

    if (value) {
        const obj = {};
        obj[key] = value;
        return {
            type: ActionTypes.SET_SESSION_STORAGE,
            payload: obj
        };
    }

    return {
        type: ActionTypes.NONE
    };
}

export function changeCurrentBalances(index) {
    return {
        type: ActionTypes.CHANGE_CURRENT_BALANCE,
        payload: {
            index
        }
    };
}

export function expandRow(rowId, cardName) {
    const type = ActionTypes.EXPAND_ROW;
    return {
        type,
        payload: rowId,
        meta: {
            experiments: {
                type,
                payload: {
                    rowId,
                    cardName
                }
            },
            analytics: {
                type,
                payload: {
                    rowId,
                    cardName
                }
            }
        }
    };
}

export function collapseRow(rowId, cardName) {
    const type = ActionTypes.COLLAPSE_ROW;
    return {
        type,
        payload: rowId,
        meta: {
            experiments: {
                type,
                payload: {
                    rowId,
                    cardName
                }
            },
            analytics: {
                type,
                payload: {
                    rowId,
                    cardName
                }
            }
        }
    };
}

export function setTermsState(payload) {
    return {
        type: ActionTypes.SET_TERMSTATE,
        payload
    };
}


export function dismissItem(id) {
    const type = ActionTypes.DISMISS_ITEM;
    return {
        type,
        payload: id,
        meta: {
            analytics: {
                type,
                payload: { id }
            }
        }
    };
}

export function dismissAction(actionId) {
    const type = ActionTypes.DISMISS_ACTION;
    return {
        type,
        payload: actionId,
        meta: {
            analytics: {
                type,
                payload: { actionId }
            }
        }
    };
}

export function actionCount(totalActions) {
    const type = ActionTypes.ACTION_COUNT;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type,
                payload: { totalActions }
            }
        }
    };
}

export function payNow() {
    const type = ActionTypes.PAY_NOW;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function addAccounts() {
    const type = ActionTypes.ADD_ACCOUNTS;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function networthAddAccounts(numOfLinkedAccts) {
    const type = ActionTypes.NETWORTH_ADD_ACCOUNTS;
    return {
        type,
        meta: {
            experiments: {
                type,
                payload: { numOfLinkedAccts }
            },
            analytics: {
                type,
                payload: { numOfLinkedAccts }
            }
        }
    };
}

export function networthFixAccounts(numOfLinkedAccts, numOfAcctErrors) {
    const type = ActionTypes.NETWORTH_FIX_ACCOUNTS;
    return {
        type,
        meta: {
            experiments: {
                type,
                payload: { numOfLinkedAccts,
                    numOfAcctErrors }
            },
            analytics: {
                type,
                payload: { numOfLinkedAccts,
                    numOfAcctErrors }
            }
        }
    };
}

export function goPaperless() {
    const type = ActionTypes.GO_PAPERLESS;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function manageLoan() {
    const type = ActionTypes.MANAGE_LOAN_ACTION;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function innerCircleJoin() {
    const type = ActionTypes.INNER_CIRCLE_ENGAGE;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function seeInvestmentDetails() {
    const type = ActionTypes.SEE_INVESTMENT_DETAILS;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function viewNMIS() {
    const type = ActionTypes.VIEW_NMIS;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function goToInvestments() {
    const type = ActionTypes.GOTO_INVESTMENTS;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function goToAnnuityIncomePlan() {
    const type = ActionTypes.GOTO_ANNUITYINCOMEPLAN;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}


export function goToInsurance() {
    const type = ActionTypes.GOTO_INSURANCE;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function goToBilling() {
    const type = ActionTypes.GOTO_BILLING;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}


export function selectAnnuityIncomeTab(annuityIncomeTabName) {
    const type = ActionTypes.SELECT_ANNUITY_INCOME_TAB;
    return {
        type,
        meta: {
            experiments: {
                type: annuityIncomeTabName
            },
            analytics: {
                type,
                payload: {
                    annuityIncomeTabName
                }
            }
        }
    };
}

export function selectSpendingTab(spendingTabName) {
    const type = ActionTypes.SELECT_SPENDING_TAB;
    return {
        type,
        meta: {
            experiments: {
                type: spendingTabName
            },
            analytics: {
                type,
                payload: {
                    spendingTabName
                }
            }
        }
    };
}

export function selectInsuranceTab(insuranceTabName) {
    const type = ActionTypes.SELECT_INSURANCE_TAB;
    return {
        type,
        meta: {
            experiments: {
                type: insuranceTabName
            },
            analytics: {
                type,
                payload: {
                    insuranceTabName
                }
            }
        }
    };
}

export function seeAllExpenses(spendingTabName) {
    const type = ActionTypes.SEE_ALL_EXPENSES;
    return {
        type,
        meta: {
            experiments: {
                type: spendingTabName
            },
            analytics: {
                type,
                payload: {
                    spendingTabName
                }
            }
        }
    };
}

export function seeCategoryAccts(spendingCategory) {
    const type = ActionTypes.VIEW_SPENDING_CATEGORY;
    return {
        type,
        meta: {
            experiments: {
                type: spendingCategory
            },
            analytics: {
                type,
                payload: {
                    spendingCategory
                }
            }
        }
    };
}


export function emailFr(numFrs, FrIndex) {
    const type = ActionTypes.EMAIL_FR;
    return {
        type,
        meta: {
            experiments: {
                type,
                payload: {
                    numFrs,
                    FrIndex
                }
            },
            analytics: {
                type,
                payload: {
                    numFrs,
                    FrIndex
                }
            }
        }
    };
}

export function visitFrTwitter(numFrs, FrIndex) {
    const type = ActionTypes.VISIT_FR_TWITTER;
    return {
        type,
        meta: {
            experiments: {
                type,
                payload: {
                    numFrs,
                    FrIndex
                }
            },
            analytics: {
                type,
                payload: {
                    numFrs,
                    FrIndex
                }
            }
        }
    };
}
export function visitFrFacebook(numFrs, FrIndex) {
    const type = ActionTypes.VISIT_FR_FACEBOOK;
    return {
        type,
        meta: {
            experiments: {
                type,
                payload: {
                    numFrs,
                    FrIndex
                }
            },
            analytics: {
                type,
                payload: {
                    numFrs,
                    FrIndex
                }
            }
        }
    };
}
export function visitFrLinkedin(numFrs, FrIndex) {
    const type = ActionTypes.VISIT_FR_LINKEDIN;
    return {
        type,
        meta: {
            experiments: {
                type,
                payload: {
                    numFrs,
                    FrIndex
                }
            },
            analytics: {
                type,
                payload: {
                    numFrs,
                    FrIndex
                }
            }
        }
    };
}

export function visitFrWebsite(numFrs, FrIndex) {
    const type = ActionTypes.VISIT_FR_WEBSITE;
    return {
        type,
        meta: {
            experiments: {
                type,
                payload: {
                    numFrs,
                    FrIndex
                }
            },
            analytics: {
                type,
                payload: {
                    numFrs,
                    FrIndex
                }
            }
        }
    };
}

export function isaViewDetails(isaType) {
    const type = ActionTypes.VIEW_ISA_DETAILS;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type,
                payload: {
                    isaType
                }
            }
        }
    };
}

export function isaLoanPayLink(isaType) {
    const type = ActionTypes.VIEW_ISA_LOAN;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type,
                payload: {
                    isaType
                }
            }
        }
    };
}

export function navigateIsas(navigation) {
    const type = ActionTypes.NAVIGATE_ISA;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type,
                payload: {
                    navigation
                }
            }
        }
    };
}

export function visitServiceCenter(numFrs) {
    const type = ActionTypes.VISIT_SERVICE_CENTER;
    return {
        type,
        meta: {
            experiments: {
                type,
                payload: {
                    numFrs
                }
            },
            analytics: {
                type,
                payload: {
                    numFrs
                }
            }
        }
    };
}

export function visitContact() {
    const type = ActionTypes.VISIT_CONTACT;
    return {
        type,
        meta: {
            analytics: {
                type
            }
        }
    };
}

export function connectNow() {
    const type = ActionTypes.CONNECT_NOW;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function reviewAccounts() {
    const type = ActionTypes.REVIEW_ACCOUNTS;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function engageCard(cardName) {
    const type = ActionTypes.ENGAGE_CARD;
    return {
        type,
        meta: {
            experiments: {
                type: `ENGAGE_${cardName}_CARD`
            },
            analytics: {
                type,
                payload: {
                    cardName
                }
            }
        }
    };
}


export function dismissSystemMessage() {
    const type = ActionTypes.DISMISS_SYSTEM_MESSAGE;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function selectSystemMessageContact() {
    const type = ActionTypes.SELECT_SYSTEM_MESSAGE_CONTACT;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function viewAnnuity(productType) {
    const type = ActionTypes.VIEW_ANNUITY;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type,
                payload: {
                    productType
                }
            }
        }
    };
}

// go paperless
export function openPaperlessModal() {
    const type = ActionTypes.OPEN_PAPERLESS_MODAL;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function closePaperlessModal() {
    const type = ActionTypes.CLOSE_PAPERLESS_MODAL;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function closeSuccessModal(e) {
    e.preventDefault();
    const type = ActionTypes.CLOSE_SUCCESS_MODAL;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function dismissOrRemind(cookieName, cookieValue) {
    const type = ActionTypes.DISMISS_OR_REMIND;
    const today = new Date();
    const expires = new Date(today.getTime() + (30 * 24 * 3600 * 1000)); // plus 30 days
    document.cookie = `${cookieName}=${cookieValue}; expires=${expires.toGMTString()}; path=/; domain=${domains.paperlessCookieDomain}`;

    return {
        payload: {
            cookieName,
            cookieValue
        },
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type
            }
        }
    };
}

export function viewIncomePlans(productType) {
    const type = ActionTypes.VIEW_INCOME_PLANS;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type,
                payload: {
                    productType
                }
            }
        }
    };
}

export function viewInvestment(productType) {
    const type = ActionTypes.VIEW_INVESTMENT;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type,
                payload: {
                    productType
                }
            }
        }
    };
}

export function viewInsurance(productType) {
    const type = ActionTypes.VIEW_INSURANCE;
    return {
        type,
        meta: {
            experiments: {
                type
            },
            analytics: {
                type,
                payload: {
                    productType
                }
            }
        }
    };
}
