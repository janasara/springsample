import types from '../constants/ActionTypes';
import config from '../utils/config';
import makeFetch from '../utils/makeFetch';
import {
    BILLING_MOCK_API_URL,
    ACCOUNTS_API_URL,
    FR_SUMMARY_API_URL,
    PAPERLESS_ENROLLMENT_API_URL,
    PAPERLESS_STATUS_API_URL,
    SUPPORT_HOURS_API_URL,
    GROUPS_API_URL
} from './ApiUrls';

const { accepttermsUrl, actionsUrl, billingUrl, footnotesUrl, messagesUrl, termsUrl } = config.clientCrossOriginUrls;

/* ACTION HELPERS */
function startAction(type) {
    return { type };
}

function successAction(type, json) {
    return { type, payload: json, meta: { receivedAt: Date.now() } };
}

function failureAction(type, error) {
    return { type, payload: error, error: true, meta: { receivedAt: Date.now() } };
}

/* ACTION CREATORS */
export function acceptTerms(verificationToken) {
    return (dispatch) => {
        dispatch(startAction(types.ACCEPT_TERMS_REQUEST));

        return makeFetch(accepttermsUrl, {
            method: 'post',
            credentials: 'include',
            headers: {
                'Accept': 'application/json', // eslint-disable-line
                'Content-Type': 'application/json',
                '__RequestVerificationToken': verificationToken, // eslint-disable-line
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(json => dispatch(successAction(types.ACCEPT_TERMS_SUCCESS, json)))
        .catch(error => dispatch(failureAction(types.ACCEPT_TERMS_FAILURE, new Error(`Accept Terms Error:${error.message}`))));
    };
}

export function enrollPaperless(payload) {
    return (dispatch) => {
        dispatch(startAction(types.PAPERLESS_ENROLL_REQUEST));
        return makeFetch(PAPERLESS_ENROLLMENT_API_URL, {
            body: JSON.stringify(payload),
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            method: 'post'
        })
        .then(json => dispatch(successAction(types.PAPERLESS_ENROLL_SUCCESS, json)))
        .catch(error => dispatch(failureAction(types.PAPERLESS_ENROLL_FAILURE, new Error(`Enroll Paperless Error:${error.message}`))));
    };
}

export function fetchActions(username, dismissed) {
    return (dispatch) => {
        dispatch(startAction(types.ACTIONS_REQUEST));

        dispatch(fetchNmcActions(username, dismissed));
    };
}

export function fetchAccounts(options = null) {
    return (dispatch) => {
        dispatch(startAction(types.ACCOUNTS_REQUEST));

        return makeFetch(ACCOUNTS_API_URL, options)
            .then(json => dispatch(successAction(types.ACCOUNTS_SUCCESS, json)))
            .catch(error => dispatch(failureAction(types.ACCOUNTS_FAILURE, new Error(`Accounts Fetch Error:${error.message}`))));
    };
}


export function fetchBilling(isa) {
    return (dispatch) => {
        dispatch(startAction(types.BILLING_REQUEST));
        if (isa) {
            return makeFetch(`${BILLING_MOCK_API_URL}?isa=${isa}`)
                .then(json => dispatch(successAction(types.BILLING_SUCCESS, json)))
                .catch(error => dispatch(failureAction(types.BILLING_FAILURE, new Error(`Billing Fetch Error:${error.message}`))));
        }

        return makeFetch(billingUrl)
            .then(json => dispatch(successAction(types.BILLING_SUCCESS, json)))
            .catch(error => dispatch(failureAction(types.BILLING_FAILURE, new Error(`Billing Fetch Error:${error.message}`))));
    };
}

export function fetchFinancialreps(options = null) {
    return (dispatch) => {
        dispatch(startAction(types.FINANCIALREPS_REQUEST));
        return makeFetch(FR_SUMMARY_API_URL, options)
            .then(json => dispatch(successAction(types.FINANCIALREPS_SUCCESS, json)))
            .catch(error => dispatch(failureAction(types.FINANCIALREPS_FAILURE, new Error(`FR Fetch Error:${error.message}`))));
    };
}

export function fetchFootnotes() {
    return (dispatch) => {
        dispatch(startAction(types.FOOTNOTES_REQUEST));

        return makeFetch(footnotesUrl)
            .then(json => dispatch(successAction(types.FOOTNOTES_SUCCESS, json)))
            .catch(error => dispatch(failureAction(types.FOOTNOTES_FAILURE, new Error(`Footnotes Fetch Error:${error.message}`))));
    };
}

export function fetchInitialState() {
    const isa = location.search.split('isa=')[1];

    return (dispatch) => { // keep slowest requests last, use blur loader
        dispatch(fetchTerms());
        dispatch(fetchMessages());
        dispatch(fetchFootnotes());
        dispatch(fetchBilling(isa));
    };
}

export function fetchMessages() {
    return (dispatch) => {
        dispatch(startAction(types.MESSAGES_REQUEST));

        return makeFetch(messagesUrl)
            .then(json => dispatch(successAction(types.MESSAGES_SUCCESS, json)))
            .catch(error => dispatch(failureAction(types.MESSAGES_FAILURE, new Error(`Messages Fetch Error:${error.message}`))));
    };
}

function fetchNmcActions(username, dismissed) {
    return (dispatch) => {
        makeFetch(actionsUrl)
            .then((actions) => {
                const items = (Object.prototype.toString.call(actions) === '[object Array]') ? actions : [];
                return {
                    actions: items,
                    dismissed,
                    username
                };
            })
            .then(json => dispatch(successAction(types.ACTIONS_SUCCESS, json)))
            .catch(error => dispatch(failureAction(types.ACTIONS_FAILURE, new Error(`NMC Action Error:${error.message}`))));
    };
}

// get the paperless preferences for the user
export function fetchPaperlessStatus(options = null) {
    return (dispatch) => {
        return makeFetch(PAPERLESS_STATUS_API_URL, options)
                .then((json) => {
                    // sweet, update the store
                    dispatch(successAction(types.PAPERLESS_STATUS_SUCCESS, json));
                })
                .catch((error) => {
                    dispatch(failureAction(types.PAPERLESS_STATUS_FAILURE, new Error(`Paperless Status Fetch Error:${error.message}`)));
            });
    };
}

export function fetchSupportHours(options = null) {
    return (dispatch) => {
        dispatch(startAction(types.HOURS_REQUEST));
        return makeFetch(SUPPORT_HOURS_API_URL, options)
            .then(json => dispatch(successAction(types.HOURS_SUCCESS, json)))
            .catch(error => dispatch(failureAction(types.HOURS_FAILURE, new Error(`Supporthours Fetch Error:${error.message}`))));
    };
}

export function fetchTerms() {
    return (dispatch) => {
        dispatch(startAction(types.TERMS_REQUEST));

        return makeFetch(termsUrl)
            .then(json => dispatch(successAction(types.TERMS_SUCCESS, json)))
            .catch(error => dispatch(failureAction(types.TERMS_FAILURE, new Error(`Terms Fetch Error:${error.message}`))));
    };
}

export function fetchGroups(options = null) {
    return (dispatch) => {
        dispatch(startAction(types.GROUPS_REQUEST));

        return makeFetch(GROUPS_API_URL, options)
            .then(json => dispatch(successAction(types.GROUPS_SUCCESS, json)))
            .catch(error => dispatch(failureAction(types.GROUPS_FAILURE, new Error(`Accounts Fetch Error:${error.message}`))));
    };
}
