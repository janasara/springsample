import React, { Component, PropTypes } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as SummaryActions from '../actions/SummaryActions';
import Actions from './Actions';
import Contact from './Contact';
import Messages from './Messages';
import Accounts from './Accounts';
import TermsAndConditions from './TermsAndConditions';
import IsaCard from './Billing';
import Exception from './Exception';
import Title from './Title';
import TopDrop from './TopDrop';
import { paperlessTopDropSelector } from '../selectors/paperless';

class App extends Component {

    componentDidMount() {
        this.props.getSessionStorageData('dismissedSysMessages');
        const banner = document.querySelector('.top-drop__banner');
        const invite = document.querySelector('.invite');
        if (banner) {
            setTimeout(() => {
                banner.classList.add('top-drop__banner--show');
            }, 1000);
        } else if (invite) {
            setTimeout(() => {
                invite.classList.add('show');
            }, 1000);
        }
    }

    render() {
        const { showPaperlessTopDrop } = this.props;
        return (
            <main>
                { showPaperlessTopDrop ? <TopDrop /> : null }
                <div className="grid-container">
                    <div className="row" id="summary-title"><Title businessName={this.props.businessContextName} /></div>
                    <div className="row" id="card-content">
                        <div className="large-12 columns">
                            <Exception />
                            <Messages />
                            <Actions />
                            <Accounts />
                            <IsaCard />
                            <Contact />
                            <TermsAndConditions />
                        </div>
                    </div>
                </div>
            </main>
        );
    }
}

const mapStateToProps = state => ({
    showPaperlessTopDrop: paperlessTopDropSelector(state),
    businessContextName: state.groups.businessAccounts[0].companyName
});

const mapDispatchToProps = dispatch => bindActionCreators(SummaryActions, dispatch);

App.propTypes = {
    getSessionStorageData: PropTypes.func,
    showPaperlessTopDrop: PropTypes.bool,
    businessContextName: PropTypes.string
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
