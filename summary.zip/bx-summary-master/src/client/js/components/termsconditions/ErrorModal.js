import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { setTermsState } from '../../actions/SummaryActions';
import config from '../../utils/config';

const NMC_URL = config.nmcDomain;

export class ErrorModal extends Component {

    exitTerms() {
        this.toggleExitTerms();
    }

    toggleExitTerms() {
        this.props.setTermsState({
            acceptedTerms: this.props.termsState.acceptedTerms,
            errorTerms: this.props.termsState.TCData ? this.props.termsState.TCData.err : null,
            exitTerms: !this.props.exitTerms,
            isTermsActive: this.props.termsState.isTermsActive,
            currentTerm: this.props.termsState.currentTerm
        });
    }

    exitConfirmModal() {
        window.location.href = `${NMC_URL}/logout`;
    }

    resetTermsAndConditions() {
        this.props.setTermsState({ errorTerms: false });
    }

    render() {
        return (
            <div>
                <div className="modal-overlay" />
                <div className="modal-container" id="error-modal">
                    <div className="modal medium">

                        <p>There was an error updating Terms Of Use. Please try accepting again and contact customer
                        service if the error continues.</p>

                        <div className="row">
                            <div className="column large-6" />
                            <div className="column large-6 terms-buttons text-right">
                                <button id="exit-terms" className="small button margin-right-small"
                                        onClick={this.exitConfirmModal.bind(this)}>
                                    Log out
                                </button>
                                <button id="view-terms" className="button secondary small"
                                    onClick={this.resetTermsAndConditions.bind(this)}>
                                    View the Terms of Use Again
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        termsState: state.terms.termsState
    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({
        setTermsState
    }, dispatch);
}

ErrorModal.propTypes = {
    acceptedTerms: PropTypes.bool,
    errorTerms: PropTypes.bool, // eslint-disable-line
    exitTerms: PropTypes.bool,
    isTermsActive: PropTypes.bool,
    currentTerm: PropTypes.number,
    setTermsState: PropTypes.func,
    termsState: PropTypes.object.isRequired
};

export default connect(mapStateToProps, mapDispatchToProps)(ErrorModal);
