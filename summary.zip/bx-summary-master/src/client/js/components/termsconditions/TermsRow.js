import React, { Component, PropTypes } from 'react';

export default class TermsRow extends Component {

    createMarkup(language) {
        return { __html: language };
    }

    render() {
        const { term, index, currentTerm } = this.props;
        const headerText = `${term.heading} (v${term.version.major}.${term.version.minor})`;

        if (currentTerm === index) {
            return (
                <div key={index}>
                    <h2><span className="icon icon-alert" /> {headerText} </h2>
                    <div dangerouslySetInnerHTML={this.createMarkup(term.language)} />
                </div>
            );
        } else if (index < currentTerm) {
            return (
                <div key={index}>
                    <h2><span className="icon-success icon" /> {headerText} </h2>
                </div>
            );
        }

        return (
            <div key={index}>
                <h2><span className="icon icon-alert" /> {headerText} </h2>
            </div>
        );
    }

}

TermsRow.propTypes = {
    term: PropTypes.any,
    index: PropTypes.number,
    currentTerm: PropTypes.number
};
