import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { setTermsState } from '../../actions/SummaryActions';
import config from '../../utils/config';

const NMC_URL = config.nmcDomain;

export class ConfirmModal extends Component {

    exitTerms() {
        this.toggleExitTerms();
    }

    toggleExitTerms() {
        this.props.setTermsState({
            acceptedTerms: this.props.termsState.acceptedTerms,
            errorTerms: this.props.termsState.TCData ? this.props.termsState.TCData.err : null,
            exitTerms: !this.props.exitTerms,
            isTermsActive: this.props.termsState.isTermsActive,
            currentTerm: this.props.termsState.currentTerm
        });
    }

    exitConfirmModal() {
        window.location.href = `${NMC_URL}/logout`;
    }

    render() {
        return (
            <div >
                <div className="modal-overlay" />

                <div className="modal-container" id="confirm-modal">
                    <div className="modal medium terms-conditions-update">
                        <p>You have not yet agreed to the updated Terms of Use. To exit without agreeing to the Terms of
                            Use, please log out.</p>
                        <p> You will be asked to review and agree to the Terms of Use the next time you log in.</p>
                        <div className="row button-group">
                            <div className="column large-6" />
                            <div className="column large-6 terms-buttons">
                                <button id="exit-terms" className="small button" onClick={this.exitConfirmModal.bind(this)}>Log out</button>
                                <button id="view-terms" className="button secondary small"
                                        onClick={this.toggleExitTerms.bind(this)}>View the Terms of Use Again
                                </button>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        termsState: state.terms.termsState
    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({
        setTermsState
    }, dispatch);
}

ConfirmModal.propTypes = {
    termsState: PropTypes.object,
    acceptedTerms: PropTypes.array,
    errorTerms: PropTypes.array, // eslint-disable-line
    currentTerm: PropTypes.number
};

export default connect(mapStateToProps, mapDispatchToProps)(ConfirmModal);
