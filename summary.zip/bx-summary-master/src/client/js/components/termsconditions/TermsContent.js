import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import TermsRow from './TermsRow';
import { acceptTerms } from '../../actions/ApiActions';
import { setTermsState } from '../../actions/SummaryActions';
import { getTermState } from '../../selectors/static';

export class TermsContent extends Component {
    acceptTerm() {
        const nextTerm = this.props.termsState.currentTerm + 1;
        this.props.setTermsState({
            acceptedTerms: this.props.termsState.acceptedTerms,
            errorTerms: this.props.termsState.TCData ? this.props.termsState.TCData.err : null,
            exitTerms: this.props.termsState.exitTerms,
            isTermsActive: this.props.termsState.isTermsActive,
            currentTerm: nextTerm
        });
        if (this.props.termsState.acceptedTerms.length === nextTerm) {
            this.exitCompletedTerms();
            this.props.acceptTerms(this.props.verificationToken);
        }
    }

    exitTerms() {
        this.toggleExitTerms();
    }

    toggleExitTerms() {
        this.props.setTermsState({
            acceptedTerms: this.props.termsState.acceptedTerms,
            errorTerms: this.props.termsState.TCData ? this.props.termsState.TCData.err : null,
            exitTerms: !this.props.exitTerms,
            isTermsActive: this.props.termsState.isTermsActive,
            currentTerm: this.props.termsState.currentTerm
        });
    }

    exitCompletedTerms() {
        document.body.classList.remove('modal-active');
        // document.getElementById('summary-title').setAttribute('aria-hidden', 'false');
        // document.getElementById('card-content').setAttribute('aria-hidden', 'false');
        // document.getElementById('sm-card-content').setAttribute('aria-hidden', 'false');
        // document.getElementById('modal-content').setAttribute('aria-hidden', 'true');
    }

    render() {
        const { TCData, currentTerm, acceptedTerms, termsState } = this.props; // eslint-disable-line
        const agree = 'agree';
        return (
            <div className="terms-conditions-update">
                <h1>Terms of Use</h1>
                <div id="terms-conditions-content">

                    <p>WE HAVE UPDATED OUR SITE’S TERMS OF USE.</p>
                    <p>Please review the updated terms of use and other agreements. If you agree, click “I Agree.” To
                        log into the site, you must agree to each set of terms.</p>
                    <p>
                        <span className="tac-note">Note: Your Preferences (Document Sharing, Information Sharing)
                            remain unchanged. You can review or update them anytime.</span>
                    </p>

                    <div className="terms-and-conditions" tabIndex="1">

                        {TCData.map((term, index) => <TermsRow term={term}
                                                                    index={index}
                                                                    currentTerm={currentTerm}
                                                                    key={index} />)}

                    </div>
                </div>
                <div className="row button-group">
                    <div className="large-8 medium-6 small-4 columns terms-counter-wrapper">
                        <span id="terms-acceptance-counter">
                            {currentTerm} of {acceptedTerms.length} Terms Accepted
                        </span>
                    </div>
                    <div className="large-4 medium-6 small-8 columns terms-buttons">
                        <button className="small button" onClick={this.acceptTerm.bind(this)} id="modal-button-validate"
                                ref={agree} tabIndex="1">I Agree
                        </button>
                        <button className="small secondary button" onClick={this.exitTerms.bind(this)}
                                id="modal-do-not-agree" tabIndex="1">I do not agree
                        </button>
                    </div>
                </div>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        termsState: getTermState(state)
    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({
        acceptTerms,
        setTermsState
    }, dispatch);
}

TermsContent.propTypes = {
    acceptTerms: PropTypes.any,
    verificationToken: PropTypes.string,
    exitTerms: PropTypes.bool,
    termsState: PropTypes.object,
    setTermsState: PropTypes.any,
    TCData: PropTypes.any,
    currentTerm: PropTypes.number,
    acceptedTerms: PropTypes.any
};

export default connect(mapStateToProps, mapDispatchToProps)(TermsContent);
