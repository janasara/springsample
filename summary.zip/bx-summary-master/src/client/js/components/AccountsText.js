import React from 'react';
import { compose } from 'redux';
import connectExperiment, { activate } from '../utils/experimentUtils'; // eslint-disable-line
// import { connect } from 'react-redux';

const AccountsText = ({ action, variant }) => {
    if (variant) {
        return (<span>Get a better understanding of your spending habits by connecting accounts.</span>);
    }
    return (<span dangerouslySetInnerHTML={{ __html: action.actionText }} />);
};

const enhancer = compose(
    connectExperiment('CX_SUMMARY_ACCOUNT_AGGREGATION_COPY')
);

export default enhancer(AccountsText);

AccountsText.propTypes = {
    action: React.PropTypes.object,
    variant: React.PropTypes.string
};
