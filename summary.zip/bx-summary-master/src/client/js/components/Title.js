import React, { PropTypes } from 'react';

const Title = ({ businessName }) => (
    <div className="column"><h1 className="page-title">{businessName} Summary</h1></div>
);

Title.propTypes = {
    businessName: PropTypes.string.isRequired
};

export default Title;
