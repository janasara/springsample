import React, { Component, PropTypes } from 'react';
import classNames from 'classnames';
import { connect } from 'react-redux';
import AccountsText from './AccountsText';
import { engageCard, dismissAction, goPaperless, addAccounts, payNow, manageLoan, actionCount } from '../actions/SummaryActions';
import { getActions, hasSVGFilter } from '../selectors/static';

export class Actions extends Component {

    shouldComponentUpdate(nextProps) {
        return this.props.actions !== nextProps.actions;
    }

    render() {
        const { actions, dismissAction, addAccounts, goPaperless, payNow, hasSVGFilter, engageCard, manageLoan, actionCount } = this.props;
        const { hasFetched, items } = actions;

        const hasContent = items.length > 0;
        const shouldMask = !hasFetched;
        const blurClasses = classNames({
            'blur-html': shouldMask && hasSVGFilter,
            'blur-text': shouldMask && !hasSVGFilter
        });

        if (hasContent) {
            // actionCount(items.length);
            return (
                <div id="actions-card" className="card" onClick={engageCard}>
                        <div className={classNames({ 'card-loader': !hasFetched })} />
                    <div className={blurClasses}>

                        <h2>Actions<span className="count-pill">{items.length}</span></h2>

                        {items.map((action, index) => {
                            const dismisslink = (action.actionId.indexOf('ISA') === -1) ? (

                                <button className="reset-button dismiss-link" title="Dismiss" aria-label="Close" onClick={(e) => {
                                    e.preventDefault();
                                    dismissAction(action.actionId);
                                }}><span className="icon icon-close" /></button>

                            ) : null;
                            return (

                                <div key={index} className="action-item">

                                    <div className="small-12 medium-9 column">
                                        <p>

                                            {(action.actionId.indexOf('ACCT-1') > -1) ?
                                                <AccountsText action={action} /> : <span dangerouslySetInnerHTML={{ __html: action.actionText }} />}
                                    </p>

                                    </div>
                                    <div className="small-12 medium-3 column text-center">
                                        <a href={action.href}
                                           onMouseDown={() => {
                                               if (action.actionId.indexOf('ACCT-') > -1) {
                                                   addAccounts();
                                               } else if (action.actionId.indexOf('ISA-') > -1) {
                                                   payNow();
                                               } else if (action.actionId.indexOf('PL-') > -1) {
                                                   goPaperless();
                                               } else if (action.actionId.indexOf('LOAN-') > -1) {
                                                   manageLoan();
                                               }
                                           }}
                                           className="button">
                                            {action.buttonText}
                                        </a>
                                        {dismisslink}
                                    </div>

                                </div>
                            );
                        })}
                    </div>
                </div>
            );
        }
        return null;
    }
}

Actions.propTypes = {
    actions: PropTypes.object.isRequired,
    dismissAction: React.PropTypes.func,
    hasSVGFilter: React.PropTypes.bool,
    addAccounts: React.PropTypes.func,
    goPaperless: React.PropTypes.func,
    payNow: React.PropTypes.func,
    engageCard: React.PropTypes.func,
    manageLoan: React.PropTypes.func,
    actionCount: React.PropTypes.func
};

const mapStateToProps = state => ({
    actions: getActions(state),
    hasSVGFilter: hasSVGFilter(state)
});

const mapDispatchToProps = dispatch => ({
    engageCard() {
        dispatch(engageCard('ACTIONS'));
    },
    dismissAction(actionId) {
        dispatch(dismissAction(actionId));
    },
    payNow() {
        dispatch(payNow());
    },
    goPaperless() {
        dispatch(goPaperless());
    },
    addAccounts() {
        dispatch(addAccounts());
    },
    manageLoan() {
        dispatch(manageLoan());
    },
    actionCount(total) {
        dispatch(actionCount(total));
    }
});
export default connect(mapStateToProps, mapDispatchToProps)(Actions);
