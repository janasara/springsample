import React, { Component, PropTypes } from 'react';
import isEmpty from 'lodash/isEmpty';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import TermsContent from './termsconditions/TermsContent';
import ConfirmModal from './termsconditions/ConfirmModal';
import ErrorModal from './termsconditions/ErrorModal';
import { acceptTerms } from '../actions/ApiActions';
import { setTermsState } from '../actions/SummaryActions';
import { getTCData, getTermState, getVerificationToken } from '../selectors/static';


export class TermsAndConditions extends Component {

    componentWillReceiveProps(nextProps) {
        if (!isEmpty(nextProps.TCData.data) && nextProps.TCData.data.length > 0) {
            if (nextProps.TCData.data !== this.props.TCData.data) {
                if (this.props.termsState.acceptedTerms.length === 0) this.initializeTerms(nextProps);
                if (!this.props.termsState.isTermsActive) this.showModal();
            }
        }
    }

    initializeTerms(nextProps) {
        const acceptedTerms = nextProps.TCData.data.map((term, index) => ({ termHead: term.Heading,
            accepted: false,
            id: index }));
        this.props.setTermsState({
            acceptedTerms,
            errorTerms: nextProps.TCData.err,
            exitTerms: false,
            isTermsActive: true,
            currentTerm: this.props.termsState.currentTerm === '' ? 0 : this.props.termsState.currentTerm
        });
    }

    showModal() {
        document.body.classList.add('modal-active');
        document.body.classList.add('page-container');
    }

    renderConfirmModal() {
        return (
            <ConfirmModal exitTerms={this.props.termsState.exitTerms} errorTerms={this.props.termsState.errorTerms} />);
    }


    renderErrorModal() {
        return (
            <ErrorModal exitTerms={this.props.termsState.exitTerms} errorTerms={this.props.termsState.errorTerms} />);
    }

    render() {
        const { TCData, termsState, acceptTerms } = this.props;
        const { data } = TCData;

        if (!isEmpty(data) && data.length > 0) {
            if (termsState.errorTerms) return this.renderErrorModal();
            if (termsState.exitTerms) return this.renderConfirmModal();

            return (
                <div id="terms-modal">
                    <div className="modal-overlay" tabIndex="-1" />

                    <div className="modal-container">
                        <div className="modal large" aria-hidden="false" id="modal-content">
                            <TermsContent TCData={data} acceptTerms={acceptTerms}
                                          currentTerm={termsState.currentTerm}
                                          acceptedTerms={termsState.acceptedTerms} />
                        </div>

                    </div>
                </div>
            );
        }
        return null;
    }
}

TermsAndConditions.propTypes = {
    termsState: PropTypes.object, // eslint-disable-line
    setTermsState: PropTypes.any,
    TCData: PropTypes.object,
    acceptTerms: PropTypes.func
};

function mapStateToProps(state) {
    return {
        TCData: getTCData(state),
        termsState: getTermState(state),
        verificationToken: getVerificationToken(state)
    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({
        acceptTerms,
        setTermsState
    }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(TermsAndConditions);
