import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import classnames from 'classnames';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import { openPaperlessModal, dismissOrRemind, setSessionStorageData } from '../actions/SummaryActions';
import { paperlessInviteSelector } from '../selectors/paperless';
import TopDropModal from './topdrop/TopDropModal';


class TopDrop extends Component {

    render() {
        const { dismissOrRemind, openPaperlessModal, paperless, setSessionStorageData, inviteCode } = this.props;
        // are we handling the invite? short circuit johnny 5
        if ( paperless.inviteCode ) {
            return (
                <div className='top-drop invite'>
                    <TopDropModal />
                </div>
            );
        }

    // otherwise, show the original top drop
        return (
        <div className='top-drop'>
          <div className="top-drop__banner">
            <div className="top-drop__icon-wrapper">
                <div className="top-drop__icon__paperless">
                    <svg height="23px" width="22px" version="1.1" viewBox="0 -1 22 23">
                      <defs>
                      <polygon id="path-1"
                          points="0.000319354838 21.4079871 21.4051232 21.4079871 21.4051232 -5.46195097e-05 0.000319354838 -5.46195097e-05 0.000319354838 21.4079871" />
                      </defs>
                      <g id="Page-1" fill="none" stroke="none" strokeWidth="1">
                      <mask id="mask-2" fill="white">
                      <polygon
                          points="0.000319354838 21.4079871 21.4051232 21.4079871 21.4051232 -5.46195097e-05 0.000319354838 -5.46195097e-05 0.000319354838 21.4079871" />
                      </mask>
                      <g id="Clip-2" />
                      <path id="Fill-1"
                          d="M14.9864,15.4540774 C13.1745935,17.2658839 10.6914323,18.882529 7.25091613,16.1637548 L12.2598194,11.1548516 C12.8140774,10.6005935 12.8140774,9.70214194 12.2598194,9.14788387 C11.7055613,8.59362581 10.8071097,8.59362581 10.2528516,9.14788387 L5.24465806,14.1560774 C4.07510968,12.6735613 3.59891613,11.2393032 3.85298065,9.88169032 C4.06162581,8.75685161 4.74930323,7.62562581 5.95291613,6.42130323 C8.30975484,4.06517419 14.8245935,3.16246452 18.4943355,2.91336774 C18.2459484,6.5824 17.342529,13.0972387 14.9864,15.4540774 M20.9895613,0.418141935 C20.7156258,0.143496774 20.3735613,-0.0218580645 19.9541419,0.00227096774 C18.7405935,0.0292387097 7.97691613,0.384077419 3.94594839,4.41433548 C2.32362581,6.03665806 1.37975484,7.65472258 1.06181935,9.36149677 C0.633883871,11.6565935 1.36414194,13.9445935 3.2227871,16.1779484 L0.416012903,18.9854323 C-0.138245161,19.5389806 -0.138245161,20.4381419 0.416012903,20.9924 C0.692787097,21.2691742 1.05614194,21.408271 1.41949677,21.408271 C1.78285161,21.408271 2.14549677,21.2691742 2.42298065,20.9924 L5.2340129,18.1806581 C7.05007742,19.6823355 8.91510968,20.444529 10.7666581,20.444529 C12.8949806,20.444529 15.0034323,19.4509806 16.9933677,17.4617548 C21.0243355,13.4300774 21.3777548,2.66710968 21.4047226,1.45285161 C21.4139484,1.06536774 21.2634968,0.691367742 20.9895613,0.418141935"
                          fill="#FFFFFF" />
                      </g>
                    </svg>
                </div>
                <div className="top-drop__text">
                  <h4 className="top-drop__title">Choose <strong>eDelivery.</strong><span className="hide">Less paperwork, more trees.</span></h4>
                </div>
            </div>
            <div className="top-drop__cta">
              <button className="top-drop__open-modal" onClick={openPaperlessModal}>Go Paperless <span className="top-drop__caret" /></button>
            </div>
            <button className="top-drop__dismiss__banner" onClick={(e) => {
                e.preventDefault();
                dismissOrRemind('goPaperless', 'isDismissed');
                this.props.setSessionStorageData('dismissedTopDropBanner', true);
            }} />
          </div>
            <ReactCSSTransitionGroup
            transitionName="paperless"
            transitionEnterTimeout={500}
            transitionLeaveTimeout={300}>
              { paperless.paperlessModalIsOpen ? <TopDropModal /> : null }
            </ReactCSSTransitionGroup>
        </div>
        );
    }
}

TopDrop.propTypes = {
    openPaperlessModal: PropTypes.func,
    setSessionStorageData: PropTypes.func,
    dismissOrRemind: PropTypes.func,
    paperless: PropTypes.object,
    inviteCode: PropTypes.bool
};

const mapStateToProps = state => ({
    paperless: state.paperless,
    inviteCode: paperlessInviteSelector(state)
});

const mapDispatchToProps = dispatch => ({
    openPaperlessModal() {
        dispatch(openPaperlessModal());
    },
    dismissOrRemind(key, val) {
        dispatch(dismissOrRemind(key, val));
    },
    setSessionStorageData(key, val) {
        dispatch(setSessionStorageData(key, val));
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(TopDrop);
