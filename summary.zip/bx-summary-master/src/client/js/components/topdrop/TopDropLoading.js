import React, { PropTypes } from 'react';

function TopDropLoading() {
    return (
        <div className="top-drop-loading">
            <div className="top-drop-modal-wrapper__title">
                <span className="top-drop-modal-wrapper__title__icon" />
                <h3>eDelivery</h3>
            </div>
          <span className="loading-indicator" />
        </div>
    );
}

export default TopDropLoading;
