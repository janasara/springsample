import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { closeSuccessModal } from '../../actions/SummaryActions';

function TopDropSuccess({ closeSuccessModal }) {
    return (
        <div>
          <div className="top-drop-success__container">
              <span className="icon icon-success" />
              <h3>We have successfully gone paperless</h3>
              <p>To change your eDelivery preferences in the future visit the preference page.</p>
              <button type="button" className="button dull" onClick={closeSuccessModal}>Close</button>
          </div>
        </div>
    );
}

TopDropSuccess.propTypes = {
    paperless: PropTypes.object
};

const mapStateToProps = state => ({
    paperless: state.paperless
});

const mapDispatchToProps = dispatch => bindActionCreators({
    closeSuccessModal
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(TopDropSuccess);
