import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { closePaperlessModal, dismissOrRemind, setSessionStorageData, closeSuccessModal } from '../../actions/SummaryActions';
import { enrollPaperless } from '../../actions/ApiActions';
import TopDropEnrollForm from './TopDropEnrollForm';
import TopDropLoading from './TopDropLoading';
import TopDropSuccess  from './TopDropSuccess';
import TopDropFail  from './TopDropFail';

export class TopDropModal extends Component {

    componentDidMount() {
        document.body.style.overflow = 'hidden';
    }

    componentWillUnmount() {
        document.body.style.overflow = '';
    }

    chooseModalContent(paperlessState) {
        if (paperlessState.isLoading) {
            return (<TopDropLoading />);
        } else if (paperlessState.showPaperlessTermsSuccess) {
            return (<TopDropSuccess />);
        } else if (paperlessState.showPaperlessTermsFailed) {
            return (<TopDropFail />);
        } else {
            return (<TopDropEnrollForm />);
        }
    }

    render() {
        const { enrollPaperless, closePaperlessModal, closeSuccessModal, dismissOrRemind, paperless, setSessionStorageData } = this.props;

        return (
            <div className='top-drop-modal-wrapper'>
                <div className="topdrop-modal-container">
                    <div className="modal medium">
                        {this.chooseModalContent(paperless)}
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => ({
    paperless: state.paperless
});

function mapDispatchToProps(dispatch) {
    return bindActionCreators({
        closePaperlessModal,
        dismissOrRemind,
        enrollPaperless,
        setSessionStorageData,
        closeSuccessModal
    }, dispatch);
}

TopDropModal.propTypes = {
    enrollPaperlessInvite: PropTypes.func,
    closePaperlessModal: PropTypes.func,
    closeSuccessModal: PropTypes.func,
    dismissOrRemind: PropTypes.func,
    enrollPaperless: PropTypes.func,
    paperless: PropTypes.object,
    setSessionStorageData: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(TopDropModal);
