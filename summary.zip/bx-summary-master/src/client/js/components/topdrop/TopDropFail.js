import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { enrollPaperless } from '../../actions/ApiActions';
import { dismissOrRemind, setSessionStorageData } from '../../actions/SummaryActions';

function TopDropFail({ paperless, dismissOrRemind, enrollPaperless, setSessionStorageData }) {
const { termsMajorVersion, termsMinorVersion, inviteCode } = paperless;
    return (
        <form action="">
          <div className="top-drop-fail__container">
              <span className="icon icon-fail" />
              <h3>Something went wrong</h3>
              <p>Looks like there was an error setting your preferences. Please try again.</p>

              <div className="row collapse">
                <button className="consent-container__try-again" type="button" onClick={(e) => {
                    e.preventDefault();
                    enrollPaperless({ termsMajorVersion, termsMinorVersion, inviteCode });
                }}>Try Again</button>
                <button className="consent-container__remind-me-later" onClick={(e) => {
                    e.preventDefault();
                    dismissOrRemind('goPaperless', 'isDismissed');
                    setSessionStorageData('dismissedTopDropBanner', true);
                }}> Remind me Later </button>
              </div>
              </div>
          </form>
    );
}

TopDropFail.propTypes = {
    paperless: PropTypes.object
};

const mapStateToProps = state => ({
    paperless: state.paperless
});

const mapDispatchToProps = dispatch => bindActionCreators({
    dismissOrRemind,
    enrollPaperless,
    setSessionStorageData
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(TopDropFail);
