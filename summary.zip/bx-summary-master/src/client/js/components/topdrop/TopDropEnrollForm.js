import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { enrollPaperless } from '../../actions/ApiActions';
import { closePaperlessModal, dismissOrRemind, setSessionStorageData, closeSuccessModal } from '../../actions/SummaryActions';

function TopDropEnrollForm({ paperless, closePaperlessModal, closeSuccessModal, dismissOrRemind, enrollPaperless, setSessionStorageData }) {
    const { termsLanguage, termsMajorVersion, termsMinorVersion, inviteCode } = paperless;
    return (
        <div>
            { !paperless.inviteCode ? <button className="consent-container__modal-close" onClick={closePaperlessModal}>
                <span className="icon icon-close" />
            </button> : null }
            <div className="top-drop-modal-wrapper__title">
                <span className="top-drop-modal-wrapper__title__icon" />
                <h3>eDelivery</h3>
            </div>
            <div className="paperless-terms-content">
                <span dangerouslySetInnerHTML={{ __html: termsLanguage }} />
                <span className="fade"></span>
            </div>

            <form action="">
                <div className="consent-container">
                    <span className="consent-container__icon" />
                    eDelivery
                    <p>By clicking here you consent to receive documents available for eDelivery electronically.</p>
                </div>
                <div className="row collapse">
                    <button className="consent-container__agree" type="button" onClick={(e) => {
                        e.preventDefault();
                        enrollPaperless({ termsMajorVersion, termsMinorVersion, inviteCode });
                    }}> I Agree </button>
                    <button className="consent-container__remind-me-later" onClick={(e) => {
                        e.preventDefault();
                        dismissOrRemind('goPaperless', 'isDismissed');
                        setSessionStorageData('dismissedTopDropBanner', true);
                    }}> Remind me Later </button>
                </div>
            </form>
        </div>
    );
}

TopDropEnrollForm.propTypes = {
    paperless: PropTypes.object
};

const mapStateToProps = state => ({
    paperless: state.paperless
});

const mapDispatchToProps = dispatch => bindActionCreators({
    closePaperlessModal,
    dismissOrRemind,
    enrollPaperless,
    setSessionStorageData,
    closeSuccessModal
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(TopDropEnrollForm);
