import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import classNames from 'classnames';
import config from '../utils/config';
import Carousel from './Carousel';
import { emailFr, visitFrWebsite, engageCard, visitServiceCenter, visitContact,
         visitFrFacebook, visitFrTwitter, visitFrLinkedin } from '../actions/SummaryActions';
import { getFRs, hasSVGFilter } from '../selectors/static';

const PLAN_URL = config.planDomain;

const ServiceContent = ({ visitServCenter, supporthours }) => (
    <div className="fr-service-content">
        <h2>
            <a onMouseDown={visitServCenter} href="https://www.northwesternmutual.com/customer-service-center"
                target="_blank" rel="noopener noreferrer">
                Customer Service Center
            </a>
        </h2>
        <div className="fr-service-content__message">
            <p>
                Visit <a onMouseDown={visitServCenter} href="https://www.northwesternmutual.com/customer-service-center"
                         target="_blank" rel="noopener noreferrer">
                Customer Service</a> for answers to common service questions.
            </p>
            <p>
                {supporthours.telephone}<br />
                {supporthours.hours}
            </p>
        </div>
    </div>
);

ServiceContent.propTypes = {
    visitServCenter: PropTypes.func,
    supporthours: PropTypes.object
};

const linkedinSvg = <svg id='Layer_1' className='social-media-svg' data-name='Layer 1' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 60'><title>linkedin</title><path d='M30,2.33A27.67,27.67,0,1,0,57.67,30,27.67,27.67,0,0,0,30,2.33ZM22.88,43.22H16.5V24h6.38v19.2ZM19.69,21.4h0a3.33,3.33,0,1,1,.08-6.64A3.33,3.33,0,1,1,19.69,21.4ZM45.9,43.22H39.52V32.95c0-2.58-.92-4.34-3.23-4.34A3.49,3.49,0,0,0,33,30.94a4.37,4.37,0,0,0-.21,1.56V43.22H26.41s0.09-17.4,0-19.2H32.8v2.72a6.34,6.34,0,0,1,5.75-3.17c4.2,0,7.35,2.74,7.35,8.64v11Z' /></svg>

const facebookSvg = <svg id='Layer_1' className='social-media-svg' data-name='Layer 1' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 60'><title>facebook</title><path d='M30,2.33A27.67,27.67,0,1,0,57.67,30,27.67,27.67,0,0,0,30,2.33ZM37,30H32.43V46.36h-6.8V30H22.4V24.23h3.23V20.5c0-2.67,1.27-6.86,6.86-6.86l5,0v5.61H33.87a1.38,1.38,0,0,0-1.44,1.57v3.4H37.6Z' /></svg>

const twitterSvg = <svg id='Layer_1' className='social-media-svg' data-name='Layer 1' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 60'><title>twitter</title><path d='M30,2.33A27.67,27.67,0,1,0,57.67,30,27.67,27.67,0,0,0,30,2.33ZM43.58,23q0,0.45,0,.91c0,9.26-7,19.94-19.94,19.94a19.82,19.82,0,0,1-10.74-3.15,14.15,14.15,0,0,0,10.37-2.9A7,7,0,0,1,16.75,33a7,7,0,0,0,3.16-.12A7,7,0,0,1,14.3,26s0-.06,0-0.09a7,7,0,0,0,3.17.88A7,7,0,0,1,15.3,17.4a19.89,19.89,0,0,0,14.44,7.32,7,7,0,0,1,11.94-6.39,14,14,0,0,0,4.45-1.7,7,7,0,0,1-3.08,3.88,14,14,0,0,0,4-1.1A14.22,14.22,0,0,1,43.58,23Z' /></svg>

const SocialMediaLink = ({ url, action, svg }) => (
    <li>
      <a onMouseDown={action} target="_blank" href={url}>
        {svg}
      </a>
    </li>
);

const Fr = ({ fr, visitFrWebsite, emailFr, visitFrFacebook, visitFrTwitter, visitFrLinkedin }) => {
    let phone = `(${fr.telephoneAreaCode}) ${fr.telephoneNumber}-${fr.telephoneUniqueNumber}`;
    phone = fr.telephoneExtension ? `${phone} x${fr.telephoneExtension}` : phone;
    const addressString = `${fr.city}, ${fr.state} ${fr.zip}-${fr.zipPlus4}`;
    return (
        <div className="row fr-panel-content">
            <div className="large-5 column fr-picture">
                <img className="padding-top-tiny" src={fr.personalImageUrl}
                     alt="" />
            </div>
            <div className="large-7 column">
                <ul className="fr-info fr-address">
                    <li><strong>{fr.personalName}</strong></li>
                    <li><strong>{fr.professionalDesignations}</strong></li>
                    <li className="fr-info__functions"><strong>{fr.jobFunctions}</strong></li>
                    <li className="fr-info__phone">{phone}</li>
                    <li>
                        <span>{fr.addressBlock1}</span>
                        {fr.addressBlock2 && fr.addressBlock3 ? <span>{fr.addressBlock2}</span> : addressString}
                        {fr.addressBlock3 ? <span>{addressString}</span> : null}
                    </li>
                    <li>
                        <a href={`http://${fr.websiteUrl}`} onMouseDown={visitFrWebsite} target="_blank" rel="noopener noreferrer">{fr.websiteUrl}</a>
                    </li>
                    <li>
                        <ul className="fr-socialmedia">
                            { fr.linkedinUrl && <SocialMediaLink url={fr.linkedinUrl} action={visitFrLinkedin} svg={linkedinSvg} />}
                            { fr.facebookUrl && <SocialMediaLink url={fr.facebookUrl} action={visitFrFacebook} svg={facebookSvg} /> }
                            { fr.twitterUrl && <SocialMediaLink url={fr.twitterUrl} action={visitFrTwitter} svg={twitterSvg} /> }
                        </ul>
                    </li>
                    <li><a className="button fr-email" href={`mailto:${fr.email}`} onMouseDown={emailFr}>Email Me</a></li>
                </ul>
            </div>
        </div>
    );
};

Fr.propTypes = {
    fr: PropTypes.object
};

const EmptyFr = ( {findRepUrl} ) => (
    <div className="row fr-panel-content">
      <h3 className="column fr-panel-header subheader">Your Financial Representative is no longer available</h3>
      <p>But don't worry, let's find you someone new.</p>
      <a className="button" target="_blank" href="https://www.northwesternmutual.com/financial-professional-locator">Find A New Rep</a>
    </div>
)

const Counter = ({ index, numItems }) => {
    if (numItems > 1) {
        return (
            <span className="fr-count">{index + 1} of {numItems}</span>
        );
    }
    return null;
};

Counter.propTypes = {
    index: PropTypes.number,
    numItems: PropTypes.number
};


class Contact extends Component {

    render() {
        const { financialreps, hasSVGFilter, engageCard, emailFr, visitFrWebsite, visitServiceCenter, visitContact, supporthours, visitFrTwitter, visitFrFacebook, visitFrLinkedin } = this.props;
        const { hasError, hasFetched, items } = financialreps;
        const hasContent = items.length > 0;
        const shouldMask = !hasFetched;
        const blurClasses = classNames({
            'blur-html': shouldMask && hasSVGFilter,
            'blur-text': shouldMask && !hasSVGFilter
        });

        if (!hasError) {
            return (
                <div className="fr-panel card" onClick={() => { engageCard(items.length); }}>
                    <div className={classNames({ 'card-loader': !hasFetched })} />
                    <div className={blurClasses}>
                        <div className="row">
                            <div className="medium-6 column fr-vertical">
                                <div className="row">
                                    <h2 className="column small-8 fr-panel-header">
                                        <a className="left" href={`${PLAN_URL}/contact`} onMouseDown={visitContact}>Your Financial Team</a>
                                    </h2>
                                </div>
                                {hasContent
                                 ? <Carousel>
                                     {items.map((fr, i) => (<Fr fr={fr} key={i}
                                         visitFrFacebook={() =>
                                             { visitFrFacebook(items.length, i); }
                                         }
                                         visitFrTwitter={() =>
                                             { visitFrTwitter(items.length, i); }
                                         }
                                         visitFrLinkedin={() =>
                                             { visitFrLinkedin(items.length, i); }
                                         }
                                         visitFrWebsite={() =>
                                             { visitFrWebsite(items.length, i); }
                                         }
                                         emailFr={() =>
                                           { emailFr(items.length, i); }
                                         } />))}
                                 </Carousel>
                                 : <EmptyFr />
                                }
                            </div>
                            <div className="medium-6 column">
                                <ServiceContent
                                    supporthours={supporthours}
                                    visitServCenter={() => {
                                        visitServiceCenter(items.length);
                                    }} />
                            </div>
                        </div>
                    </div>
                </div>
            );
        }
        return null;
    }
}

Contact.propTypes = {
    financialreps: PropTypes.object,
    hasSVGFilter: PropTypes.bool,
    engageCard: PropTypes.func,
    supporthours: PropTypes.object
};

const mapStateToProps = state => ({
    financialreps: getFRs(state),
    hasSVGFilter: hasSVGFilter(state),
    supporthours: state.supporthours
});

const mapDispatchToProps = dispatch => ({
    emailFr(numFrs, index) {
        dispatch(emailFr(numFrs, index));
    },
    visitFrFacebook(numFrs, index) {
        dispatch(visitFrFacebook(numFrs, index));
    },
    visitFrTwitter(numFrs, index) {
        dispatch(visitFrTwitter(numFrs, index));
    },
    visitFrLinkedin(numFrs, index) {
        dispatch(visitFrLinkedin(numFrs, index));
    },
    visitFrWebsite(numFrs, index) {
        dispatch(visitFrWebsite(numFrs, index));
    },
    engageCard() {
        dispatch(engageCard('CONTACT'));
    },
    visitServiceCenter(numFrs) {
        dispatch(visitServiceCenter(numFrs));
    },
    visitContact() {
        dispatch(visitContact());
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(Contact);
