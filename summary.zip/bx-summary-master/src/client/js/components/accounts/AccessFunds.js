import React, { PropTypes } from 'react';

const ChildRow = ({ product }) => {
    const href = `/account-detail/type/${product.accountTypeCde}/account/${product.accountNumberMasked}`;
    return (
        <tr className="solo-row">
            <td>
                <p className="insured-label">{product.ownerName}</p>
                  <a
                    data-metrics-linkname="summary:annuities-income-card:annuities-detail-link"
                    className="policy-link"
                    href={href}>
                    {product.accountNumberMasked}
                </a>
            </td>
            <td className="text-right">{product.value}</td>
        </tr>
    );
};

const renderFootnotes = (footnotes) => {
    return footnotes.map((footnote, index) => <i key={index} className="footnote">- {footnote.messageTxt}</i>);
};

const AccessFunds = ({ accessFundsData, footnotes }) => {
    const renderedFootnotes = (footnotes && footnotes.length > 0) ? renderFootnotes(footnotes) : null;
    if (accessFundsData && accessFundsData.length > 0) {
        return (<div className="access-fund">
            <table className="table">
                <thead>
                <tr>
                    <th>Owner</th>
                    <th className="text-right">Total Account Balance</th>
                </tr>
                </thead>
                <tbody>
                {
                    accessFundsData.map((item, index) =>
                        <ChildRow key={index} product={item} />
                    )
                }
                </tbody>
            </table>
            {renderedFootnotes}
        </div>);
    }

    return null;
};

export default AccessFunds;

AccessFunds.propTypes = {
    accessFundsData: PropTypes.array.isRequired,
    footnotes: PropTypes.array
};

AccessFunds.defaultProps = {
    footnotes: []
};
