import React, { PropTypes } from 'react';

const ChildRow = ({ product }) => {
    const href = `/account-detail/type/${product.accountTypeCde}/account/${product.accountNumberMasked}`;
    return (
        <tr className="solo-row">
            <td>
                <a className="policy-link"
                   href={href}
                   data-metrics-linkname="summary:disability-card:disability-detail-link">
                    {product.accountTypeDetail} - {product.accountNumberMasked}
                </a>
            </td>
            <td className="text-right"> {product.benefit || 'N/A'} </td>
            <td className="text-right"> {product.annualizedPremium || 'N/A'} </td>
        </tr>
    );
};

const Disability = ({ diData }) => {
    if (diData && diData.length > 0) {
        return (<div className="disability">
            <table id="disability-table" className="disability-table table">
                <thead>
                <tr>
                    <th>Name/Number</th>
                    <th className="text-right">Benefit</th>
                    <th className="text-right">Annualized Premium</th>
                </tr>
                </thead>
                <tbody>
                {
                    diData.map((item, index) =>
                        <ChildRow key={index} product={item} />
                    )
                }
                </tbody>
            </table>
        </div>);
    }

    return null;
};

Disability.propTypes = {
    diData: PropTypes.array.isRequired
};

export default Disability;
