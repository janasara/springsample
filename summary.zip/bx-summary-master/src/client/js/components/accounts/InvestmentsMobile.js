import React, { Component, PropTypes } from 'react';

export default class InvestmentsMobile extends Component {
    processProducts(data) {
        return data.map((product, index) => (
          <li key={index} className="top-row">
            <ul>
              <div className="title">
                <p className="insured-name">
                  <strong>
                    {product.ownerName}
                  </strong>
                  <span className="role text-dark-grey"> Owner</span>
                </p>
                <span className="policy-link">
                  <a data-metrics-linkname="summary:insurance-card-mobile:detail-link">
                    {product.accountTypeDetail} - {product.accountNumberMasked}
                  </a>
                </span>
              </div>
            </ul>
            <ul className="keyval-chart">
              <li>
                <span className="key">
                  Market Value
                </span>
                <span className="val">
                  {product.value || '$0.00'}
                </span>
              </li>
            </ul>
          </li>
        ));
    }

    render() {
        const { data, title } = this.props;

        if (data && data.length > 0) {
            const products = this.processProducts(data);
            return (
                <div className="investment-card card">
                    <h3>{title}</h3>

                    <ul className="investment-list">
                        {products}
                    </ul>
                </div>
            );
        }

        return null;
    }
}

InvestmentsMobile.propTypes = {
    data: PropTypes.array.isRequired,
    title: PropTypes.string.isRequired
};
