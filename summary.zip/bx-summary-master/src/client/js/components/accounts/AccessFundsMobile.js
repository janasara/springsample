import React, { PropTypes } from 'react';

const processProducts = (data) => {
    return data.map((account, itemIndex) => {
        const key = `${itemIndex}`;

        return (
            <li key={key} className="top-row">
                <div>
                    <span className="access-funds-account-owner-name">{account.ownerName}</span>
                    <strong className="text-dark-grey">Owner</strong>
                </div>

                <div className="access-funds-account-num">{account.accountNumberMasked}</div>

                <ul className="keyval-chart">
                    <li>
                        <span className="key">Total Account Balance</span>
                        <span className="val">{account.value}</span>
                    </li>
                </ul>
            </li>
        );
    });
};


const AccessFundsMobile = ({ data, title }) => {
    if (data && data.length > 0) {
        const products = processProducts(data);
        return (
            <div className="access-funds-card card">
                <h3>{title}</h3>

                <ul className="access-funds-list">
                    {products}
                </ul>
            </div>
        );
    }

    return null;
};

export default AccessFundsMobile;

AccessFundsMobile.propTypes = {
    data: PropTypes.array.isRequired,
    title: PropTypes.string.isRequired
};
