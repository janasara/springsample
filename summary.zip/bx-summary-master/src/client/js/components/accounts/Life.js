import React, { PropTypes } from 'react';

const ChildRow = ({ product }) => {
    const href = `/account-detail/type/${product.accountTypeCde}/account/${product.accountNumberMasked}`;
    return (
        <tr className={'solo-row'}>
            <td>
                <a className="policy-link"
                   href={href}
                   data-metrics-linkname="summary:life-card:life-detail-link">
                    {product.accountTypeDetail} - {product.accountNumberMasked}
                </a>
            </td>
            <td className="text-right"> {product.benefit || 'N/A'} </td>
            <td className="text-right"> {product.value || 'N/A'}</td>
            <td className="text-right"> {product.annualizedPremium || 'N/A'} </td>
        </tr>
    );
};

const Life = ({ lifeData }) => {
    if (lifeData && lifeData.length > 0) {
        return (<div className="life">
            <table id="life-table" className="life-table table">
                <thead>
                <tr>
                    <th>Name/Number</th>
                    <th className="text-right">Net Death Benefit</th>
                    <th className="text-right">Net Cash Value</th>
                    <th className="text-right">Annualized Premium</th>
                </tr>
                </thead>
                <tbody>
                {
                    lifeData.map((item, index) =>
                        <ChildRow key={index} product={item} />
                    )
                }
                </tbody>
            </table>
        </div>);
    }

    return null;
};

Life.propTypes = {
    lifeData: PropTypes.array.isRequired
};

export default Life;
