import React from 'react';


export default function getTitle(insured, label = 'Insured') {
    const href = `/account-detail/type/${insured.accountTypeCde}/account/${insured.accountNumberMasked}`;

    return (
        <div className="title">
            <p className="insured-name">
                <strong>{insured.insuredName}</strong>
                <span className="text-dark-grey">{label}</span>
            </p>
            <p className="policy-link">
                <a href={href} data-metrics-linkname="summary:insurance-card-mobile:life-card-detail-link">
                    {insured.accountTypeCde === 3 ? '' : `${insured.accountTypeDetail} - `} {insured.accountNumberMasked}
                </a>
            </p>
        </div>
    );
}
