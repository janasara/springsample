import React, { PropTypes } from 'react';
import ULife from './ULife';
import Life from './Life';
import Disability from './Disability';
import Annuity from './Annuity';
import AccessFunds from './AccessFunds';
import TabPanels from './../TabPanels';
import TabPanel from './../TabPanel';
import Investments from './Investments';
import { selectInsuranceTab } from './../../actions/SummaryActions';

const AccountTabs = ({ ulifeData, lifeData, bdiData, annuityData, investmentData,
  varLifeData, incomePlanData, accessFundsData, accessFundFootnotes }) => {
    const tabs = [];

    if (lifeData && lifeData.length > 0) {
        tabs.push(
            <TabPanel key={0} name={`Life (${lifeData.length})`}>
                <Life key={0} lifeData={lifeData} />
            </TabPanel>
        );
    }
    if (bdiData && bdiData.length > 0) {
        tabs.push(
            <TabPanel key={1} name={`Disability (${bdiData.length})`}>
                <Disability key={1} diData={bdiData} />
            </TabPanel>
        );
    }
    if (varLifeData && varLifeData.length > 0) {
        tabs.push(
            <TabPanel key={2} name={`Variable Life (${varLifeData.length})`}>
                <Life key={2} lifeData={varLifeData} />
            </TabPanel>
        );
    }
    if (ulifeData && ulifeData.length > 0) {
        tabs.push(
            <TabPanel key={3} name={`Universal Life (${ulifeData.length})`}>
                <ULife key={3} ulifeData={ulifeData} />
            </TabPanel>
        );
    }
    if (annuityData && annuityData.length > 0) {
        tabs.push(
            <TabPanel key={4} name={`Annuities (${annuityData.length})`}>
                <Annuity key={4} annuityData={annuityData} />
            </TabPanel>
        );
    }
    if (investmentData && investmentData.length > 0) {
        tabs.push(
            <TabPanel key={5} name={`Investments (${investmentData.length})`}>
                <Investments key={5} investmentData={investmentData} />
            </TabPanel>
        );
    }
    if (incomePlanData && incomePlanData.length > 0) {
        tabs.push(
            <TabPanel key={6} name={`Income Plans (${incomePlanData.length})`}>
                <Annuity key={6} annuityData={incomePlanData} />
            </TabPanel>
        );
    }
    if (accessFundsData && accessFundsData.length > 0) {
        tabs.push(
            <TabPanel key={7} name={`Access Funds (${accessFundsData.length})`}>
                <AccessFunds key={7} accessFundsData={accessFundsData} footnotes={accessFundFootnotes} />
            </TabPanel>
        );
    }

    return <TabPanels action={selectInsuranceTab}>{tabs}</TabPanels>;
};

AccountTabs.propTypes = {
    ulifeData: PropTypes.array.isRequired,
    lifeData: PropTypes.array.isRequired,
    bdiData: PropTypes.array.isRequired,
    annuityData: PropTypes.array.isRequired,
    investmentData: PropTypes.array.isRequired,
    varLifeData: PropTypes.array.isRequired,
    incomePlanData: PropTypes.array.isRequired,
    accessFundsData: PropTypes.array.isRequired,
    accessFundFootnotes: PropTypes.array
};

AccountTabs.defaultProps = {
    accessFundFootnotes: []
};

export default AccountTabs;
