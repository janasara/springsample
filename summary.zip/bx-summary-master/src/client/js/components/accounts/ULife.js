import React, { PropTypes } from 'react';

const ChildRow = ({ group }) => {
    const href = `/groupdetail/${group.groupNumberMasked}`;
    return (
        <tr className={'solo-row'}>
            <td>{group.groupName} - <a href={href}>{group.groupNumberMasked}</a>
              <br />
              <span className="policy-count-text text-dark-grey"> {group.policyCount > 1 && `${group.policyCount} Policies`}</span>
            </td>
            <td className="text-right">{group.netDeathBenefit || 'N/A'}</td>
            <td className="text-right">{group.contractFundInvestedAssetsValue || 'N/A'}</td>
            <td className="text-right">{group.cashSurrenderValue || 'N/A'}</td>
            <td className="text-right">{group.costBasisValue || 'N/A'}</td>
        </tr>
    );
};

const ULife = ({ ulifeData }) => {
    if (ulifeData && ulifeData.length > 0) {
        return (<div className="group">
            <table id="ulife-group-table" className="group-table table">
                <thead>
                  <tr>
                      <th>Name/Number</th>
                      <th className="text-right">Net Death Benefit</th>
                      <th className="text-right">Contract Fund Value /<br />Invested Assets Value</th>
                      <th className="text-right">Net Cash Surrender Value</th>
                      <th className="text-right">Net Cost Basis</th>
                  </tr>
                </thead>
                <tbody>
                {
                    ulifeData.map((item, index) =>
                        <ChildRow key={index} group={item} />
                    )
                }
                </tbody>
            </table>
        </div>);
    }

    return null;
};

ULife.propTypes = {
    ulifeData: PropTypes.array.isRequired
};

export default ULife;
