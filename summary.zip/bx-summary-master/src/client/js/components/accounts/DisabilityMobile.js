import React, { Component, PropTypes } from 'react';
import getTitle from './helpers';

export default class DIMobile extends Component {
    processProducts(data) {
        return data.map((product, index) => (
            <li key={index} className="top-row" data-subrow-id={product.parentKey}>

                { getTitle(product) }

                <ul className="keyval-chart">
                    <li>
                        <span className="key">Group Name/Number</span>
                        <span className="val">{product.ownerName}</span>
                    </li>
                    <li>
                        <span className="key">Benefit</span>
                        <span className="val">{product.benefit || 'N/A'}</span>
                    </li>
                    <li>
                        <span className="key">Annualized Premium</span>
                        <span className="val">{product.annualizedPremium || 'N/A'}</span>
                    </li>
                </ul>
            </li>
        ));
    }

    render() {
        const { data } = this.props;
        const products = this.processProducts(data);

        if (data && data.length > 0) {
            return (
                <div className="disability-card card">
                    <h3>{this.props.title}</h3>

                    <ul className="di-list">
                        {products}
                    </ul>

                </div>
            );
        }

        return null;
    }
}

DIMobile.propTypes = {
    data: PropTypes.array.isRequired,
    title: PropTypes.string
};
