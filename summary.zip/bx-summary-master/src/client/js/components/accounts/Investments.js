import React, { PropTypes } from 'react';

const ChildRow = ({ product }) => {
    const href = `/account-detail/type/${product.accountTypeCde}/account/${product.accountNumberMasked}`;

    return (
        <tr className={'solo-row'}>
            <td>
                <span>{product.ownerName}</span>
                <br />
                <a className="policy-link"
                   href={href}
                   data-metrics-linkname="summary:investment-card:detail-link">
                   <span className="policy-label">
                       {product.accountNumberMasked}
                   </span>
                </a>
            </td>
            <td>{product.accountTypeDetail}</td>
            <td className="text-right">{product.value ? product.value : '$0.00'} </td>
            <td className="text-right">{product.valueAsOfDate}</td>
        </tr>
    );
};

const Investments = ({ investmentData }) => {
    if (investmentData && investmentData.length > 0) {
        return (<div className="investment">
            <table id="investment-table" className="investment-table table">
                <thead>
                <tr>
                    <th>Owner</th>
                    <th>Account Type</th>
                    <th className="text-right">Market Value</th>
                    <th className="text-right">As Of</th>
                </tr>
                </thead>
                <tbody>
                {
                    investmentData.map((item, index) =>
                        <ChildRow key={index} product={item} />
                    )
                }
                </tbody>
            </table>
        </div>);
    }

    return null;
};

Investments.propTypes = {
    investmentData: PropTypes.array.isRequired
};

export default Investments;
