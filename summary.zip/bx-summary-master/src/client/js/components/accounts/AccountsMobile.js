import React, { PropTypes } from 'react';

import LifeMobile from './LifeMobile';
import DIMobile from './DisabilityMobile';
import AnnuityMobile from './AnnuityMobile';
import InvestmentsMobile from './InvestmentsMobile';
import AccessFundsMobile from './AccessFundsMobile';

const AccountsMobile = ({ lifeData, varLifeData, bdiData, annuityData, investmentData, accessFundsData }) => (
    <div className="accounts-mobile">

        <h2 className="accounts-mobile-title">
            <span className="small">Northwestern Mutual</span>
            Insurance, Annuities & Investment
        </h2>

        <LifeMobile key={0} data={lifeData} title="Life" />
        <LifeMobile key={1} data={varLifeData} title="Variable Life" />
        <DIMobile key={2} data={bdiData} title="Disability" />
        <AnnuityMobile key={3} data={annuityData} title="Annuities" />
        <InvestmentsMobile key={4} data={investmentData} title="Investments" />
        <AccessFundsMobile key={5} data={accessFundsData} title="Access Funds" />
    </div>
);

AccountsMobile.propTypes = {
    lifeData: PropTypes.array.isRequired,
    varLifeData: PropTypes.array.isRequired,
    bdiData: PropTypes.array.isRequired,
    annuityData: PropTypes.array.isRequired,
    investmentData: PropTypes.array.isRequired,
    accessFundsData: PropTypes.array.isRequired
};

export default AccountsMobile;
