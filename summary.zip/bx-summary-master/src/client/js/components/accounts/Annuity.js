import React, { PropTypes } from 'react';

const ChildRow = ({ product }) => {
    const href = `/account-detail/type/${product.accountTypeCde}/account/${product.accountNumberMasked}`;
    return (
        <tr className="solo-row">
            <td>
                <p className="insured-label">{product.ownerName}</p>
                  <a
                    data-metrics-linkname="summary:annuities-income-card:annuities-detail-link"
                    className="policy-link"
                    href={href}>
                    {product.accountType} - {product.accountNumberMasked}
                </a>
            </td>
            <td> {product.accountTypeDetail} </td>
            <td> {product.value || 'N/A'} </td>
            <td> {product.valueAsOfDate} </td>
        </tr>
    );
};

const Annuity = ({ annuityData }) => {
    if (annuityData && annuityData.length > 0) {
        return (<div className="annuity">
            <table className="table">
                <thead>
                <tr>
                    <th>Owner</th>
                    <th>Account Type</th>
                    <th>Total Value</th>
                    <th>As Of</th>
                </tr>
                </thead>
                <tbody>
                {
                    annuityData.map((item, index) =>
                        <ChildRow key={index} product={item} />
                    )
                }
                </tbody>
            </table>
        </div>);
    }

    return null;
};

export default Annuity;

Annuity.propTypes = {
    annuityData: PropTypes.array.isRequired
};
