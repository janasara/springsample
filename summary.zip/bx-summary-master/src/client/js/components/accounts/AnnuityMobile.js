import React, { Component, PropTypes } from 'react';

export default class AnnuityMobile extends Component {
    getTitle(insured) {
        // const footNotes = (insured.footnotes && insured.footnotes.length > 0) ? insured.footnotes.join(', ') : '';
        const href = `/account-detail/type/${insured.accountTypeCde}/account/${insured.accountNumberMasked}`;
        const analyticsLink = 'summary:annuities-income-card-mobile:annuities-detail-link';

        return (
                <div className="title">
                    <p className="insured-name">
                        <strong>{insured.ownerName}</strong>
                        <span className="text-dark-grey">Owner</span>
                    </p>
                    <p className="policy-link">
                        <a href={href} data-metrics-linkname={analyticsLink}>
                            {insured.accountType} - {insured.accountNumberMasked}
                        </a>

                    </p>
                </div>
        );
    }

    processProducts(data) {
        return data.map((product, index) => {
            const title = this.getTitle(product);

            return (
                <li key={index} className="top-row" data-subrow-id={product.parentKey}>

                    {title}

                    <ul className="keyval-chart">
                        <li>
                            <span className="key">Account Type</span>
                            <span className="val">{product.accountTypeDetail}</span>
                        </li>
                        <li>
                            <span className="key">Value</span>
                            <span className="val">{product.value}</span>
                        </li>
                        <li>
                            <span className="key">As of Date</span>
                            <span className="val">{product.valueAsOfDate}</span>
                        </li>
                    </ul>
                </li>
            );
        });
    }

    render() {
        const { data } = this.props;

        if (data && data.length > 0) {
            const products = this.processProducts(data);

            return (
                <div className="annuity-card card">
                    <h3>Annuities</h3>

                    <ul className="annuity-list">
                        {products}
                    </ul>

                </div>
            );
        }

        return (<div />);
    }
}

AnnuityMobile.propTypes = {
    data: PropTypes.array.isRequired
};
