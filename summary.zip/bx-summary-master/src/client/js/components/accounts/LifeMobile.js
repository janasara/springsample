import React, { Component, PropTypes } from 'react';
import getTitle from './helpers';

export default class LifeMobile extends Component {
    processProducts(data) {
        return data.map((product, index) => (
            <li key={index} className="top-row">

                { getTitle(product) }

                <ul className="keyval-chart">
                    <li>
                        <span className="key">Owner</span>
                        <span className="val">{product.ownerName}</span>
                    </li>
                    <li>
                        <span className="key">Net Death Benefit</span>
                        <span className="val">{product.benefit || 'N/A'}</span>
                    </li>
                    <li>
                        <span className="key">Net Cash Value</span>
                        <span className="val">{product.value || 'N/A'}</span>
                    </li>
                    <li>
                        <span className="key">Annualized Premium</span>
                        <span className="val">{product.annualizedPremium || 'N/A'}</span>
                    </li>
                </ul>
            </li>
        ));
    }

    render() {
        const { data, title } = this.props;

        if (data && data.length > 0) {
            const products = this.processProducts(data);
            return (
                <div className="life-card card">
                    <h3>{title}</h3>

                    <ul className="life-list">
                        {products}
                    </ul>
                </div>
            );
        }

        return null;
    }
}

LifeMobile.propTypes = {
    data: PropTypes.array.isRequired,
    title: PropTypes.string.isRequired
};
