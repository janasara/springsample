import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import isEmpty from 'lodash/isEmpty';
import MediaQuery from 'react-responsive';
import mediaQueries from '../utils/mediaQueries';
import AccountTabs from './accounts/AccountTabs';
import AccountsMobile from './accounts/AccountsMobile';
import { getAccountsHasFetched, getInsuranceFootnotes, getInvestments, getLifeAccounts,
  getVarLifeAccounts, getBusinessDIAccounts, getAnnuityData, getUlifeGroups, getIncomePlanData,
  getAccessFunds, getAccessFundFootnotes } from '../selectors/static';

export class Accounts extends Component {
    // TODO: Check on updating of component - has impact on Footnotes
    /* shouldComponentUpdate(nextProps) {
        return this.props.data !== nextProps.data;
    } */

    render() {
        const { hasFetched } = this.props;
        const hasContent = !isEmpty(this.props.lifeData) || !isEmpty(this.props.bdiData) || !isEmpty(this.props.varLifeData) ||
                            !isEmpty(this.props.ulifeData) || !isEmpty(this.props.annuityData) || !isEmpty(this.props.investmentData) ||
                            !isEmpty(this.props.incomePlanData) || !isEmpty(this.props.accessFundsData);
        if (hasContent && hasFetched) {
            return (
                <div className="group-card card">
                  <h2><a href={'/groups'}>Insurance, Annuities & Investment</a></h2>
                    <MediaQuery query={mediaQueries.$desktopAndPrint} component="div">
                        <AccountTabs {...this.props} />
                    </MediaQuery>
                    <MediaQuery query={mediaQueries.$mobileAndNotPrint} component="div">
                        <AccountsMobile {...this.props} />
                    </MediaQuery>
                </div>
            );
        }

        return null;
    }
}

Accounts.propTypes = {
    ulifeData: PropTypes.array.isRequired,
    investmentData: PropTypes.array.isRequired,
    hasFetched: PropTypes.bool,
    lifeData: PropTypes.array.isRequired,
    varLifeData: PropTypes.array.isRequired,
    annuityData: PropTypes.array.isRequired,
    bdiData: PropTypes.array.isRequired,
    incomePlanData: PropTypes.array.isRequired,
    accessFundsData: PropTypes.array.isRequired,
    accessFundFootnotes: PropTypes.array
};

Accounts.defaultProps = {
    hasFetched: false,
    accessFundFootnotes: []
};

const mapStateToProps = state => ({
    ulifeData: getUlifeGroups(state),
    investmentData: getInvestments(state),
    lifeData: getLifeAccounts(state),
    varLifeData: getVarLifeAccounts(state),
    bdiData: getBusinessDIAccounts(state),
    annuityData: getAnnuityData(state),
    incomePlanData: getIncomePlanData(state),
    accessFundsData: getAccessFunds(state),
    accessFundFootnotes: getAccessFundFootnotes(state),
    hasFetched: state.groups.hasFetched && getAccountsHasFetched(state)
});

export default connect(mapStateToProps)(Accounts);
