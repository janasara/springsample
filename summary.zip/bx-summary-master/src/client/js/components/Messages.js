import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { dismissItem, engageCard, dismissSystemMessage, setSessionStorageData, getSessionStorageData } from '../actions/SummaryActions';
import { getMessages, getDismissedSysMessages, getDismissed } from '../selectors/static';
import _includes from 'lodash/includes';

export class Messages extends Component {

    componentDidMount() {
        getSessionStorageData('dismissedSysMessages');
    }

    shouldComponentUpdate(nextProps) {
        return this.props !== nextProps;
    }

    handleClick(e) {
        e.preventDefault();
        dismissSystemMessage();
        this.props.setSessionStorageData('dismissedSysMessages', true);
    }

    render() {
        const { idHash, dismissItem, messages, dismissed, engageCard, dismissedSysMessages } = this.props;
        const isLoaded = messages.length > 0;

        if (isLoaded && !messages.error) {
            const messagesTemplate = messages.map((message, index) => {
                if (message.displayLevel) {
                    if (message.displayLevel === 2) {
                        if (!dismissedSysMessages) {
                            return (
                                <div key={index} className={`card message level-${message.messageLevel}`}>
                                  <div className="message__container">
                                    <div className="message__content">
                                      <span className="message__icon message__icon--notification" />
                                        <p className="message__text">
                                          <strong>Important Notice</strong><br />
                                          <span dangerouslySetInnerHTML={{ __html: message.messageTxt }} />
                                        </p>
                                      </div>
                                      <button className="message__button reset-button">
                                        <span className="message__icon message__icon--close dismiss-sys-msg" title="Dismiss" onClick={this.handleClick.bind(this)} />
                                      </button>
                                    </div>
                                </div>
                            );
                        }

                        return null;
                    }
                    if(!_includes(dismissed, idHash + message.messageCode)){
                      return (
                          <div key={index} className={`card message level-${message.messageLevel}`}>
                              <div className="message__container">
                                <div className="message__content">
                                  <span className="message__icon message__icon--alert" />
                                  <p className="message__text" dangerouslySetInnerHTML={{ __html: message.messageTxt }} />
                                </div>
                                {(message.messageCode && message.messageCode === 'AnyRestriction') ? <button className="message__button reset-button">
                                  <span className="message__icon message__icon--close" title="Dismiss" onClick={(e) => {
                                    e.preventDefault()
                                    dismissItem(idHash + message.messageCode || 'no_code')
                                  }} />
                                </button> : null}
                              </div>
                          </div>
                      );
                    }
                    return null;
                }

                return (
                    <div key={index} className={`card message level-'${message.messageLevel}`}>
                      <div className="message__container">
                        <div className="message__content">
                          <span className="message__icon message__icon--fail" />
                          <p className="message__text" dangerouslySetInnerHTML={{ __html: message.messageTxt }} />
                        </div>
                      </div>
                    </div>
                );
            }, this);

            return (
                <div onClick={engageCard}>{messagesTemplate}</div>
            );
        }

        return null;
    }
}

Messages.propTypes = {
    messages: PropTypes.array.isRequired,
    dismissedSysMessages: PropTypes.bool,
    dismissed: PropTypes.array,
    engageCard: PropTypes.func,
    setSessionStorageData: PropTypes.func,
    idHash: PropTypes.string
};

const mapStateToProps = state => ({
    messages: getMessages(state),
    dismissedSysMessages: getDismissedSysMessages(state),
    dismissed: getDismissed(state),
    idHash: state.meta.idHash
});

const mapDispatchToProps = dispatch => ({
    engageCard() {
        dispatch(engageCard('MESSAGES'));
    },
    dismissItem(id) {
        dispatch(dismissItem(id));
    },
    dismissSystemMessage() {
        dispatch(dismissSystemMessage());
    },
    setSessionStorageData(key, val) {
        dispatch(setSessionStorageData(key, val));
    }
});
export default connect(mapStateToProps, mapDispatchToProps)(Messages);
