/* eslint-disable */
import React, { Component, PropTypes } from 'react';
import Carousel from 'nuka-carousel';

const Decorators = [{
    component: class LeftArrow extends Component {
        render() {
            return (
                <button value="previous" type="button" aria-label="previous-button" className="reset-button fr-previous icon icon-caret-left"
                    style={this.styleArrow(this.props.slideCount === 1)}
                    onClick={this.props.previousSlide} />
            );
        }
        shouldComponentUpdate() { return false; }
        styleArrow(disabled) { return { display: disabled ? 'none' : 'block' }; }
    },
    position: 'CenterLeft',
    style: {
        top: '30%'
    }
},
    {
        component: class RightArrow extends Component {
            render() {
                return (
                <button value="next" type="button" aria-label="next-button" className="reset-button fr-next icon icon-caret-right"
                    style={this.styleArrow(this.props.slideCount === 1)}
                    onClick={this.props.nextSlide} />
                );
            }
            shouldComponentUpdate() { return false; }
            styleArrow(disabled) { return { display: disabled ? 'none' : 'block' }; }
    },
        position: 'CenterRight',
        style: {
            top: '30%'
        }
    },
    {
        component: class Counter extends Component {
            render() {
                return (
                <h2 className="column small-4 text-right" data-active-id={`id-${this.props.currentSlide + 1}`} aria-live="polite"
                    style={this.styleArrow(this.props.slideCount === 1)} >
                <span className="fr-count">{this.props.currentSlide + 1} of {this.props.slideCount}</span>
                </h2>
                );
            }
            shouldComponentUpdate(nextProps) { return this.props.currentSlide !== nextProps.currentSlide; }
            styleArrow(disabled) { return { display: disabled ? 'none' : 'block' }; }
   },
        position: 'TopRight',
        style: {
            top: '-40px'
        }
    }
];

export default ({ children }) => (
    <Carousel wrapAround={children.length > 1 ? true : false} decorators={Decorators}>{children}</Carousel>
);
