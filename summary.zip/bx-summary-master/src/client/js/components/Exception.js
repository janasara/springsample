import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { getExceptions } from '../selectors/static';

class Exception extends Component {

    shouldComponentUpdate(nextProps) {
        return this.props.exceptions.length !== nextProps.exceptions.length;
    }

    render() {
        const { exceptions } = this.props;
        if (exceptions.length > 0) {
            const messagesTemplate = exceptions.map((message, index) => <li key={index} dangerouslySetInnerHTML={{ __html: message }} />);
            return (
                    <div className="card">
                        <div className="message__container">
                            <div className="message__content">
                                <span className="message__icon message__icon--fail" />
                                <div className="message__text">
                                    <ul className="message--exception">{messagesTemplate}</ul>
                                </div>
                            </div>
                        </div>
                    </div>
            );
        }
        return null;
    }
}

Exception.propTypes = {
    exceptions: PropTypes.array.isRequired
};

const mapStateToProps = state => ({
    exceptions: getExceptions(state)
});

export default connect(mapStateToProps)(Exception);
