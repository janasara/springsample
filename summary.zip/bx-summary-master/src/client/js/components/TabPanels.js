import React, { Children, Component, PropTypes } from 'react';
import classNames from 'classnames';
import { connect } from 'react-redux';

class TabPanels extends Component {

    constructor(props) {
        super(props);

        this.state = {
            activeTabIndex: 0
        };
    }

    setActiveTab(index) {
        this.setState({ activeTabIndex: index });
    }

    renderTabs(children, onTabClick) {
        const tabs = children.map((child, index) => {
            const { name } = child.props;
            const id = name.replace(/ /g, '');
            const panelId = `panel${id}` || 'panelId';
            const tabId = `tab${id}` || 'tabId';
            const active = index === this.state.activeTabIndex;
            const classes = classNames('tab-title', { active });
            const href = `#${encodeURIComponent(name)}`;
            const onClick = (event) => {
                event.preventDefault();
                this.setActiveTab(index);
                onTabClick(name);
            };

            return (
                <li key={index} className={classes} role="tab"
                    aria-controls={panelId}
                    id={tabId} aria-selected={active}>
                    <a href={href} onClick={onClick}>{name}</a>
                </li>
            );
        });

        return <ul className="tabs" role="tablist">{tabs}</ul>;
    }

    renderContent(children) {
        return children.map((child, index) =>
                                React.cloneElement(child, { active: index === this.state.activeTabIndex }));
    }

    render() {
        const { dispatch, action } = this.props;
        const children = Children.toArray(this.props.children);
        const onTabClick = (tabName) => { dispatch(action(tabName)); };
        const tabs = this.renderTabs(children, onTabClick);
        const content = this.renderContent(children);
        return (
            <div className="TabPanels">
                {tabs}
                {content}
            </div>
        );
    }
}

TabPanels.propTypes = {
    dispatch: PropTypes.func,
    children: PropTypes.any,
    action: PropTypes.func
};


export default connect()(TabPanels);
