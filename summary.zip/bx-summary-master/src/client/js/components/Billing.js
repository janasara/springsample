import React, { Component } from 'react';
import classNames from 'classnames';
import { connect } from 'react-redux';
import Navigation from './billing/shared/Navigation';
import Header from './billing/shared/Header';
/* special case cards */
import NoISA from './billing/NoISA';
import OnlineIneligible from './billing/OnlineIneligible';

/* premium/loan/annuity shared card */
import DirectOrRecurring from './billing/shared/DirectOrRecurring';

/* annuity cards */
import AnnuityDirectScheduled from './billing/annuity/AnnuityDirectScheduled';
import AnnuityRecurring from './billing/annuity/AnnuityRecurring';
import AnnuityRecurringScheduled from './billing/annuity/AnnuityRecurringScheduled';
import AnnuityDirect from './billing/annuity/AnnuityDirect';

/* loan cards */
import LoanPaymentZeroDue from './billing/loan/LoanPaymentZeroDue';

/* premium cards */
import PremiumDirectPastDue from './billing/premium/PremiumDirectPastDue';
import PremiumDirectSplitPayment from './billing/premium/PremiumDirectSplitPayment';
import PremiumDirectSplitPaymentPastDue from './billing/premium/PremiumDirectSplitPaymentPastDue';
import PremiumDirectMonthlyPastDue from './billing/premium/PremiumDirectMonthlyPastDue';

/* payment cards */
import PaymentAdditionalDue from './billing/payment/PaymentAdditionalDue';
import PaymentScheduled from './billing/payment/PaymentScheduled';
import PaymentZeroDue from './billing/payment/PaymentZeroDue';

import { engageCard, goToBilling } from '../actions/SummaryActions';
import { getIsaData, hasSVGFilter } from '../selectors/static';
import addAutomationProp from '../utils/addAutomationProp';

class Billing extends Component {
    constructor(props) {
        super(props);
        this.state = {
            activeIndex: 0
        };
    }

    navigate(event) {
        const activeIndex = Number(event.target.getAttribute('data-navigate'));
        this.setState({ activeIndex });
    }

    renderNavigation(billingDetailsData, render) {
        if (render) {
            const navigationgOptions = {
                countText: `${this.state.activeIndex + 1} of ${billingDetailsData.length}`,
                nextIndex: (this.state.activeIndex + 1) % billingDetailsData.length,
                prevIndex: this.state.activeIndex === 0 ? (billingDetailsData.length - 1) : this.state.activeIndex - 1,
                onClick: this.navigate.bind(this)
            };

            return (
                <Navigation options={navigationgOptions} />
            );
        }

        return null;
    }


    renderHeader(isaNumber, goToBilling) {
        return (
            <Header isaNumber={isaNumber} goToBilling={goToBilling} />
        );
    }

    render() {
        const { data, hasSVGFilter, engageCard, goToBilling } = this.props;
        const { hasError, hasFetched, items } = data;
        const hasContent = items.length > 0;
        const multipleCards = items && items.length > 1;
        let card;

        const shouldMask = !hasFetched;
        const blurClasses = classNames({
            'blur-html': shouldMask && hasSVGFilter,
            'blur-text': shouldMask && !hasSVGFilter
        });

        if (!hasError && hasContent) {
            const isaData = items[this.state.activeIndex].insuredList;
            const cardData = items[this.state.activeIndex];
            const navigation = this.renderNavigation(items, multipleCards);
            const header = this.renderHeader(cardData.isaNumber, goToBilling);

            switch (cardData.cardType) {
                // premiums
                case 'PremiumDirectDue':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="DirectDue" />);
                    break;
                case 'PremiumDirectDueHasLoan':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="DirectDueHasLoan" />);
                    break;
                case 'PremiumDirectPastDue':
                case 'DirectShortagePastDue':
                    card = (<PremiumDirectPastDue cardData={cardData} isaData={isaData} type="DirectPastDue" />);
                    break;
                case 'PremiumDirectMonthlyPastDue':
                    card = (<PremiumDirectMonthlyPastDue cardData={cardData} isaData={isaData}
                        type="DirectMonthlyPastDue" />);
                    break;
                case 'PremiumDirectOutOfWindow':
                case 'PremiumPaidMisc':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="DirectNotDue" />);
                    break;
                case 'PremiumDirectOutOfWindowHasLoan':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="DirectNotDueHasLoan" />);
                    break;
                case 'PremiumRecurring':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="Recurring" />);
                    break;
                case 'PremiumRecurringHasLoan':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="RecurringHasLoan" />);
                    break;
                case 'ScheduledPayment':
                    card = (<PaymentScheduled cardData={cardData} isaData={isaData} type="PendingPayment" />);
                    break;
                case 'DirectShortageDue':
                    card = (<PremiumDirectSplitPayment cardData={cardData} isaData={isaData}
                        type="DirectShortageDue" />);
                    break;
                case 'PremiumPaid':
                    card = (<LoanPaymentZeroDue cardData={cardData} isaData={isaData} type="PremiumPaidZeroDue" />);
                    break;
                // loans
                case 'LoanDue':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="Loan" />);
                    break;
                case 'LoanOutOfWindow':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="LoanNotDue" />);
                    break;
                case 'LoanRecurring':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="LoanRecurring" />);
                    break;
                case 'LoanScheduledPayment':
                    card = (<PaymentScheduled cardData={cardData} type="PendingLoanPayment" />);
                    break;
                case 'LoanOnlyFrozen':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="LoanFrozen" />);
                    break;
                case 'LoanPaidOff':
                    card = (<LoanPaymentZeroDue cardData={cardData} isaData={isaData} type="LoanPaidZeroDue" />);
                    break;
                // annuity
                case 'AnnuityRecurringInOrOutOfWindow':
                    card = (<AnnuityRecurring cardData={cardData} isaData={isaData} type="AnnuityRecurring" />);
                    break;
                case 'AnnuityDirectInOrOutOfWindow':
                    card = (<AnnuityDirect cardData={cardData} isaData={isaData} type="AnnuityDirect" />);
                    break;
                case 'AnnuityDirectScheduled':
                    card = (<AnnuityDirectScheduled cardData={cardData} isaData={isaData}
                        type="AnnuityDirectPending" />);
                    break;
                case 'AnnuityRecurringAddlContributionScheduled':
                    card = (<AnnuityRecurringScheduled cardData={cardData} isaData={isaData}
                        type="AnnuityRecurringPending" />);
                    break;
                case 'AnnuityFrozen':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="AnnuityFrozen" />);
                    break;
                // payment cases
                case 'PremiumPaidByDividend':
                    card = (<PaymentZeroDue cardData={cardData} isaData={isaData} type="PaidByDividend" />);
                    break;
                case 'PremiumPaidBy1035':
                    card = (<PaymentZeroDue cardData={cardData} isaData={isaData} type="PaidBy1035" />);
                    break;
                case 'PremiumPaidByDivAnd1035':
                    card = (<PaymentZeroDue cardData={cardData} isaData={isaData} type="PaidBy1035Dividend" />);
                    break;
                case 'PremiumFrozen':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="PremiumFrozen" />);
                    break;
                case 'RecurringShortageDue':
                    card = (<PaymentAdditionalDue cardData={cardData} isaData={isaData}
                        type="RecurringShortageDue" />);
                    break;
                case 'PaymentAdditionalDue':
                case 'RecurringAdditionalPaymentDue':
                case 'DirectAdditionalPaymentDue':
                    card = (<PaymentAdditionalDue cardData={cardData} isaData={isaData}
                        type="PremiumAdditionalDue" />);
                    break;
                case 'PremiumDirectSplitPaymentPastDue':
                    card = (<PremiumDirectSplitPaymentPastDue cardData={cardData} isaData={isaData}
                        type="PremiumSplitPayPastDue" />);
                    break;
                case 'OnlinePaymentIneligible':
                    card = (<OnlineIneligible cardData={cardData} isaData={isaData}
                        type="OnlinePaymentIneligible" />);
                    break;
                case 'HOCaseLock':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="HOCaseLock" />);
                    break;
                case 'ChangePending':
                    card = (<DirectOrRecurring cardData={cardData} isaData={isaData} type="ChangePending" />);
                    break;
                case 'PayerButNotOnIsa': // this will also return if the ISA service is not returning/has errors and the client is a payer
                    card = (<NoISA type="PayerButNotOnIsa" />);
                    break;
                case 'NotAPayer':
                    return null;
                default :
                    return null;
            }
// PremiumRecurringHasLoan, PremiumDirectDueHasLoan, PremiumDirectOutOfWindowHasLoan
            return (
                <section className="isa-card" onClick={engageCard}>
                    <div className={classNames({ 'card-loader': !hasFetched })} />
                    <div className={blurClasses} {...addAutomationProp('isa-card-qa')}>
                        {header}
                        {navigation}
                        {card}
                    </div>
                </section>
            );
        }

        return null;
    }
}

Billing.propTypes = {
    data: React.PropTypes.object,
    hasSVGFilter: React.PropTypes.bool,
    engageCard: React.PropTypes.func,
    goToBilling: React.PropTypes.func
};

const mapStateToProps = state => ({
    data: getIsaData(state),
    hasSVGFilter: hasSVGFilter(state)
});

const mapDispatchToProps = dispatch => ({
    engageCard() {
        dispatch(engageCard('ISA'));
    },
    goToBilling() {
        dispatch(goToBilling());
    }
});
export default connect(mapStateToProps, mapDispatchToProps)(Billing);
