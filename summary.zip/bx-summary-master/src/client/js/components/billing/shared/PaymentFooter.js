import React, { Component } from 'react';
import { connect } from 'react-redux';
import config from '../../../utils/config';
import { isaViewDetails, isaLoanPayLink } from '../../../actions/SummaryActions';

const NMC_URL = config.nmcDomain;

class Footer extends Component {

    renderButton(buttonText, linkingUrl, type, isaViewDetails) {
        return (<a href={linkingUrl}
                onMouseDown={() => {
                    isaViewDetails(type);
                }}
                className="button">{buttonText}</a>
        );
    }

    renderLink(linkingUrl, type, isaLoanPayLink) {
        return (<a href={linkingUrl}
            onMouseDown={() => {
                isaLoanPayLink(type);
            }}>make a loan payment</a>
        );
    }

    render() {
        const { totalPaymentDue, dueDate, frequency, isaUrl, type, isaTotal, isaViewDetails, isaLoanPayLink } = this.props;

        const dueString = (type === 'Loan') ? 'Total Loan Payment' : 'Total Payment Due';
        const nmcUrl = `${NMC_URL + isaUrl}`;

        if (type === 'Recurring') {
            const seeDetails = this.renderButton('See Details', nmcUrl, type, isaViewDetails);
            return (
                <div className="cta-container cta-container--default cta-container--1-column">
                    <div className="cta">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <h5>Total Payment: {isaTotal}</h5>
                            <p>Scheduled {frequency} Payment: {dueDate}</p>
                        </div>
                        <div className="cta__button cta__button--1-column">
                            {seeDetails}
                        </div>
                    </div>
                </div>
            );
        } else if (type === 'RecurringHasLoan') {
            const seeDetails = this.renderButton('See Details', nmcUrl, type, isaViewDetails);
            const loanLink = this.renderLink(`${nmcUrl}&loan`, type, isaLoanPayLink);
            return (
                <div className="cta-container cta-container--default cta-container--1-column">
                    <div className="cta">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <h5>Total Payment: {isaTotal}</h5>
                            <p>Scheduled {frequency} Payment: {dueDate}</p>
                        </div>
                        <div className="cta__button cta__button--1-column">
                            {seeDetails}
                        </div>
                    </div>
                    <div className="cta__loan-message">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <p>You can {loanLink} on your outstanding loan balance.</p>
                        </div>
                    </div>
                </div>
            );
        } else if (type === 'DirectNotDue') {
            const seeDetails = this.renderButton('See Details', nmcUrl, type, isaViewDetails);
            return (
                <div className="cta-container cta-container--default cta-container--1-column">
                    <div className="cta">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <h5>Total Payment: {totalPaymentDue}</h5>
                            <p>Next {frequency} Payment: {dueDate}</p>
                        </div>
                        <div className="cta__button cta__button--1-column">
                            {seeDetails}
                        </div>
                    </div>
                </div>
            );
        } else if (type === 'DirectNotDueHasLoan') {
            const seeDetails = this.renderButton('See Details', nmcUrl, type, isaViewDetails);
            const loanLink = this.renderLink(`${nmcUrl}&loan`, type, isaLoanPayLink);
            return (
                <div className="cta-container cta-container--default cta-container--1-column">
                    <div className="cta">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <h5>Total Payment: {totalPaymentDue}</h5>
                            <p>Next {frequency} Payment: {dueDate}</p>
                        </div>
                        <div className="cta__button cta__button--1-column">
                            {seeDetails}
                        </div>
                    </div>
                    <div className="cta__loan-message">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <p>You can {loanLink} on your outstanding loan balance.</p>
                        </div>
                    </div>
                </div>
            );
        } else if (type === 'LoanNotDue') {
            const seeDetails = this.renderButton('See Details', nmcUrl, type, isaViewDetails);
            const loanLink = this.renderLink(`${nmcUrl}&loan`, type, isaLoanPayLink);
            return (
                <div className="cta-container cta-container--default cta-container--1-column">
                    <div className="cta">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <h5>Total Loan Payment: {totalPaymentDue}</h5>
                            <p>Next {frequency} Payment: {dueDate}</p>
                        </div>
                        <div className="cta__button cta__button--1-column">
                            {seeDetails}
                        </div>
                    </div>
                    <div className="cta__loan-message">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <p>You can {loanLink} on your outstanding loan balance.</p>
                        </div>
                    </div>
                </div>
            );
        } else if (type === 'LoanRecurring') {
            const seeDetails = this.renderButton('See Details', nmcUrl, type, isaViewDetails);
            const loanLink = this.renderLink(`${nmcUrl}&loan`, type, isaLoanPayLink);
            return (
                <div className="cta-container cta-container--default cta-container--1-column">
                    <div className="cta">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <h5>Total Loan Payment: {totalPaymentDue}</h5>
                            <p>Scheduled {frequency} Payment: {dueDate}</p>
                        </div>
                        <div className="cta__button cta__button--1-column">
                            {seeDetails}
                        </div>
                    </div>
                    <div className="cta__loan-message">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <p>You can {loanLink} on your outstanding loan balance.</p>
                        </div>
                    </div>
                </div>
            );
        } else if (type === 'AnnuityDirect') {
            const makeContribution = this.renderButton('Make Contribution', nmcUrl, type, isaViewDetails);
            return (
                <div className="cta-container cta-container--default cta-container--1-column">
                    <div className="cta">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <h5>You can make online contributions to your annuity.</h5>
                        </div>
                        <div className="cta__button cta__button--1-column">
                            {makeContribution}
                        </div>
                    </div>
                </div>
            );
        } else if (type === 'HOCaseLock' || type === 'ChangePending') {
            const seeDetails = this.renderButton('See Details', nmcUrl, type, isaViewDetails);
            return (
                <div className="cta-container cta-container--default cta-container--1-column">
                    <div className="cta">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                        <p>An ISA change is processing. Please allow 1 business day for this change to be complete.</p>
                        </div>
                        <div className="cta__button cta__button--1-column">
                            {seeDetails}
                        </div>
                    </div>
                </div>
            );
        } else if (type === 'DirectDueHasLoan') {
            const makePayment = this.renderButton('Make Payment', nmcUrl, type, isaViewDetails);
            const loanLink = this.renderLink(`${nmcUrl}&loan`, type, isaLoanPayLink);
            return (
                <div className="cta-container cta-container--default cta-container--1-column">
                    <div className="column">
                    <div className="cta">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <h5>{dueString}: {totalPaymentDue}</h5>
                            <p>Due Date: {dueDate}</p>
                        </div>
                        <div className="cta__button cta__button--1-column">
                            {makePayment}
                        </div>
                    </div>
                    <div className="cta__loan-message">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <p>You can {loanLink} on your outstanding loan balance.</p>
                        </div>
                    </div>
                    </div>
                </div>
            );
        }
        const makePayment = this.renderButton('Make Payment', nmcUrl, type, isaViewDetails);
        return (
            <div className="cta-container cta-container--default cta-container--1-column">
                <div className="column">
                    <div className="cta">
                        <div className="cta__message cta__message--no-icon cta__message--1-column">
                            <h5>{dueString}: {totalPaymentDue}</h5>
                            <p>Due Date: {dueDate}</p>
                        </div>
                        <div className="cta__button cta__button--1-column">
                            {makePayment}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

Footer.propTypes = {
    totalPaymentDue: React.PropTypes.string,
    dueDate: React.PropTypes.string,
    frequency: React.PropTypes.string,
    isaUrl: React.PropTypes.string,
    type: React.PropTypes.string,
    isaViewDetails: React.PropTypes.func,
    isaLoanPayLink: React.PropTypes.func,
    isaTotal: React.PropTypes.string
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    },
    isaLoanPayLink(type) {
        dispatch(isaLoanPayLink(type));
    }
});

export default connect(null, mapDispatchToProps)(Footer);
