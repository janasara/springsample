import React, { Component } from 'react';
import classNames from 'classnames';
import ProductRow from './ProductRow';
import LeftColumnTotal from './LeftColumnTotal';
import AdditionalPayments from './AdditionalPayments';

export default class Payment extends Component {

    renderInsured(insuredList) {
        const renderedList = insuredList.map((insured, index) => {
            const productList = insured.productList.map((product, i) => <ProductRow product={product} key={i} />);

            return (
                <div className="isa-card-insured-product" key={index}>
                    <h5 className="isa-card-insured-product__insured-name">{insured.name}, Insured</h5>
                    {productList}
                </div>
            );
        });
        return renderedList;
    }

    renderHeading(type) {
        if (type && (type === 'Loan' || type === 'LoanNotDue' || type === 'LoanRecurring' || type === 'LoanFrozen')) {
            return <h4 className="isa-card__nested-heading">Loan Payments</h4>;
        }
        return null;
    }

    render() {
        const { insuredList, productCount, serviceCharge, additionalPayment, type, totalPaymentDue, isaTotal } = this.props;
        const hasMultiInsured = insuredList.length > 1;
        const hasLargeProductlist = productCount > 4;
        const classes = classNames({
            'isa-card-insured-2-column-container': hasLargeProductlist && hasMultiInsured,
            'insured-2-column': (hasLargeProductlist && !hasMultiInsured) ||
                                                    (!hasLargeProductlist && hasMultiInsured) ||
                                                    (!hasLargeProductlist && !hasMultiInsured)
        });
        const heading = this.renderHeading(type);
        /*
        /*
        Evenly distribute the insured and their product list across columns so it looks visually decent.
        'Rule' is set by LV design that 4 product rows should be the max rows to appear in the left column before jumping to 2 columns
        */
        const leftCol = [];
        const rightCol = [];
        let currentProductCount = 0;
        const insuredLength = insuredList.length;
        if (hasMultiInsured && hasLargeProductlist && insuredList) {
            // split out columns
            insuredList.map((insured, index) => {
                currentProductCount += insured.productList.length;
                // first check agains the 'rule' to make sure we hit that quota
                // then check to see if we hit the half mark in attempt to distribute evenly
                if (currentProductCount <= 4 || (currentProductCount <= (productCount / 2) || index <= ((insuredLength - 1) / 2))) {
                    leftCol.push(insured);
                    return leftCol;
                }
                rightCol.push(insured);
                return rightCol;
            });

            const renderedListLeft = this.renderInsured(leftCol);
            const renderedListRight = this.renderInsured(rightCol);
            return (
                <div className={classes}>
                    {heading}
                    <div className="insured-2-column">
                        {renderedListLeft}
                    </div>
                    <div className="insured-2-column">
                        {renderedListRight}
                    </div>
                </div>
            );
        } else if (totalPaymentDue && !hasMultiInsured) {
            const renderedList = this.renderInsured(insuredList);
            // this uses 'billedAmount' from api call because there is no current amountDue, not in a bill cycle
            if (type === 'Recurring' || type === 'RecurringHasLoan' || type === 'DirectNotDue' || type === 'DirectNotDueHasLoan') {
                return (
                    <div className={classes}>
                        {heading}
                        {renderedList}
                        <LeftColumnTotal totalPaymentDue={isaTotal} />
                    </div>
                );
            }
            // this uses 'amountDue' because we are in the bill cycle and have a current payment due
            return (
                <div className={classes}>
                    {heading}
                    {renderedList}
                    <LeftColumnTotal totalPaymentDue={totalPaymentDue} />
                </div>
            );
        } else if ((serviceCharge !== '$0.00' || additionalPayment !== '$0.00') && !hasLargeProductlist) {
            const renderedList = this.renderInsured(insuredList);
            return (
                <div className={classes}>
                    {heading}
                    {renderedList}
                    <AdditionalPayments serviceCharge={serviceCharge} additionalPayment={additionalPayment} />
                </div>
            );
        }
        const renderedList = this.renderInsured(insuredList);
        return (
            <div className={classes}>
                {heading}
                {renderedList}
            </div>
        );
    }
}

Payment.propTypes = {
    insuredList: React.PropTypes.array,
    productCount: React.PropTypes.number,
    totalPaymentDue: React.PropTypes.string,
    isaTotal: React.PropTypes.string,
    serviceCharge: React.PropTypes.string,
    additionalPayment: React.PropTypes.string,
    type: React.PropTypes.string
};
