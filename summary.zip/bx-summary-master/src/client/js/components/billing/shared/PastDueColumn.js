import React, { Component } from 'react';
import { connect } from 'react-redux';
import config from '../../../utils/config';
import { isaViewDetails } from '../../../actions/SummaryActions';

const NMC_URL = config.nmcDomain;

class PastDueColumn extends Component {

    renderButton(buttonText, isaViewDetails, linkingUrl, type) {
        return (<a href={linkingUrl}
            onMouseDown={() => {
                isaViewDetails(type);
            }}
            className="button warning">{buttonText}</a>
        );
    }

    render() {
        const { totalPaymentDue, dueDate, isaUrl, type, isaViewDetails } = this.props;

        const nmcUrl = `${NMC_URL + isaUrl}`;
        const makePayment = this.renderButton('Make Payment', isaViewDetails, nmcUrl, type);

        return (
            <div className="cta-container cta-container--flex cta-container--warning cta-container--2-column">
                <div className="cta">
                    <div className="cta__icon cta__icon--2-column cta__icon--warning" />
                    <div className="cta__message cta__message--warning">
                        <strong>Your payment of {totalPaymentDue} was due on {dueDate}.</strong>
                    <p>To avoid potential loss of coverage, pay the full amount today.</p>
                    </div>
                    <div className="cta__button cta__button--2-column">
                        {makePayment}
                    </div>
                </div>
            </div>
        );
    }
}


PastDueColumn.propTypes = {
    totalPaymentDue: React.PropTypes.string,
    dueDate: React.PropTypes.string,
    isaUrl: React.PropTypes.string,
    type: React.PropTypes.string,
    isaViewDetails: React.PropTypes.func
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(PastDueColumn);
