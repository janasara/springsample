import React from 'react';
import { connect } from 'react-redux';
import { navigateIsas } from '../../../actions/SummaryActions';

const Navigation = ({ options, navigateIsas }) => (
    <div className="isa-card-navigation">
        <button className="isa-card-navigation__previous" data-navigate={options.prevIndex} onClick={options.onClick} onMouseDown={() => {
            navigateIsas(`${options.countText}`);
        }} />
        <span className="isa-card-navigation__page-count">{options.countText}</span>
        <button className="isa-card-navigation__next" data-navigate={options.nextIndex} onClick={options.onClick} onMouseDown={() => {
            navigateIsas(`${options.countText}`);
        }} />
    </div>
);

Navigation.propTypes = {
    options: React.PropTypes.object,
    navigateIsas: React.PropTypes.func
};

const mapDispatchToProps = dispatch => ({
    navigateIsas(navigation) {
        dispatch(navigateIsas(navigation));
    }
});

export default connect(null, mapDispatchToProps)(Navigation);
