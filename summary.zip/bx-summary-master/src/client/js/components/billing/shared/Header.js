import React from 'react';
import config from '../../../utils/config';

const NMC_URL = config.nmcDomain;

const Header = ({ isaNumber, goToBilling }) => {
    const url = `${NMC_URL}/billing`;
    return (
        <div className="isa-card-header">
            <h2 className="isa-card-header__heading">
                <a href={url} onMouseDown={goToBilling}>Billing & Payments</a>
            </h2>
            <h4 className="isa-card-header__isa-number">Insurance Service Account (ISA) {isaNumber}</h4>
        </div>
    );
};

Header.propTypes = {
    isaNumber: React.PropTypes.string
};

export default Header;
