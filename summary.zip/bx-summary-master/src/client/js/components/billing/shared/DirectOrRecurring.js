import React, { Component } from 'react';
import startCase from 'lodash/startCase';
import MediaQuery from 'react-responsive';
import Payment from './Payment';
import MobilePayment from './MobilePayment';
import PaymentFooter from './PaymentFooter';
import MessageColumn from './MessageColumn';
import mediaQueries from '../../../utils/mediaQueries';
import addAutomationProp from '../../../utils/addAutomationProp';

export default class PremiumDirectOrRecurring extends Component {

    renderCard(totalPaymentDue, dueDate, frequency, initialIsaData, isaUrl, serviceCharge, additionalPayment, type, isaTotal) {
        let productCount = 0;
        const isaData = initialIsaData.map((insured) => {
            productCount += insured.productList.length;
            return productCount;
        });

        if (productCount > 4 && isaData.length > 1) {
            return (
                <div>
                    <MediaQuery query={mediaQueries.$desktopAndPrint} component="div" className="billing-multi-col" >
                        <Payment insuredList={initialIsaData} productCount={productCount}
                            serviceCharge={serviceCharge} additionalPayment={additionalPayment} type={type} />
                        <PaymentFooter totalPaymentDue={totalPaymentDue} dueDate={dueDate} frequency={frequency}
                            isaUrl={isaUrl} type={type} isaTotal={isaTotal} />
                    </MediaQuery>

                    <MediaQuery query={mediaQueries.$mobileAndNotPrint} component="div" className="billing-multi-col" >
                        <MobilePayment insuredList={initialIsaData} productCount={productCount}
                            serviceCharge={serviceCharge} additionalPayment={additionalPayment} type={type} />
                        <PaymentFooter totalPaymentDue={totalPaymentDue} dueDate={dueDate} frequency={frequency}
                            isaUrl={isaUrl} type={type} isaTotal={isaTotal} />
                    </MediaQuery>
                </div>
            );
        }

        return (
            <div>
                <MediaQuery query={mediaQueries.$desktopAndPrint} component="div" className="isa-card-2-column-container" >
                    <Payment insuredList={initialIsaData} productCount={productCount} totalPaymentDue={totalPaymentDue} isaTotal={isaTotal}
                        serviceCharge={serviceCharge} additionalPayment={additionalPayment} type={type} />
                    <MessageColumn totalPaymentDue={totalPaymentDue} dueDate={dueDate} frequency={frequency}
                        isaUrl={isaUrl} type={type} isaTotal={isaTotal} />
                </MediaQuery>

                <MediaQuery query={mediaQueries.$mobileAndNotPrint} component="div" className="isa-card-2-column-container" >
                    <MobilePayment insuredList={initialIsaData} productCount={productCount}
                        serviceCharge={serviceCharge} additionalPayment={additionalPayment} type={type} />
                    <MessageColumn totalPaymentDue={totalPaymentDue} dueDate={dueDate} frequency={frequency}
                        isaUrl={isaUrl} type={type} isaTotal={isaTotal} />
                </MediaQuery>
            </div>
        );
    }

    render() {
        const { cardData, isaData, type } = this.props;
        const card = this.renderCard(cardData.amountDue, cardData.dueDate,
            startCase(cardData.frequency), isaData, cardData.isaUrl, cardData.serviceCharge, cardData.additionalPayment, type, cardData.isaTotal);

        return (
            <div className="isa-card-content-container" {...addAutomationProp(type)}>
                {card}
            </div>
        );
    }

}

PremiumDirectOrRecurring.propTypes = {
    cardData: React.PropTypes.object,
    isaData: React.PropTypes.array,
    type: React.PropTypes.string
};
