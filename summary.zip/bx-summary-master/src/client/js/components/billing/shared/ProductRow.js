import React from 'react';

const ProductRow = ({ product }) => {
    if (product.isOwnerAndNotRestricted || product.isNotOwner) {
        return (
        <div className="isa-card-insured-product__product-info-container">
            <div className="isa-card-insured-product__product-name">{product.productType} - {product.subjectNum}</div>
            <div className="isa-card-insured-product__product-amount">{product.payment}</div>
        </div>
        );
    }
    return (
        <div className="product-row row">
            <div className="small-9 column product-name">Not Available</div>
            <div className="small-3 column product-amount">{product.payment}</div>
        </div>
    );
};

ProductRow.propTypes = {
    product: React.PropTypes.object
};

export default ProductRow;
