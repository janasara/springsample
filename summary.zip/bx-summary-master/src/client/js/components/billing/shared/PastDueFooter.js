import React, { Component } from 'react';
import { connect } from 'react-redux';
import config from '../../../utils/config';
import { isaViewDetails } from '../../../actions/SummaryActions';

const NMC_URL = config.nmcDomain;

class PastDueFooter extends Component {

    renderButton(buttonText, isaViewDetails, linkingUrl, type) {
        return (<a href={linkingUrl}
            onMouseDown={() => {
                isaViewDetails(type);
            }}
            className="button warning">{buttonText}</a>
        );
    }

    render() {
        const { totalPaymentDue, dueDate, isaUrl, type, isaViewDetails } = this.props;

        const nmcUrl = `${NMC_URL + isaUrl}`;
        const makePayment = this.renderButton('Make Payment', isaViewDetails, nmcUrl, type);

        return (
            <div className="cta-container cta-container--warning cta-container--1-column">
                <div className="cta">
                    <div className="cta__icon cta__icon--warning cta__icon--1-column" />
                    <div className="cta__message cta__message--warning cta__message--1-column">
                        <h5 className="cta__heading cta__heading--warning">
                            Your payment of <strong>{totalPaymentDue}</strong> was due on {dueDate}.
                        </h5>
                    <p>To avoid potential loss of coverage, pay the full amount today.</p>
                    </div>
                    <div className="cta__button cta__button--1-column">
                        {makePayment}
                    </div>
                </div>
            </div>
        );
    }
}

PastDueFooter.propTypes = {
    totalPaymentDue: React.PropTypes.string,
    dueDate: React.PropTypes.string,
    isaUrl: React.PropTypes.string,
    type: React.PropTypes.string,
    isaViewDetails: React.PropTypes.func
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(PastDueFooter);
