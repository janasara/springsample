import React, { Component } from 'react';

export default class AdditionalPayments extends Component {

    renderAdditionalPayment(additionalPayment) {
        if (additionalPayment && additionalPayment !== '$0.00') {
            return (
                <div className="billing-service-charge small-12column">
                    <div className="billing-charge-row row">
                        <div className="small-9 column billing-charge-name"><strong>Additional Payment</strong></div>
                        <div className="small-3 column billing-charge-amount">{additionalPayment}</div>
                    </div>
                </div>
            );
        }
        return null;
    }

    renderServiceCharge(serviceCharge) {
        if (serviceCharge && serviceCharge !== '$0.00') {
            return (
                    <div className="isa-card-service-charge">
                        <div className="isa-card-service-charge__name"><strong>Service Charge</strong></div>
                        <div className="isa-card-service-charge__amount">{serviceCharge}</div>
                    </div>
            );
        }

        return null;
    }

    render() {
        const { serviceCharge, additionalPayment } = this.props;
        const serviceChargeDue = this.renderServiceCharge(serviceCharge);

        const additionalPaymentDue = this.renderAdditionalPayment(additionalPayment);
        if (serviceChargeDue || additionalPaymentDue) {
            return (
                <div>
                    {serviceChargeDue}
                    {additionalPaymentDue}
                </div>
            );
        }
        return null;
    }
}

AdditionalPayments.propTypes = {
    serviceCharge: React.PropTypes.string,
    additionalPayment: React.PropTypes.string
};
