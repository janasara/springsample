import React from 'react';

const LeftColumnTotal = ({ totalPaymentDue }) => (
    <div className="isa-card-insured-product__total-row-container">
        <span className="isa-card-insured-product__product-name"><strong>Total Payment</strong></span>
        <span className="isa-card-insured-product__product-amount"><strong>{totalPaymentDue}</strong></span>
    </div>
);

LeftColumnTotal.propTypes = {
    totalPaymentDue: React.PropTypes.string
};

export default LeftColumnTotal;
