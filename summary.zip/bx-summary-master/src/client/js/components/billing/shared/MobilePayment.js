import React, { Component } from 'react';

export default class MobilePayment extends Component {

    renderInsured(insuredList) {
        const renderedList = insuredList.map((insured, index) => {
            const productList = insured.productList.map((product, i) => (
                <ul className="keyval-chart" key={i}>
                    <li>
                        <span>{product.productType} - {product.subjectNum}</span>
                    </li>
                    <li className="billing-mobile-row">
                        <span className="key">Total</span>
                        <span className="val">{product.payment}</span>
                    </li>
                </ul>
            ));

            return (
                <li key={index} className="top-row">
                    <div className="title">
                        <p className="insured-name">
                            <strong>{insured.name}</strong>
                            <span className="text-dark-grey">Insured</span>
                        </p>
                    </div>
                        {productList}
                </li>
            );
        });
        return renderedList;
    }

    renderServiceLine(serviceCharge) {
        if (serviceCharge !== '$0.00') {
            return (
                <li className="top-row">
                    <ul className="keyval-chart">
                        <li>
                            <span className="key">Service Charge</span>
                            <span className="val">{serviceCharge}</span>
                        </li>
                    </ul>
                </li>
            );
        }
        return null;
    }

    renderAddlPaymentLine(addlPayment) {
        if (addlPayment !== '$0.00') {
            return (
                <li className="top-row">
                    <ul className="keyval-chart">
                        <li>
                            <span className="key">Additional Payment</span>
                            <span className="val">{addlPayment}</span>
                        </li>
                    </ul>
                </li>
            );
        }
        return null;
    }

    renderHeading(type) {
        if (type && type.indexOf('Loan') >= 0) {
            return <h4 className="isa-card__nested-heading">Loan Payments</h4>;
        }
        return null;
    }

    render() {
        const { insuredList, serviceCharge, additionalPayment, type } = this.props;

        if ((serviceCharge !== '$0.00' || additionalPayment !== '$0.00')) {
            const renderedList = this.renderInsured(insuredList);
            const serviceLine = this.renderServiceLine(serviceCharge);
            const addlPayLine = this.renderAddlPaymentLine(additionalPayment);
            return (
                <div className="billing-mobile-insured">
                    {renderedList}
                    {serviceLine}
                    {addlPayLine}
                </div>
            );
        }
        const renderedList = this.renderInsured(insuredList);
        const heading = this.renderHeading(type);
        return (
            <div className="billing-mobile-insured">
                {heading}
                {renderedList}
            </div>
        );
    }
}

MobilePayment.propTypes = {
    insuredList: React.PropTypes.array,
    serviceCharge: React.PropTypes.string,
    additionalPayment: React.PropTypes.string,
    type: React.PropTypes.string
};
