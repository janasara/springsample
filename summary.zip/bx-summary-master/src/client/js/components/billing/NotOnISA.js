import React, { Component } from 'react';
import { connect } from 'react-redux';
import { isaViewDetails } from '../../actions/SummaryActions';

class NotOnISA extends Component {
    renderButton(buttonText, type, isaViewDetails) {
        return (<a href="/contact"
            onMouseDown={() => {
                isaViewDetails(type);
            }}
            className="button">{buttonText}</a>
        );
    }

    render() {
        const { type, isaViewDetails } = this.props;

        const contactUs = this.renderButton('Contact Us', type, isaViewDetails);

        return (
            <div className="isa-card-content-container">
                <h4 className="isa-card-content-container__heading">Pay Online</h4>
                <div className="isa-card-content-container__no-isa-container">
                    <div className="isa-card-content-container__no-isa">
                       <p>
                           To make an online payment or see payment history online, you must be the designated
                           payer of the Insurance Service Account (ISA). You are not recorded as the payer of an ISA.
                       </p>
                   </div>
                   <div className="cta-container cta-container--default cta-container--2-column">
                       <div className="cta">
                           <div className="cta__message cta__message--no-icon">
                               <h5>Questions?</h5>
                           </div>
                           <div className="cta__button">
                               {contactUs}
                           </div>
                       </div>
                   </div>
               </div>
           </div>
        );
    }
}

NotOnISA.propTypes = {
    type: React.PropTypes.string,
    isaViewDetails: React.PropTypes.func
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(NotOnISA);
