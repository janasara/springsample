import React, { Component } from 'react';
import { connect } from 'react-redux';
import { isaViewDetails } from '../../actions/SummaryActions';

class NoISA extends Component {
    renderButton(buttonText, type, isaViewDetails) {
        return (<a href="/contact"
            onMouseDown={() => {
                isaViewDetails(type);
            }}
            className="button">{buttonText}</a>
        );
    }
    render() {
        const { type, isaViewDetails } = this.props;

        const contactUs = this.renderButton('Contact Us', type, isaViewDetails);
        return (
            <div className="isa-card-content-container">
                <h4 className="isa-card-content-container__heading">Pay Online</h4>
                <div className="isa-card-content-container__no-isa-container isa-card-content-container__no-isa-container--flex">
                    <div className="isa-card-content-container__no-isa">
                       <p>Paying online requires an Insurance Service Account (ISA). You do not have any active ISAs.</p>

                      <h5>With an ISA you can:</h5>
                       <ul>
                           <li>Pay insurance premiums that are due.</li>
                           <li>Make contributions to annuities.</li>
                           <li>Set up automatic withdrawals from your checking or savings account for premium payments or annuity contributions.</li>
                           <li>Set up a loan repayment schedule, and make loan payments.</li>
                           <li>View your payment history.</li>
                       </ul>
                       <p>We do not accept debit or credit card payments.</p>
                   </div>
                   <div className="cta-container cta-container--default cta-container--2-column">
                       <div className="cta">
                           <div className="cta__message cta__message--no-icon">
                               <h5>Contact us to set up an ISA.</h5>
                           </div>
                           <div className="cta__button">
                               {contactUs}
                           </div>
                       </div>
                   </div>
               </div>
           </div>
        );
    }
}

NoISA.propTypes = {
    type: React.PropTypes.string,
    isaViewDetails: React.PropTypes.func
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(NoISA);
