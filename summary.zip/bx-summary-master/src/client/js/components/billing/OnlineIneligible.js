import React from 'react';
import config from '../../utils/config';

const NMC_URL = config.nmcDomain;

const OnlineIneligible = ({ cardData }) => (
    <div className="cta-container cta-container--default cta-container--1-column">
        <div className="cta">
            <div className="cta__message cta__message--1-column cta__message--no-icon">
                <p>
                    This Insurance Service Account (ISA) is not eligible for online payments. Please contact use for assistance.
                </p>
            </div>
            <div className="cta__button cta__button--1-column">
                <a className="button" href={`${NMC_URL + cardData.isaUrl}`}>See Details</a>
            </div>
        </div>
    </div>
);

OnlineIneligible.propTypes = {
    cardData: React.PropTypes.object
};

export default OnlineIneligible;
