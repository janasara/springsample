import React, { Component } from 'react';
import { connect } from 'react-redux';
import config from '../../../utils/config';
import { isaViewDetails } from '../../../actions/SummaryActions';

const NMC_URL = config.nmcDomain;

class LoanPaymentZeroDue extends Component {

    renderButton(buttonText, isaViewDetails, linkingUrl, type) {
        return (<a href={linkingUrl}
            onMouseDown={() => {
                isaViewDetails(type);
            }}
            className="button">{buttonText}</a>
        );
    }

    renderCard(isaUrl, type, isaViewDetails) {
        const nmcUrl = `${NMC_URL + isaUrl}`;
        if (type === 'PremiumPaidZeroDue') {
            const seeDetails = this.renderButton('See Details', isaViewDetails, nmcUrl, type);
            return (

                <div className="loan-payment-zero-due-panel">

                    <div className="billing-panel-details">
                        <div className="row billing-alert-box">
                                <div className="medium-1 column billing-panel-details-icon">
                                    <div className="icon icon-success" />
                                </div>
                                <div className="medium-7 small-12 column billing-panel-details-box">
                                    <div className="billing-panel-details-content"><strong>$0 Payment Due</strong></div>
                                    <div className="billing-panel-details-message">
                                        Your premium is paid in full. You don&#39;t owe any more payments.
                                    </div>
                                </div>
                                <div className="medium-4 small-12 column billing-panel-button">
                                    {seeDetails}
                                </div>
                            </div>
                    </div>

                </div>

            );
        }
        const seeDetails = this.renderButton('See Details', isaViewDetails, nmcUrl, type);
        return (
            <div className="cta-container cta-container--info cta-container--1-column">
                <div className="cta">
                        <div className="cta__icon cta__icon--1-column cta__icon--info" />
                        <div className="cta__message--1-column">
                            <h5>$0 Payment Due</h5>
                            <p>This loan is paid in full. You don&#39;t owe any more payments.</p>
                        </div>
                        <div className="cta__button cta__button--1-column">
                            {seeDetails}
                        </div>
                </div>
            </div>
        );
    }

    render() {
        const { cardData, type, isaViewDetails } = this.props;

        const card = this.renderCard(cardData.isaUrl, type, isaViewDetails);

        return (
            <div>
                {card}
            </div>
        );
    }

}

LoanPaymentZeroDue.propTypes = {
    cardData: React.PropTypes.object,
    type: React.PropTypes.string,
    isaViewDetails: React.PropTypes.func
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(LoanPaymentZeroDue);
