import React, { Component } from 'react';
import { connect } from 'react-redux';
import config from '../../../utils/config';
import { isaViewDetails } from '../../../actions/SummaryActions';

const NMC_URL = config.nmcDomain;

class PaymentAdditionalDue extends Component {

    renderButton(buttonText, linkingUrl, type, isaViewDetails) {
        return (<a href={linkingUrl}
                onMouseDown={() => {
                    isaViewDetails(type);
                }}
                className="button">{buttonText}</a>
        );
    }

    renderCard(additionalPayment, frequency, isaUrl, isaViewDetails) {
        const nmcUrl = `${NMC_URL + isaUrl}`;
        const makePayment = this.renderButton('See Details', nmcUrl, 'AdditionalDue', isaViewDetails);
        return (
            <div className="cta-container cta-container--default cta-container--1-column">
                <div className="column">
                <div className="cta">
                    <div className="cta__message cta__message--no-icon cta__message--1-column">
                        <h5>Your additional payment of {additionalPayment} is due today.</h5>
                        <p>
                            Due to your requested insurance protection increase,
                            an additional payment is required to bring your account current.
                        </p>
                        <p>
                            This amount does not include  your {frequency} payment amount.
                        </p>
                    </div>
                    <div className="cta__button cta__button--1-column">
                        {makePayment}
                    </div>
                </div>
                </div>
            </div>
        );
    }

    render() {
        const { cardData, isaViewDetails } = this.props;

        const card = this.renderCard(cardData.shortageAmountDue, cardData.frequency, cardData.isaUrl, isaViewDetails);

        return (

            <div>
                <h4 className="isa-card__heading">Additional Payment Required</h4>
                {card}
            </div>
        );
    }

}

PaymentAdditionalDue.propTypes = {
    cardData: React.PropTypes.object,
    isaViewDetails: React.PropTypes.func
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(PaymentAdditionalDue);
