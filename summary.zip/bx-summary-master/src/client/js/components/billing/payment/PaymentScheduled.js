import React, { Component } from 'react';
import { connect } from 'react-redux';
import config from '../../../utils/config';
import { isaViewDetails } from '../../../actions/SummaryActions';

const NMC_URL = config.nmcDomain;

class PaymentScheduled extends Component {
    renderButton(buttonText, isaViewDetails, linkingUrl, type) {
        return (<a href={linkingUrl}
            onMouseDown={() => {
                isaViewDetails(type);
            }}
            className="button">{buttonText}</a>
        );
    }

    renderHeading(type) {
        if (type && type.indexOf('Loan') >= 0) {
            return <h4 className="isa-card__nested-heading">Loan Payment Scheduled</h4>;
        }
        return <h4 className="isa-card__nested-heading">Payment Scheduled</h4>;
    }

    renderCard(paymentDate, amount, maskedAcctNumber, bankAccountType, confirmationNumber, isaUrl, type, isaViewDetails) {
        const nmcUrl = `${NMC_URL + isaUrl}`;
        const seeDetails = this.renderButton('See Details', isaViewDetails, nmcUrl, type);
        const heading = this.renderHeading(type);

        return (
            <div className="isa-card__content">
                <div className="isa-card-payment-scheduled">
                    {heading}
                    <ul className="keyval-chart">
                        <li>
                            <span className="key">Payment Date</span>
                            <span className="val text-right">{paymentDate}</span>
                        </li>
                        <li>
                            <span className="key">Amount</span>
                            <span className="val text-right">{amount}</span>
                        </li>
                        <li>
                            <span className="key">{bankAccountType} Account</span>
                            <span className="val text-right">{maskedAcctNumber}</span>
                        </li>
                        <li>
                            <span className="key">Confirmation Number</span>
                            <span className="val text-right">{confirmationNumber}</span>
                        </li>
                    </ul>
                </div>
                <div className="cta-container cta-container--default cta-container--2-column">
                    <div className="cta">
                        <div className="cta__message cta__message--no-icon">
                        <h5>Your payment is processing</h5>
                        <p>
                            Please allow 1-3 business days after the payment for the
                            transaction to be reflected in your {bankAccountType.toLowerCase()} account.
                        </p>
                        </div>
                        <div className="cta__button">
                            {seeDetails}
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    render() {
        const { cardData, type, isaViewDetails } = this.props;

        const card = this.renderCard(
            cardData.pendingPayment.paymentDate,
            cardData.pendingPayment.paymentAmount,
            cardData.pendingPayment.maskedBankAccountNumber,
            cardData.pendingPayment.bankAccountType,
            cardData.pendingPayment.confirmationNumber,
            cardData.isaUrl,
            type,
            isaViewDetails
        );

        return (
            <div>
                {card}
            </div>

        );
    }

}

PaymentScheduled.propTypes = {
    cardData: React.PropTypes.object,
    type: React.PropTypes.string,
    isaViewDetails: React.PropTypes.func
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(PaymentScheduled);
