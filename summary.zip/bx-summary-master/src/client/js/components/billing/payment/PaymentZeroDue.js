import React, { Component } from 'react';
import { connect } from 'react-redux';
import config from '../../../utils/config';
import { isaViewDetails } from '../../../actions/SummaryActions';

const NMC_URL = config.nmcDomain;

class PaymentZeroDue extends Component {

    renderButton(buttonText, isaViewDetails, linkingUrl, type) {
        return (<a href={linkingUrl}
            onMouseDown={() => {
                isaViewDetails(type);
            }}
            className="button">{buttonText}</a>
        );
    }

    renderContent(dueDate, frequency, type) {
        if (type === 'PaidBy1035') {
            return (
                <div className="cta__message cta__message--1-column">
                    <h5>$0 Payment Due</h5>
                    <p>
                        Your {dueDate} {frequency} premium is paid by a 1035 exchange from one of your life insurance policies.
                    </p>
                    <p>
                        For future payments, if your 1035 echange doesn&#39;t cover the entire amount,
                        you will be asked to pay the balance.
                    </p>
                </div>
            );
        } else if (type === 'PaidBy1035Dividend') {
            return (
                <div className="cta__message cta__message--1-column">
                    <h5>$0 Payment Due</h5>
                    <p>
                        Your {dueDate} {frequency} premium is paid by your allocated dividends and a 1035 exchange
                         from one of your life insurance policies.
                    </p>
                    <p>
                        For future payments, if your allocated dividends and 1035 echange doesn&#39;t cover the entire amount,
                        you will be asked to pay the balance.
                    </p>
                </div>
            );
        }

        return (
            <div className="cta__message cta__message--1-column">
                <h5>$0 Payment Due</h5>
                <p>
                    Your {dueDate} {frequency} premium is paid by your allocated dividends.
                </p>
                <p>
                    For future payments, if your allocated dividends don&#39;t cover the entire amount,
                    you will be asked to pay the balance.
                </p>
            </div>
        );
    }

    renderCard(dueDate, frequency, isaUrl, type, isaViewDetails) {
        const content = this.renderContent(dueDate, frequency, type);
        const seeDetails = this.renderButton('See Details', isaViewDetails, isaUrl, type);
        return (
            <div className="cta-container cta-container--info cta-container--1-column">
                <div className="cta">
                    <div className="cta__icon cta__icon--1-column cta__icon--info" />
                        {content}
                    <div className="cta__button cta__button--1-column">
                        {seeDetails}
                    </div>
                </div>
            </div>
        );
    }

    render() {
        const { cardData, type, isaViewDetails } = this.props;
        const nmcUrl = `${NMC_URL + cardData.isaUrl}`;
        const card = this.renderCard(cardData.dueDate, cardData.frequency, nmcUrl, type, isaViewDetails);

        return (
            <div className="isa-card-content-container">
                {card}
            </div>

        );
    }

}

PaymentZeroDue.propTypes = {
    cardData: React.PropTypes.object,
    type: React.PropTypes.string,
    isaViewDetails: React.PropTypes.func
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(PaymentZeroDue);
