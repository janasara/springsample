import React, { Component } from 'react';

export default class AnnuityDirectInsuredPanel extends Component {

    renderProduct(product) {
        return (
            <div className="isa-card-insured-product__product-info-container">
                <div className="isa-card-insured-product__product-name">{product.productType} - {product.subjectNum}</div>
            </div>
        );
    }

    renderInsured(insured) {
        const rows = this.renderProduct(insured.productList[0]);
        return (
            <div className="isa-card-insured-product">
                <h5 className="isa-card-insured-product__insured-name">{insured.name}, Annuitant</h5>
                {rows}
            </div>
        );
    }

    render() {
        const { insuredList } = this.props;
        // const nmcUrl = `${NMC_URL + isaUrl}`;
        const renderedList = this.renderInsured(insuredList[0]);
        return (
            <div className="insured-2-column">
                {renderedList}
            </div>
        );
    }
}

AnnuityDirectInsuredPanel.propTypes = {
    insuredList: React.PropTypes.array
};
