import React, { Component } from 'react';

export default class MobileAnnuityDirectInsured extends Component {

    renderProduct(product) {
        return (
            <ul className="keyval-chart">
                <li>
                    <span>{product.productType} - {product.subjectNum}</span>
                </li>
            </ul>

        );
    }

    renderInsured(insured) {
        const rows = this.renderProduct(insured.productList[0]);
        return (
            <li className="top-row">
                <div className="title">
                    <p className="insured-name">
                        <strong>{insured.name}</strong>
                        <span className="text-dark-grey">Annuitant</span>
                    </p>
                </div>
                    {rows}
            </li>
        );
    }

    render() {
        const { insuredList } = this.props;
        // const nmcUrl = `${NMC_URL + isaUrl}`;
        const renderedList = this.renderInsured(insuredList[0]);
        return (
            <div className="single-payment-panel billing-mobile-insured">
                {renderedList}
            </div>
        );
    }
}

MobileAnnuityDirectInsured.propTypes = {
    insuredList: React.PropTypes.array
};
