import React, { Component } from 'react';
import startCase from 'lodash/startCase';
import config from '../../../utils/config';

const NMC_URL = config.nmcDomain;

export default class MobileAnnuityRecurringInsured extends Component {

    renderProduct(product, frequency, date, isaUrl) {
        return (
            <ul className="keyval-chart">
                <li>
                    <span>{product.productType} - {product.subjectNum}</span>
                </li>
                <li className="billing-mobile-row annuity">
                    <span className="key">Total</span>
                    <span className="val">{product.payment}</span>
                </li>
                <li className="billing-mobile-row annuity">
                    <span className="key">Scheduled {frequency} Contribution</span>
                    <span className="val">{date}</span>
                </li>
                <li className="billing-mobile-row">
                    <span><a href={isaUrl}>See Details</a></span>
                </li>
            </ul>

        );
    }

    renderInsured(insured, frequency, dueDate, isaUrl) {
        const rows = this.renderProduct(insured.productList[0], frequency, dueDate, isaUrl);
        return (
            <li className="top-row">
                <div className="title">
                    <p className="insured-name">
                        <strong>{insured.name}</strong>
                        <span className="text-dark-grey">Annuitant</span>
                    </p>
                </div>
                    {rows}
            </li>
        );
    }

    render() {
        const { insuredList, frequency, dueDate, isaUrl } = this.props;
        const nmcUrl = `${NMC_URL + isaUrl}`;
        const renderedList = this.renderInsured(insuredList[0], startCase(frequency), dueDate, nmcUrl);
        return (
            <div className="billing-mobile-insured">
                {renderedList}
            </div>
        );
    }
}

MobileAnnuityRecurringInsured.propTypes = {
    insuredList: React.PropTypes.array,
    frequency: React.PropTypes.string,
    dueDate: React.PropTypes.string,
    isaUrl: React.PropTypes.string
};
