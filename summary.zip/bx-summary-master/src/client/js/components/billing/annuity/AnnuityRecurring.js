import React, { Component } from 'react';
import MediaQuery from 'react-responsive';
import MessageColumn from '../shared/MessageColumn';
import AnnuityRecurringInsuredPanel from './AnnuityRecurringInsuredPanel';
import MobileAnnuityRecurringInsured from './MobileAnnuityRecurringInsured';
import mediaQueries from '../../../utils/mediaQueries';

export default class AnnuityRecurring extends Component {

    renderCard(dueDate, frequency, initialIsaData, isaUrl) {
        return (
            <div>
                <MediaQuery query={mediaQueries.$desktopAndPrint} component="div"
                    className="isa-card-2-column-container isa-card-2-column-container--flex" >
                    <AnnuityRecurringInsuredPanel insuredList={initialIsaData} frequency={frequency} dueDate={dueDate} isaUrl={isaUrl} />
                    <MessageColumn isaUrl={isaUrl} type="AnnuityRecurring" />
                </MediaQuery>

                <MediaQuery query={mediaQueries.$mobileAndNotPrint} component="div"
                    className="isa-card-2-column-container isa-card-2-column-container--flex" >
                    <MobileAnnuityRecurringInsured insuredList={initialIsaData} frequency={frequency} dueDate={dueDate} isaUrl={isaUrl} />
                    <MessageColumn isaUrl={isaUrl} type="AnnuityRecurring" />
                </MediaQuery>
            </div>
        );
    }

    render() {
        const { cardData, isaData } = this.props;

        const card = this.renderCard(cardData.dueDate, cardData.frequency, isaData, cardData.isaUrl);

        return (
            <div className="isa-card-content-container">
                {card}
            </div>

        );
    }

}

AnnuityRecurring.propTypes = {
    cardData: React.PropTypes.object,
    isaData: React.PropTypes.array
};
