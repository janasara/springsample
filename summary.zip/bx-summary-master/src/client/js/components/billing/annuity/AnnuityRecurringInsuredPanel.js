import React, { Component } from 'react';
import startCase from 'lodash/startCase';
import { connect } from 'react-redux';
import config from '../../../utils/config';
import { isaViewDetails } from '../../../actions/SummaryActions';

const NMC_URL = config.nmcDomain;

class AnnuityRecurringInsuredPanel extends Component {

    renderButton(buttonText, linkingUrl, type, isaViewDetails) {
        return (<a href={linkingUrl}
                onMouseDown={() => {
                    isaViewDetails(type);
                }}
                className="button">{buttonText}</a>
        );
    }

    renderProduct(product, frequency, date, isaUrl, isaViewDetails, type) {
        const seeDetails = this.renderButton('See Details', isaUrl, type, isaViewDetails);
        return (
            <div>
                <div className="isa-card-insured-product__product-info-container">
                    <div className="isa-card-insured-product__product-name">{product.productType} - {product.subjectNum}</div>
                    <div className="isa-card-insured-product__product-amount">{product.payment}</div>
                </div>
                <div className="isa-card-insured-product__product-info-container">
                    <div className="isa-card-insured-product__product-name">Scheduled {frequency} Contribution</div>
                    <div className="isa-card-insured-product__product-amount">{date}</div>
                </div>
                {seeDetails}
            </div>
        );
    }

    renderInsured(insured, frequency, dueDate, isaUrl, isaViewDetails, type) {
        const rows = this.renderProduct(insured.productList[0], frequency, dueDate, isaUrl, isaViewDetails, type);
        return (
            <div>
                <h5 className="isa-card-insured-product__insured-name">{insured.name}, Annuitant</h5>
                {rows}
            </div>
        );
    }

    render() {
        const { insuredList, frequency, dueDate, isaUrl, isaViewDetails, type } = this.props;
        const nmcUrl = `${NMC_URL + isaUrl}`;
        const renderedList = this.renderInsured(insuredList[0], startCase(frequency), dueDate, nmcUrl, isaViewDetails, type);
        return (
            <div className="insured-2-column">
                {renderedList}
            </div>
        );
    }
}

AnnuityRecurringInsuredPanel.propTypes = {
    insuredList: React.PropTypes.array,
    frequency: React.PropTypes.string,
    dueDate: React.PropTypes.string,
    isaUrl: React.PropTypes.string,
    isaViewDetails: React.PropTypes.func,
    type: React.PropTypes.string
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(AnnuityRecurringInsuredPanel);
