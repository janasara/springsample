import React, { Component } from 'react';
import { connect } from 'react-redux';
import config from '../../../utils/config';
import { isaViewDetails } from '../../../actions/SummaryActions';

const NMC_URL = config.nmcDomain;

class AnnuityRecurringScheduled extends Component {

    renderButton(buttonText, linkingUrl, type, isaViewDetails) {
        return (<a href={linkingUrl}
                onMouseDown={() => {
                    isaViewDetails(type);
                }}
                className="button">{buttonText}</a>
        );
    }

    renderCard(paymentDate, amount, maskedAcctNumber, bankAccountType, confirmationNumber, isaUrl, isaViewDetails, type) {
        const nmcUrl = `${NMC_URL + isaUrl}`;
        const seeDetails = this.renderButton('See Details', nmcUrl, type, isaViewDetails);
        return (
            <div className="isa-card__content">
                <div className="isa-card-payment-scheduled">
                    <h4 className="isa-card__nested-heading">Additional Annuity Contribution Scheduled</h4>
                    <ul className="keyval-chart">
                        <li>
                            <span className="key">Contribution Date</span>
                            <span className="val text-right">{paymentDate}</span>
                        </li>
                        <li>
                            <span className="key">Amount</span>
                            <span className="val text-right">{amount}</span>
                        </li>
                        <li>
                            <span className="key">{bankAccountType} Account</span>
                            <span className="val text-right">{maskedAcctNumber}</span>
                        </li>
                        <li>
                            <span className="key">Confirmation Number</span>
                            <span className="val text-right">{confirmationNumber}</span>
                        </li>
                    </ul>
                </div>
                <div className="cta-container cta-container--default cta-container--2-column">
                    <div className="cta">
                        <div className="cta__message cta__message--no-icon">
                        <h5>Contribution Pending</h5>
                            <p>Your contribution is processing and will be applied on the contribution date.
                            Please allow 1-3 business days for this transaction to be reflected in your {bankAccountType.toLowerCase()} account.</p>
                        </div>
                        <div className="cta__button cta__button--2-column">
                            {seeDetails}
                        </div>
                    </div>
                </div>
            </div>
        );
    }


    render() {
        const { cardData, isaViewDetails, type } = this.props;

        const card = this.renderCard(
            cardData.pendingPayment.paymentDate,
            cardData.pendingPayment.paymentAmount,
            cardData.pendingPayment.maskedBankAccountNumber,
            cardData.pendingPayment.bankAccountType,
            cardData.pendingPayment.confirmationNumber,
            cardData.isaUrl,
            isaViewDetails,
            type
        );

        return (
            <div className="isa-card-content-container">
                {card}
            </div>

        );
    }

}

AnnuityRecurringScheduled.propTypes = {
    cardData: React.PropTypes.object,
    isaViewDetails: React.PropTypes.func,
    type: React.PropTypes.string
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(AnnuityRecurringScheduled);
