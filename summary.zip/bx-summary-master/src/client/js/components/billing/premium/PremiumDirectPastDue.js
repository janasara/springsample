import React, { Component } from 'react';
import MediaQuery from 'react-responsive';
import Payment from '../shared/Payment';
import MobilePayment from '../shared/MobilePayment';
import PastDueFooter from '../shared/PastDueFooter';
import PastDueColumn from '../shared/PastDueColumn';
import mediaQueries from '../../../utils/mediaQueries';

export default class PremiumDirectPastDue extends Component {

    renderCard(totalPaymentDue, dueDate, initialIsaData, isaUrl, serviceCharge, additionalPayment, type) {
        let productCount = 0;
        const isaData = initialIsaData.map((insured) => {
            productCount += insured.productList.length;
            return productCount;
        });

        if (productCount > 4 && isaData.length > 1) {
            return (
                <div>
                    <MediaQuery query={mediaQueries.$desktopAndPrint} component="div" className="billing-multi-col" >
                        <Payment insuredList={initialIsaData} productCount={productCount}
                            serviceCharge={serviceCharge} additionalPayment={additionalPayment} />

                        <PastDueFooter totalPaymentDue={totalPaymentDue} dueDate={dueDate}
                            isaUrl={isaUrl} type={type} />
                    </MediaQuery>

                    <MediaQuery query={mediaQueries.$mobileAndNotPrint} component="div" className="billing-multi-col" >
                        <MobilePayment insuredList={initialIsaData} productCount={productCount}
                            serviceCharge={serviceCharge} additionalPayment={additionalPayment} />

                        <PastDueFooter totalPaymentDue={totalPaymentDue} dueDate={dueDate}
                            isaUrl={isaUrl} type={type} />
                    </MediaQuery>
                </div>
            );
        }

        return (
            <div>
                <MediaQuery query={mediaQueries.$desktopAndPrint} component="div"
                    className="isa-card-1-column-container isa-card-1-column-container--flex" >
                    <Payment insuredList={initialIsaData} productCount={productCount}
                        serviceCharge={serviceCharge} additionalPayment={additionalPayment} />

                    <PastDueColumn totalPaymentDue={totalPaymentDue} dueDate={dueDate}
                        isaUrl={isaUrl} type={type} />
                </MediaQuery>

                <MediaQuery query={mediaQueries.$mobileAndNotPrint} component="div" className="isa-card-1-column-container" >
                    <MobilePayment insuredList={initialIsaData} productCount={productCount}
                        serviceCharge={serviceCharge} additionalPayment={additionalPayment} />

                    <PastDueColumn totalPaymentDue={totalPaymentDue} dueDate={dueDate}
                        isaUrl={isaUrl} type={type} />
                </MediaQuery>
            </div>
        );
    }

    render() {
        const { cardData, isaData, type } = this.props;

        const card = this.renderCard(
            cardData.billedAmount,
            cardData.dueDate,
            isaData,
            cardData.isaUrl,
            cardData.serviceCharge,
            cardData.additionalPayment,
            type
        );

        return (

            <div className="isa-card-content-container">
                {card}
            </div>

        );
    }

}

PremiumDirectPastDue.propTypes = {
    cardData: React.PropTypes.object,
    isaData: React.PropTypes.array,
    type: React.PropTypes.string
};
