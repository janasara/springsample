import React, { Component } from 'react';
import { connect } from 'react-redux';
import config from '../../../utils/config';
import { isaViewDetails } from '../../../actions/SummaryActions';

const NMC_URL = config.nmcDomain;

class PremiumDirectMonthlyPastDue extends Component {

    renderButton(buttonText, linkingUrl, type, isaViewDetails) {
        return (<a href={linkingUrl}
                onMouseDown={() => {
                    isaViewDetails(type);
                }}
                className="button warning">{buttonText}</a>
        );
    }

    renderCard(amountDue, dueDate, pastDueAmount, billedAmount, frequency, frequencyPaymentDue, isaUrl, isaViewDetails) {
        const nmcUrl = `${NMC_URL + isaUrl}`;
        const seeDetails = this.renderButton('See Details', nmcUrl, 'PremiumDirectMonthlyPastDue', isaViewDetails);
        return (

            <div className="cta-container cta-container--warning cta-container--1-column">
                <div className="cta">
                    <div className="cta__icon cta__icon--warning cta__icon--1-column" />
                    <div className="cta__message cta__message--warning cta__message--1-column">
                        <h5 className="cta__heading cta__heading--warning">Your payment of {amountDue} was due on {dueDate}.</h5>
                        <p>
                            Your current total of <strong>{billedAmount}</strong> includes both your {frequency} payment
                            of <strong>{amountDue} plus</strong> the past due amount of <strong>{pastDueAmount}</strong>.
                            Please make a payment to avoid potential loss of coverage.
                        </p>
                    </div>
                    <div className="cta__button cta__button--1-column">
                        {seeDetails}
                    </div>
                </div>
            </div>
        );
    }

    render() {
        const { cardData, isaViewDetails } = this.props;

        const card = this.renderCard(
                cardData.amountDue,
                cardData.dueDate,
                cardData.pastDueAmount,
                cardData.billedAmount,
                cardData.frequency,
                cardData.calculatedPremium,
                cardData.isaUrl,
                isaViewDetails
            );

        return (

            <div className="isa-card-content-container">
                {card}
            </div>
        );
    }

}

PremiumDirectMonthlyPastDue.propTypes = {
    cardData: React.PropTypes.object,
    isaViewDetails: React.PropTypes.func
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(PremiumDirectMonthlyPastDue);
