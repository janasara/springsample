import React, { Component } from 'react';
import { connect } from 'react-redux';
import config from '../../../utils/config';
import { isaViewDetails } from '../../../actions/SummaryActions';

const NMC_URL = config.nmcDomain;

class PremiumDirectSplitPaymentPastDue extends Component {

    renderButton(buttonText, linkingUrl, type, isaViewDetails) {
        return (<a href={linkingUrl}
                onMouseDown={() => {
                    isaViewDetails(type);
                }}
                className="button warning">{buttonText}</a>
        );
    }

    renderCard(totalPaymentDue, dueDate, additionalPayement, frequency, frequencyPaymentDue, isaUrl, isaViewDetails) {
        const nmcUrl = `${NMC_URL + isaUrl}`;
        const seeDetails = this.renderButton('See Details', nmcUrl, 'PremiumDirectSplitPayPastDue', isaViewDetails);
        return (
            <div className="cta-container cta-container--warning cta-container--1-column">
                <div className="cta">
                    <div className="cta__icon cta__icon--1-column cta__icon--warning" />
                    <div className="cta__message cta__message--warning cta__message--1-column">
                        <h5 className="cta__heading cta__heading--warning">Your payment of {totalPaymentDue} was due on {dueDate}.</h5>
                        <p>
                            Due to your requested insurance protection increase,
                            your total payment includes your monthly payment
                            of {frequencyPaymentDue} plus an additional {additionalPayement}.
                            Please make a payment to avoid potential loss of coverage.
                        </p>
                    </div>
                    <div className="cta__button cta__button--1-column">
                        {seeDetails}
                    </div>
                </div>
            </div>
        );
    }

    render() {
        const { cardData, isaViewDetails } = this.props;

        const card = this.renderCard(cardData.amountDue, cardData.dueDate,
            cardData.shortageAmountDue, cardData.frequency, cardData.calculatedPremium, cardData.isaUrl, isaViewDetails);

        return (
            <div className="isa-card-content-container">
                {card}
            </div>
        );
    }

}

PremiumDirectSplitPaymentPastDue.propTypes = {
    cardData: React.PropTypes.object,
    isaViewDetails: React.PropTypes.func
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(PremiumDirectSplitPaymentPastDue);
