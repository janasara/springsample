import React, { Component } from 'react';
import { connect } from 'react-redux';
import config from '../../../utils/config';
import { isaViewDetails } from '../../../actions/SummaryActions';

const NMC_URL = config.nmcDomain;

class PremiumDirectSplitPayment extends Component {

    renderButton(buttonText, linkingUrl, type, isaViewDetails) {
        return (<a href={linkingUrl}
                onMouseDown={() => {
                    isaViewDetails(type);
                }}
                className="button">{buttonText}</a>
        );
    }

    renderCard(totalPaymentDue, dueDate, additionalPayement, frequency, frequencyPaymentDue, isaUrl, isaViewDetails) {
        const nmcUrl = `${NMC_URL + isaUrl}`;
        const makePayment = this.renderButton('Make Payment', nmcUrl, 'PremiumDirectSplitPay', isaViewDetails);
        return (
            <div className="cta-container cta-container--default cta-container--1-column">
                <div className="cta">
                    <div className="cta__message cta__message--no-icon cta__message--1-column">
                        <h5>Total Payment due: {totalPaymentDue}</h5>
                        <p>Due date: {dueDate}</p>
                        <p>
                            Due to your requested insurance protection increase, your total payment includes your{' '}
                            {frequency.toLowerCase()} payment of <strong>{frequencyPaymentDue}</strong> plus an
                            additional <strong>{additionalPayement}</strong>.
                        </p>
                    </div>
                    <div className="cta__button cta__button--1-column">
                        {makePayment}
                    </div>
                </div>
            </div>
        );
    }

    render() {
        const { cardData, isaViewDetails } = this.props;

        const card = this.renderCard(
                cardData.amountDue,
                cardData.dueDate,
                cardData.shortageAmountDue,
                cardData.frequency,
                cardData.calculatedPremium,
                cardData.isaUrl,
                isaViewDetails
            );

        return (

            <div className="isa-card-content-container">
                {card}
            </div>
        );
    }

}

PremiumDirectSplitPayment.propTypes = {
    cardData: React.PropTypes.object,
    isaViewDetails: React.PropTypes.func
};

const mapDispatchToProps = dispatch => ({
    isaViewDetails(type) {
        dispatch(isaViewDetails(type));
    }
});

export default connect(null, mapDispatchToProps)(PremiumDirectSplitPayment);
