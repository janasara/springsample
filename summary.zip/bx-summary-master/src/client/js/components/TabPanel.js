import React, { PropTypes } from 'react';
import classNames from 'classnames';

const TabPanel = ({ children, active, name }) => {
    const classes = classNames('TabPanel', { 'is-active': active });
    const id = name.replace(/ /g, '');
    const panelId = `panel${id}` || 'panelId';
    const tabId = `tab${id}` || 'tabId';
    return (<div tabIndex="0" aria-hidden={!active} className={classes} role="tabpanel"
                id={panelId} aria-labelledby={tabId}>{children}</div>);
};

TabPanel.propTypes = {
    name: PropTypes.string,
    active: PropTypes.bool,
    children: PropTypes.any
};

export default TabPanel;
