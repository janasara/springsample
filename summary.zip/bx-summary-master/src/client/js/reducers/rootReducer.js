import { combineReducers } from 'redux';
import terms from './terms';
import meta from './meta';
import actions from './actions';
import dismissed from './dismissed';
import exceptions from './exceptions';
import financialreps from './financialreps';
import messages from './messages';
import footnotes from './footnotes';
import billing from './billing';
import paperless from './paperless';
import supporthours from './supporthours';
import groups from './groups';
import accounts from './accounts';


const rootReducer = combineReducers({
    actions,
    accounts,
    dismissed,
    terms,
    meta,
    exceptions,
    financialreps,
    messages,
    footnotes,
    billing,
    paperless,
    supporthours,
    groups
});

export default rootReducer;
