import ActionTypes from '../constants/ActionTypes';

export const initialState = {
    lastUpdated: null,
    isFetching: false,
    hasFetched: false,
    didInvalidate: false,
    hasError: false,
    error: null,

    accountsLoaded: false,
    accessFundsData: [],
    annuityData: [],
    insuranceData: [],
    investmentData: []
};

function accounts(state = initialState, { type, payload, meta }) {
    switch (type) {
        case ActionTypes.ACCOUNTS_REQUEST:
            return Object.assign({}, state, {
                isFetching: true
            });
        case ActionTypes.ACCOUNTS_FAILURE:
            return Object.assign({}, state, {
                hasError: true,
                error: payload,
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });
        case ActionTypes.ACCOUNTS_SUCCESS:
            return Object.assign({}, state, {
                accountsLoaded: true,
                ...payload,
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });
        default:
            return state;
    }
}

export default accounts;
