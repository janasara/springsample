export const initialState = [];

const MESSAGES = {
    ACCOUNTS_FAILURE: 'Failed to load Insurance &amp; Investments.',
    NETWORTH_FAILURE: 'Failed to load Net Worth.',
    FINANCIALREPS_FAILURE: 'Failed to load Financial Representatives.',
    SPENDING_FAILURE: 'Failed to load Spending Information.',
    BILLING_FAILURE: 'Failed to load Billing Information',
    MESSAGES_FAILURE: 'Failed to load Messages.'
};

const SILENCED_MESSAGES = {
    TERMS_FAILURE: true,
    FOOTNOTES_FAILURE: true,
    ACCEPT_TERMS_FAILURE: true,
    ACTIONS_FAILURE: true
};

export function isSilenced(type) {
    return !!SILENCED_MESSAGES[type];
}

export function createMessage(type) {
    return (MESSAGES[type]) ? MESSAGES[type] : 'An unexpected error has occurred.';
}

function exceptions(state = initialState, { type, error = false }) {
    if (error && !isSilenced(type)) {
        const message = createMessage(type);
        return (state.indexOf(message) > -1) ? state : state.concat(message);
    }

    return state;
}

export default exceptions;
