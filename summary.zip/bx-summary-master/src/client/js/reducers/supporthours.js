import ActionTypes from '../constants/ActionTypes';

export const initialState = {
    type: 'CustomerService',
    hours: 'Monday - Friday, 7:00 a.m. - 6:00 p.m., Central Time',
    telephone: '(866) 950-4644',
    isDefault: true
};

function supporthours(state = initialState, { type, payload, meta }) {
    switch (type) {
        case ActionTypes.HOURS_REQUEST:
            return Object.assign({}, state, {
                isFetching: true
            });
        case ActionTypes.HOURS_FAILURE:
            return Object.assign({}, state, {
                hasError: true,
                error: {
                    ...payload
                },
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });
        case ActionTypes.HOURS_SUCCESS:
            return Object.assign({}, state, {
                invdetailsLoaded: true,
                ...payload,
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });
        default:
            return state;
    }
}

export default supporthours;
