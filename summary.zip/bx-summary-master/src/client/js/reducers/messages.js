import ActionTypes from '../constants/ActionTypes';

export const initialState = {
    lastUpdated: null,
    isFetching: false,
    hasFetched: false,
    didInvalidate: false,
    hasError: false,
    error: null,

    dismissedSysMessages: false,
    messages: []
};

function messages(state = initialState, { type, payload, meta }) {
    switch (type) {
        case ActionTypes.MESSAGES_REQUEST:
            return Object.assign({}, state, {
                isFetching: true
            });
        case ActionTypes.MESSAGES_FAILURE:
            return Object.assign({}, state, {
                hasError: true,
                error: payload,
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });
        case ActionTypes.MESSAGES_SUCCESS:
            return Object.assign({}, state, {
                messages: payload,
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });
        case ActionTypes.SET_SESSION_STORAGE:
            return Object.assign({}, state, { ...payload });
        default:
            return state;
    }
}

export default messages;
