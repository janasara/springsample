export const initialState = {
    title: 'Summary',
    username: null,
    ua: null
};

const meta = (state = initialState) => state;

export default meta;
