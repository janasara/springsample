// all the the stuff we needs for project 24
import ActionTypes from '../constants/ActionTypes';

export const initialState = {
    enrolled: true,
    featureActive: false, // is any of this stuff prod ready?
    inviteCode: undefined,
    isDismissed: false,
    isLoading: false,
    paperlessModalIsOpen: false,
    showPaperlessTermsSuccess: false,
    showPaperlessTermsFailed: false,
    termsMajorVersion: 0,
    termsMinorVersion: 0,
    termsLanguage: ''
};

function paperless(state = initialState, { type, payload }) {
    switch (type) {
        case ActionTypes.DISMISS_OR_REMIND:
            return Object.assign({}, state, {
                paperlessModalIsOpen: false,
                isDismissed: true
            // isInvite: false
            });
        case ActionTypes.OPEN_PAPERLESS_MODAL:
            return Object.assign({}, state, {
                paperlessModalIsOpen: true
            });
        case ActionTypes.CLOSE_PAPERLESS_MODAL:
            return Object.assign({}, state, {
                paperlessModalIsOpen: false,
                isLoading: false,
                showPaperlessTermsSuccess: false
                // isInvite: false
            });
        case ActionTypes.PAPERLESS_ENROLL_INVITE:
            return Object.assign({}, state, {
                isLoading: true
            });
        case ActionTypes.PAPERLESS_STATUS_SUCCESS:
            return Object.assign({}, state, {
                termsMajorVersion: payload.majorVersion || undefined,
                termsMinorVersion: payload.minorVersion || undefined,
                termsLanguage: payload.language || undefined,
                enrolled: payload.enrolled
            });
        case ActionTypes.PAPERLESS_STATUS_FAILURE:
            return Object.assign({}, state, {
                termsMajorVersion: undefined,
                termsMinorVersion: undefined,
                termsLanguage: undefined
            });
        case ActionTypes.PAPERLESS_ENROLL_REQUEST:
            return Object.assign({}, state, {
                isLoading: true
            });
        case ActionTypes.PAPERLESS_ENROLL_SUCCESS:
            return Object.assign({}, state, {
                isLoading: false,
                showPaperlessTermsSuccess: true
            });
        case ActionTypes.PAPERLESS_ENROLL_FAILURE:
            return Object.assign({}, state, {
                showPaperlessTermsFailed: true,
                isLoading: false
            });
        case ActionTypes.CLOSE_SUCCESS_MODAL:
            return Object.assign({}, state, {
                enrolled: true,
                isDismissed: true,
                paperlessModalIsOpen: false,
                showPaperlessTermsFailed: false,
                showPaperlessTermsSuccess: false
            });
        default:
            return state;
    }
}

export default paperless;
