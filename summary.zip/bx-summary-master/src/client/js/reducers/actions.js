import _includes from 'lodash/includes';
import _uniqBy from 'lodash/uniqBy';
import _sortBy from 'lodash/sortBy';
import ActionTypes from '../constants/ActionTypes';

import ACTION_CONTENT from './data/action-content.json';

export const initialState = {
    lastUpdated: null,
    isFetching: false,
    hasFetched: false,
    didInvalidate: false,

    isLinked: false,
    items: []
};

function makeActionsUnique(items, payload) {
    const filteredItems = _uniqBy(items, 'actionId') // make sure we dont accidently duplicate
        .filter(action => !_includes(payload.dismissed, action.actionId)); // remove dismissed actions
    return _sortBy(filteredItems, 'priority'); // sort remaining actions by priority
}

function mapActionIds(items, username) {
    return items.map(action => Object.assign({}, action, {
        actionId: `action-${username}-${action.actionId}`, // make id unique
        buttonText: action.buttonText
    }));
}

function actions(state = initialState, {
    type,
    payload,
    meta
}) {
    switch (type) {
        case ActionTypes.ACTIONS_REQUEST:
            return Object.assign({}, state, {
                isFetching: true
            });
        case ActionTypes.AUTH_REP_ACTION: {
            let items = state.items;

            if (payload.authrep.cxidAction === 2) {
                const action = ACTION_CONTENT.authRepBiz[0];
                action.href = payload.authrep.cxidUrl;

                const newItems = mapActionIds(ACTION_CONTENT.authRepBiz, payload.username);
                items = items.concat(newItems);
            }

            if (payload.authrep.cxidAction === 1) {
                const action = ACTION_CONTENT.authRepClient[0];
                action.href = payload.authrep.cxidUrl;

                const newItems = mapActionIds(ACTION_CONTENT.authRepClient, payload.username);
                items = items.concat(newItems);
            }

            return Object.assign({}, state, {
                items: makeActionsUnique(items, payload),
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });
        }
        case ActionTypes.LINKING_ACTION: {
            let items = state.items;

            if (!payload.isLinked) {
                const newItems = mapActionIds(ACTION_CONTENT.linkingItems, payload.username);
                items = items.concat(newItems);
            }

            return Object.assign({}, state, {
                items: makeActionsUnique(items, payload),
                isLinked: payload.isLinked,
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });
        }
        case ActionTypes.ACTIONS_SUCCESS: {
            let items = state.items;

            const newItems = mapActionIds(payload.actions, payload.username);
            items = items.concat(newItems);

            return Object.assign({}, state, {
                items: makeActionsUnique(items, payload),
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });
        }
        case ActionTypes.DISMISS_ACTION:
            return Object.assign({}, state, {
                items: state.items.filter(action => action.actionId !== payload)
            }); // eslint-disable-line
        default:
            return state;
    }
}

export default actions;
