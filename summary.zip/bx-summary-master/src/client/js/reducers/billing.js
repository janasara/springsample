import ActionTypes from '../constants/ActionTypes';

export const initialState = {
    lastUpdated: null,
    isFetching: false,
    hasFetched: false,
    didInvalidate: false,
    hasError: false,
    error: null,
    items: [{
        cardType: 'PremiumDirectDue',
        frequency: 'monthly',
        isaNumber: 'xxx0000',
        dueDate: '06/15/2016',
        dueDateAsDate: '2016-06-15T00:00:00',
        isAnnuity: false,
        amountDue: '$126.00',
        serviceCharge: '$1.00',
        additionalPayment: '$0.00',
        insuredList: [{
            productList: [{
                subjectNum: 'xxx0000',
                totalPremium: '$25.00',
                loanRepayment: '$100.00',
                allocatedDiv: '--',
                productType: 'Whole Life',
                freqPremium: '$25.99',
                ltc1035Payment: 'N/A',
                payment: '$125.99',
                productDetailUrl: '/InsuranceDetail?subjectNum=xxx0000',
                isOwnerAndRestricted: false,
                isOwnerAndNotRestricted: false,
                isNotOwner: true,
                annuityCurrentValue: null,
                valueAsOfDate: '',
                isAnnuityTaxQualified: false
            }],
            baseLegalEntityID: '0000000',
            name: 'Jane M Doe',
            loanRepaymentSum: '$100.00',
            allocatedDivSum: '$0.00',
            totalPremiumSum: '$25.99',
            ltc1035Sum: '$0.00',
            paymentSum: '$125.99'
        }],
        isRecurringISA: false,
        paymentStatus: 2,
        isLoanOnly: false,
        totalLoan: 100.0,
        shortageAmountDue: 0.00,
        calculatedPremium: '$126.99',
        nextBillAmount: '$126.99',
        totalLtc1035: 0.0,
        totalDiv: 0.0,
        totalPremium: 25.99,
        isaUrl: '/billing/xxx0000'
    }]
};

function billing(state = initialState, { type, payload, meta }) {
    switch (type) {
        case ActionTypes.BILLING_REQUEST:
            return Object.assign({}, state, {
                isFetching: true
            });
        case ActionTypes.BILLING_FAILURE:
            return Object.assign({}, state, {
                hasError: true,
                error: payload,
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });
        case ActionTypes.BILLING_SUCCESS:
            return Object.assign({}, state, {
                items: payload,
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });

        default:
            return state;
    }
}

export default billing;
