import ActionTypes from '../constants/ActionTypes';

export const initialState = {
    lastUpdated: null,
    isFetching: false,
    hasFetched: false,
    didInvalidate: false,
    hasError: false,
    error: null,

    termsAndConditions: {
        data: [],
        verificationToken: '',
        err: false
    },
    termsState: {
        acceptedTerms: [],
        isTermsActive: false,
        exitTerms: false,
        errorTerms: false,
        currentTerm: 0
    }
};

const terms = (state = initialState, { type, payload, meta }) => {
    switch (type) {
        case ActionTypes.TERMS_REQUEST:
            return Object.assign({}, state, {
                isFetching: true
            });
        case ActionTypes.TERMS_FAILURE:
            return Object.assign({}, state, {
                hasError: true,
                error: payload,
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });
        case ActionTypes.TERMS_SUCCESS:
            return Object.assign({}, state, {
                termsAndConditions: {
                    err: false,
                    data: payload.termsModel,
                    verificationToken: payload.token
                },
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });

        // todo, decide if reusing hasFetched, isFetching, etc. for both get/post is long term preference
        case ActionTypes.ACCEPT_TERMS_REQUEST:
            return Object.assign({}, state, {
                isFetching: true
            });
        case ActionTypes.ACCEPT_TERMS_FAILURE:
            return Object.assign({}, state, {
                hasError: true,
                error: payload,
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt,

                termsAndConditions: {
                    err: true,
                    data: state.termsAndConditions.data
                }
            });
        case ActionTypes.ACCEPT_TERMS_SUCCESS:
            return Object.assign({}, state, {
                hasFetched: true,
                isFetching: false,
                lastUpdated: meta.receivedAt
            });

        case ActionTypes.SET_TERMSTATE:
            return Object.assign({}, state, {
                termsState: {
                    acceptedTerms: payload.acceptedTerms,
                    isTermsActive: payload.isTermsActive,
                    currentTerm: payload.currentTerm,
                    exitTerms: payload.exitTerms,
                    errorTerms: payload.errorTerms
                }
            });

        default:
            return state;
    }
};

export default terms;
