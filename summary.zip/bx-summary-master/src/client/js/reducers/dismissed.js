import { REHYDRATE } from 'redux-persist/constants';
import ActionTypes from '../constants/ActionTypes';

export const initialState = [];

function dismissed(state = initialState, { type, payload }) {
    switch (type) {
        case REHYDRATE:
            return payload.dismissed || initialState;
        case ActionTypes.DISMISS_ITEM:
            // todo prevent duplicates
            return state.concat(payload);
        case ActionTypes.DISMISS_ACTION:
            // todo prevent duplicates
            return state.concat(payload);
        default:
            return state;
    }
}

export default dismissed;
