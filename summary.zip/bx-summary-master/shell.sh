#!/bin/bash

docker run -v `pwd`:/docker -w /docker --rm -it nmlv-cx-summary  /bin/bash
