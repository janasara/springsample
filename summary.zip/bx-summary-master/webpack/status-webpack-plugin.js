const webpack = require('webpack');

module.exports = function(name, doneMessage){

    return new webpack.ProgressPlugin(function(percentage, message) {
      var MOVE_LEFT = new Buffer('1b5b3130303044', 'hex').toString();
      var CLEAR_LINE = new Buffer('1b5b304b', 'hex').toString();
      process.stdout.write(CLEAR_LINE + 'webpack compiling ['+name+']: ' + Math.round(percentage * 100) + '%: ' + message + MOVE_LEFT);
      if(percentage == 1){
          setTimeout(function(){
            process.stdout.write(doneMessage || "webpack say good, fire up...\n");
          },0);
      }
    });

}
