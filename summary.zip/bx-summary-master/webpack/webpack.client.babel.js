const IS_DEV = require('../src/server/utils/isDev');
const path = require('path');
const webpack = require('webpack');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const WebpackAssetsManifest = require('webpack-assets-manifest');
const CaseSensitivePathsPlugin = require('case-sensitive-paths-webpack-plugin');
const StatusWebpackPlugin = require('./status-webpack-plugin');
const config = require('config');
const fs = require('fs');

const basePath = config.basePath;
const hash = IS_DEV
    ? '[name]'
    : '[name]-[chunkhash]';
const root = process.cwd();
const styleLoaders = ['css-loader?minimize&sourceMap&importLoaders=5', 'postcss-loader', 'sass-loader?sourceMap'];
const prefetches = ['react', 'redux'];
const port = 8081;
const host = 'http://localhost';
const contentBase = `${host}:${port}`;
const publicPath = IS_DEV
    ? `${contentBase}${basePath}/assets/`
    : `${basePath}/assets/`;
let babelrc = JSON.parse(fs.readFileSync(path.join(root, '.babelrc'), 'utf8'));

var plugins = [
    new webpack.IgnorePlugin(/\/server\/*/),
    new WebpackAssetsManifest({
        output: path.join(root, '/build/assets', 'asset-manifest.json'),
        writeToDisk: true
    }),
    new CaseSensitivePathsPlugin(),
    new CleanWebpackPlugin(['build/assets'], {
        'root': path.join(__dirname, '../'),
        'verbose': false
    }),
    new webpack.DefinePlugin({
        'IS_BROWSER': true,
        'IS_DEV': IS_DEV,
        'process.env.NODE_ENV': JSON.stringify(IS_DEV
            ? 'development'
            : 'production'),
        'process.env.NODE_APP_INSTANCE': JSON.stringify(process.env.NODE_APP_INSTANCE)
    }),
    ...prefetches.map((i) => new webpack.PrefetchPlugin(i)),
    ...(IS_DEV
        ? [
            new webpack.HotModuleReplacementPlugin(),
            new webpack.SourceMapDevToolPlugin({filename: "[file].map", append: `\n//# sourceMappingURL=${basePath}/assets/[url]`, exclude: ["vendors.js"]}),
            new StatusWebpackPlugin('client')
        ]
        : [
            new webpack.ContextReplacementPlugin(/.*$/, /NEVER_MATCH^/), // ignore dynamic reqires
            new webpack.optimize.OccurrenceOrderPlugin(),
            new webpack.optimize.AggressiveMergingPlugin(),
            new ExtractTextPlugin({filename: `public/${hash}.css`, disable: false, allChunks: true}),
            new webpack.optimize.UglifyJsPlugin(require('./uglifyjs.json'))
        ]),
    // new OfflinePlugin({publicPath:`${basePath}/assets/`, relativePaths: false, caches: {main: ["GuardianSans-Thin-Web.woff"]}, safeToUseOptionalCaches: true, AppCache: false })
];

module.exports = {
    devServer: {
        host,
        port,
        proxy: {
            "**": `${host}:${port}`
        },
        quiet: true,
        noInfo: true,
        hot: true,
        inline: true,
        lazy: false,
        publicPath,
        headers: {
            'Access-Control-Allow-Origin': '*'
        },
        stats: {
            colors: true
        }
    },
    context: path.join(root, 'src'),
    entry: {
        main: IS_DEV
            ? ["webpack/hot/dev-server", `webpack-dev-server/client?${contentBase}`, './client/js/index.js', './client/scss/index.scss']
            : [
                './client/js/index.js', './client/scss/index.scss'
            ],
        criticalpath: ['./client/scss/blur.scss', './client/scss/loaders.scss', './client/scss/fonts.scss']
    },
    output: {
        path: path.join(root, '/build/assets'),
        publicPath, // needed so fonts can be found
        filename: hash + '.js',
        chunkFilename: hash + '.js'
    },
    externals: {
        'window.newrelic': 'newrelic'
    },
    plugins: plugins,
    module: {
        rules: [
            {
                test: /\.js$/,
                loader: 'babel-loader',
                include: path.join(root, 'src'),
                options: {
                    cacheDirectory: false,
                    babelrc: false,
                    ...(IS_DEV)
                        ? Object.assign({}, babelrc, {
                            presets: [].concat(babelrc.presets, ['react-hmre'])
                        })
                        : babelrc
                }
            }, {
                test: /\.json$/,
                loader: 'json-loader'
            }, {
                test: /\.(jpe?g|png|gif)([\?]?.*)$/,
                include: [path.join(root, 'src/client')],
                use: ['url-loader?limit=100', 'image-webpack-loader?bypassOnDebug&optimizationLevel=7&interlaced=false'],
            }, {
                test: /\.(woff|woff2|eot|ttf|svg)([?]?.*)$/,
                use: 'file-loader?name=[name].[ext]', //name fonts to enable de-dup shared header/footer fonts
            }, {
                test: /.s?css$/,
                include: [
                    path.join(root, 'src/client'),
                    path.resolve(root, 'node_modules')
                ],
                loader: IS_DEV
                    ? 'style-loader!' + styleLoaders.join('!')
                    : ExtractTextPlugin.extract({fallback: 'style-loader', use: styleLoaders})
            }
        ]
    }
};
