import webpack from 'webpack';
import DevServer from 'webpack-dev-server';
import config from './webpack.client.babel';

const { port, host } = config.devServer;

const devServer = new DevServer(webpack(config), config.devServer)
    .listen(port, () => {
        console.log(`HMR server on ${host}:${port} [${process.env.NODE_ENV}]`);
    });
