import request from 'supertest';
import { expect } from 'chai';
import { Router } from 'express';
import proxyquire from 'proxyquire';

let fake = new Router();
fake.use(function (req, res) {
    res.json({});
});

let app = proxyquire
    .noCallThru()
    .load('../../src/server/app', {
        './routes/health': fake,
        './routes/info': fake,
        './routes/root': fake,
        './routes/api/frsummary': fake,
    }).default;

describe('test the main application', function() {

    // it('should be registered for a health route', function (done) {
    //     request(app)
    //         .get('/summary/health')
    //         .expect('Content-Type', /json/)
    //         .expect(200)
    //         .end(function (err, res) {
    //             if (err) {
    //                 return done(err);
    //             }
    //             expect(res.body).to.deep.equal({});
    //             done();
    //         });
    // });
    //
    // it('should be registered for a info route', function (done) {
    //     request(app)
    //         .get('/summary/info')
    //         .expect('Content-Type', /json/)
    //         .expect(200)
    //         .end(function (err, res) {
    //             if (err) {
    //                 return done(err);
    //             }
    //             expect(res.body).to.deep.equal({});
    //             done();
    //         });
    // });
    //
    // it('should be registered for a spending route', function (done) {
    //     request(app)
    //         .get('/summary/api/spending')
    //         .expect('Content-Type', /json/)
    //         .expect(200)
    //         .end(function (err, res) {
    //             if (err) {
    //                 return done(err);
    //             }
    //             expect(res.body).to.deep.equal({});
    //             done();
    //         });
    // });
    //
    // it('should be registered for a networth route', function (done) {
    //     request(app)
    //         .get('/summary/api/networth')
    //         .expect('Content-Type', /json/)
    //         .expect(200)
    //         .end(function (err, res) {
    //             if (err) {
    //                 return done(err);
    //             }
    //             expect(res.body).to.deep.equal({});
    //             done();
    //         });
    // });
    //
    // it('should be registered for a frsummary route', function (done) {
    //     request(app)
    //         .get('/summary/api/frsummary')
    //         .expect('Content-Type', /json/)
    //         .expect(200)
    //         .end(function (err, res) {
    //             if (err) {
    //                 return done(err);
    //             }
    //             expect(res.body).to.deep.equal({});
    //             done();
    //         });
    // });
    //
    // it('should be registered for a accounts route', function (done) {
    //     request(app)
    //         .get('/summary/api/accounts')
    //         .expect('Content-Type', /json/)
    //         .expect(200)
    //         .end(function (err, res) {
    //             if (err) {
    //                 return done(err);
    //             }
    //             expect(res.body).to.deep.equal({});
    //             done();
    //         });
    // });

    // it('should be registered to handle 404', function (done) {
    //     request(app)
    //         .get('/summary/api/junk')
    //         .expect('Content-Type', /json/)
    //         .expect(404)
    //         .end(function (err, res) {
    //             if (err) {
    //                 return done(err);
    //             }
    //             done();
    //         });
    // });
});
