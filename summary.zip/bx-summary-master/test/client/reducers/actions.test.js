import { expect } from 'chai';
import actions, { initialState } from './../../../src/client/js/reducers/actions';
import ActionTypes from './../../../src/client/js/constants/ActionTypes';

describe('actions reducer', function() {

    it('should return its default state', () => {
        let nextState = actions(undefined, { type: 'unknown'} );
        expect(nextState).to.deep.equal(initialState);
    });

});
