import { expect } from 'chai';
import billing, { initialState } from './../../../src/client/js/reducers/billing';
import ActionTypes from './../../../src/client/js/constants/ActionTypes';

describe('billing reducer', function() {

    it('should return its default state', () => {
        let nextState = billing(undefined, { type: 'unknown'} );
        expect(nextState).to.deep.equal(initialState);
    });

});
