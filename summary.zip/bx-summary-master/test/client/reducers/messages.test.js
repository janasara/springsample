import { expect } from 'chai';
import messages, { initialState } from './../../../src/client/js/reducers/messages';
import ActionTypes from './../../../src/client/js/constants/ActionTypes';

describe('messages reducer', function() {

    it('should return its default state', () => {
        let nextState = messages(undefined, { type: 'unknown'} );
        expect(nextState).to.deep.equal(initialState);
    });

});
