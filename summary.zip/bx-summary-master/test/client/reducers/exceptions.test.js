import { expect } from 'chai';
import exceptions, { initialState } from './../../../src/client/js/reducers/exceptions';
import ActionTypes from './../../../src/client/js/constants/ActionTypes';

describe('exceptions reducer', function() {

    it('should return its default state', () => {
        let nextState = exceptions(undefined, { type: 'unknown'} );
        expect(nextState).to.deep.equal(initialState);
    });

});
