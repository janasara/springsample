import { expect } from 'chai';
import terms, { initialState } from './../../../src/client/js/reducers/terms';
import ActionTypes from './../../../src/client/js/constants/ActionTypes';

describe('terms reducer', function() {

    it('should return its default state', () => {
        let nextState = terms(undefined, { type: 'unknown'} );
        expect(nextState).to.deep.equal(initialState);
    });

});
