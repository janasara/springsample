import { expect } from 'chai';
import footnotes, { initialState } from './../../../src/client/js/reducers/footnotes';
import ActionTypes from './../../../src/client/js/constants/ActionTypes';

describe('footnotes reducer', function() {

    it('should return its default state', () => {
        let nextState = footnotes(undefined, { type: 'unknown'} );
        expect(nextState).to.deep.equal(initialState);
    });

});
