import { expect } from 'chai';
import meta, { initialState } from './../../../src/client/js/reducers/meta';
import ActionTypes from './../../../src/client/js/constants/ActionTypes';

describe('meta reducer', function() {

    it('should return its default state', () => {
        let nextState = meta(undefined, { type: 'unknown'} );
        expect(nextState).to.deep.equal(initialState);
    });

});
