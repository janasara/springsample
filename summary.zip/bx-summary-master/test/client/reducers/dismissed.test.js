import { expect } from 'chai';
import dismissed, { initialState } from './../../../src/client/js/reducers/dismissed';
import ActionTypes from './../../../src/client/js/constants/ActionTypes';

describe('dismissed reducer', function() {

    it('should return its default state', () => {
        let nextState = dismissed(undefined, { type: 'unknown'} );
        expect(nextState).to.deep.equal(initialState);
    });

});
