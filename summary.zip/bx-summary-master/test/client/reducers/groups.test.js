import { expect } from 'chai';
import groups, { initialState } from './../../../src/client/js/reducers/groups';

describe('groups reducer', function () {

    it('should return its default state', () => {
        const nextState = groups(undefined, { type: 'unknown'} );
        expect(nextState).to.deep.equal(initialState);
    });
});
