import React from 'react';
import { expect } from 'chai';
import sinon from 'sinon';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import types from './../../../src/client/js/constants/ActionTypes';
import { fetchGroups, fetchActions, fetchBilling, fetchFinancialreps,
fetchFootnotes, fetchMessages, fetchTerms } from './../../../src/client/js/actions/ApiActions';
import { GROUPS_API_URL, BILLING_MOCK_API_URL, FR_SUMMARY_API_URL } from './../../../src/client/js/actions/ApiUrls';
import config from './../../../src/client/js/utils/config';

const middlewares = [ thunk ];
const mockStore = configureMockStore(middlewares);
const store = mockStore({});

const { accepttermsUrl, actionsUrl, billingUrl, footnotesUrl, messagesUrl, termsUrl } = config.clientCrossOriginUrls;

describe('ApiActions fetchFinancialreps()', function() {

    beforeEach(() => {
        fetchMock.restore();
        store.clearActions();
        sinon.useFakeTimers(new Date(3030,1,1).getTime());
    });

    it('Should return results', () => {

        fetchMock.mock(FR_SUMMARY_API_URL, []);
        return store.dispatch(fetchFinancialreps()).then(() => {
            let expectedActions = [
                { type: types.FINANCIALREPS_REQUEST },
                { type: types.FINANCIALREPS_SUCCESS, payload: [], meta: { receivedAt: Date.now() } }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });

    it('Should trigger error action on exception', () => {
        let error = new Error('failure');
        fetchMock.mock(FR_SUMMARY_API_URL, {
            throws: error
        });

        return store.dispatch(fetchFinancialreps()).then(() => {
            let expectedActions = [
                { type: types.FINANCIALREPS_REQUEST },
                { type: types.FINANCIALREPS_FAILURE, payload: error, error: true, meta: { receivedAt: Date.now() }  }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });

    it('Should trigger error action on 500', () => {
        let error = new Error('Internal Server Error');
        fetchMock.mock(FR_SUMMARY_API_URL, {
            status: 500
        });

        return store.dispatch(fetchFinancialreps()).then(() => {
            let expectedActions = [
                { type: types.FINANCIALREPS_REQUEST },
                { type: types.FINANCIALREPS_FAILURE, payload: error, error: true, meta: { receivedAt: Date.now() }  }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });
});

describe('ApiActions fetchFootnotes()', function() {
    beforeEach(() => {
        fetchMock.restore();
        store.clearActions();
        sinon.useFakeTimers(new Date(3030,1,1).getTime());
    });
    it('Should return results', () => {

        fetchMock.mock(footnotesUrl, []);
        return store.dispatch(fetchFootnotes()).then(() => {
            let expectedActions = [
                { type: types.FOOTNOTES_REQUEST },
                { type: types.FOOTNOTES_SUCCESS, payload: [], meta: { receivedAt: Date.now() } }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });

    it('Should trigger error action on exception', () => {
        let error = new Error('failure');
        fetchMock.mock(footnotesUrl, {
            throws: error
        });

        return store.dispatch(fetchFootnotes()).then(() => {
            let expectedActions = [
                { type: types.FOOTNOTES_REQUEST },
                { type: types.FOOTNOTES_FAILURE, payload: error, error: true, meta: { receivedAt: Date.now() }  }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });

    it('Should trigger error action on 500', () => {
        let error = new Error('Internal Server Error');
        fetchMock.mock(footnotesUrl, {
            status: 500
        });

        return store.dispatch(fetchFootnotes()).then(() => {
            let expectedActions = [
                { type: types.FOOTNOTES_REQUEST },
                { type: types.FOOTNOTES_FAILURE, payload: error, error: true, meta: { receivedAt: Date.now() }  }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });
  });

describe('ApiActions fetchMessages()', function() {

    beforeEach(() => {
        fetchMock.restore();
        store.clearActions();
        sinon.useFakeTimers(new Date(3030,1,1).getTime());
    });

    it('Should return results', () => {

        fetchMock.mock(messagesUrl, []);
        return store.dispatch(fetchMessages()).then(() => {
            let expectedActions = [
                { type: types.MESSAGES_REQUEST },
                { type: types.MESSAGES_SUCCESS, payload: [], meta: { receivedAt: Date.now() } }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });

    it('Should trigger error action on exception', () => {
        let error = new Error('failure');
        fetchMock.mock(messagesUrl, {
            throws: error
        });

        return store.dispatch(fetchMessages()).then(() => {
            let expectedActions = [
                { type: types.MESSAGES_REQUEST },
                { type: types.MESSAGES_FAILURE, payload: error, error: true, meta: { receivedAt: Date.now() }  }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });

    it('Should trigger error action on 500', () => {
        let error = new Error('Internal Server Error');
        fetchMock.mock(messagesUrl, {
            status: 500
        });

        return store.dispatch(fetchMessages()).then(() => {
            let expectedActions = [
                { type: types.MESSAGES_REQUEST },
                { type: types.MESSAGES_FAILURE, payload: error, error: true, meta: { receivedAt: Date.now() }  }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });
});

describe('ApiActions fetchTerms()', function() {

    beforeEach(() => {
        fetchMock.restore();
        store.clearActions();
        sinon.useFakeTimers(new Date(3030,1,1).getTime());
    });

    it('Should return results', () => {

        fetchMock.mock(termsUrl, []);
        return store.dispatch(fetchTerms()).then(() => {
            let expectedActions = [
                { type: types.TERMS_REQUEST },
                { type: types.TERMS_SUCCESS, payload: [], meta: { receivedAt: Date.now() } }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });

    it('Should trigger error action on exception', () => {
        let error = new Error('failure');
        fetchMock.mock(termsUrl, {
            throws: error
        });

        return store.dispatch(fetchTerms()).then(() => {
            let expectedActions = [
                { type: types.TERMS_REQUEST },
                { type: types.TERMS_FAILURE, payload: error, error: true, meta: { receivedAt: Date.now() }  }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });

    it('Should trigger error action on 500', () => {
        let error = new Error('Internal Server Error');
        fetchMock.mock(termsUrl, {
            status: 500
        });

        return store.dispatch(fetchTerms()).then(() => {
            let expectedActions = [
                { type: types.TERMS_REQUEST },
                { type: types.TERMS_FAILURE, payload: error, error: true, meta: { receivedAt: Date.now() }  }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });
});


describe('ApiActions fetchBilling()', function() {

    beforeEach(() => {
        fetchMock.restore();
        store.clearActions();
        sinon.useFakeTimers(new Date(3030,1,1).getTime());
    });

    it('Should return results', () => {

        fetchMock.mock(billingUrl, []);
        return store.dispatch(fetchBilling()).then(() => {
            let expectedActions = [
                { type: types.BILLING_REQUEST },
                { type: types.BILLING_SUCCESS, payload: [], meta: { receivedAt: Date.now() } }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });

    it('Should trigger error action on exception', () => {
        let error = new Error('failure');
        fetchMock.mock(billingUrl, {
            throws: error
        });

        return store.dispatch(fetchBilling()).then(() => {
            let expectedActions = [
                { type: types.BILLING_REQUEST },
                { type: types.BILLING_FAILURE, payload: error, error: true, meta: { receivedAt: Date.now() }  }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });

    it('Should trigger error action on 500', () => {
        let error = new Error('Internal Server Error');
        fetchMock.mock(billingUrl, {
            status: 500
        });

        return store.dispatch(fetchBilling()).then(() => {
            let expectedActions = [
                { type: types.BILLING_REQUEST },
                { type: types.BILLING_FAILURE, payload: error, error: true, meta: { receivedAt: Date.now() }  }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });
});
describe('ApiActions fetchGroups()', function () {

    beforeEach(() => {
        fetchMock.restore();
        store.clearActions();
        sinon.useFakeTimers(new Date(3030,1,1).getTime());
    });

    it('Should return results', () => {

        fetchMock.mock(GROUPS_API_URL, []);
        return store.dispatch(fetchGroups()).then(() => {
            const expectedActions = [
                { type: types.GROUPS_REQUEST },
                { type: types.GROUPS_SUCCESS, payload: [], meta: { receivedAt: Date.now() } }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });

    it('Should trigger error action on exception', () => {
        const error = new Error('failure');
        fetchMock.mock(GROUPS_API_URL, {
            throws: error
        });

        return store.dispatch(fetchGroups()).then(() => {
            const expectedActions = [
                { type: types.GROUPS_REQUEST },
                { type: types.GROUPS_FAILURE, payload: error, error: true, meta: { receivedAt: Date.now() }  }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });

    it('Should trigger error action on 500', () => {
        const error = new Error('Internal Server Error');
        fetchMock.mock(GROUPS_API_URL, {
            status: 500
        });

        return store.dispatch(fetchGroups()).then(() => {
            const expectedActions = [
                { type: types.GROUPS_REQUEST },
                { type: types.GROUPS_FAILURE, payload: error, error: true, meta: { receivedAt: Date.now() }  }
            ];
            expect(store.getActions()).to.deep.include.members(expectedActions);
        });
    });
});
