import React from 'react';
import { expect } from 'chai';
import {setTermsState, setSessionStorageData, dismissAction } from './../../../src/client/js/actions/SummaryActions';
import ActionTypes from './../../../src/client/js/constants/ActionTypes';
import fetchMock from 'fetch-mock';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import termsJSON from './../../../src/server/mock/terms'

const middlewares = [ thunk ];
const mockStore = configureMockStore(middlewares);
const store = mockStore({ });

describe('SummaryActions', function() {
    beforeEach(() => {
        fetchMock.restore();
    });

    it('Should set term state', () => {
        let action = setTermsState(termsJSON, ActionTypes.TERMS_SUCCESS);
        expect(action).to.deep.equal({
            type: ActionTypes.SET_TERMSTATE,
            payload: termsJSON
        });
    });

    it('Should set session storage', () => {
        let action = setSessionStorageData('dismissedSysMessages', true);
        expect(action).to.deep.equal({
            type: ActionTypes.SET_SESSION_STORAGE,
            payload: {
                dismissedSysMessages: true
            }
        });
    });

    it('Should set term state', () => {
        let action = setTermsState({
            acceptedTerms: false,
            errorTerms: null,
            exitTerms: null,
            isTermsActive: true,
            currentTerm: 1
        });
        let payload = {
            acceptedTerms: false,
            errorTerms: null,
            exitTerms: null,
            isTermsActive: true,
            currentTerm: 1
        };
        expect(action).to.deep.equal({
            type: ActionTypes.SET_TERMSTATE,
            payload
        });
    });

    it('Should dismiss action', () => {
        let action = dismissAction('ISA-1');

        expect(action).to.deep.equal({
            type: ActionTypes.DISMISS_ACTION,
            payload: 'ISA-1',
            meta: {
                analytics: {
                    type: ActionTypes.DISMISS_ACTION,
                    payload: { 'actionId': 'ISA-1'}
                }
            }
        });
    });

});
