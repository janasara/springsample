import React from 'react';
import { expect } from 'chai';
import { shallow, mount, render } from 'enzyme';

import {TermsAndConditions} from './../../../src/client/js/components/TermsAndConditions';
import * as Actions from  './../../../src/client/js/actions/SummaryActions';

import { terms } from './mock/terms';
import { emptyTerms } from './mock/terms-empty';
import { multiTerms } from './mock/terms-multiple';

const method = Actions.acceptTerms;


describe('<TermsAndConditions/>', function() {

    it('should render', () => {
        let mockData = {
            TCData: {data: terms.termsModel},
            acceptTerms: method,
            verificationToken: terms.token,
            termsState: {
                acceptedTerms: [],
                isTermsActive: true,
                exitTerms: false,
                errorTerms: false,
                currentTerm: 0
            }
        }
        let TCWrapper = shallow(<TermsAndConditions {...mockData}/>);
        expect(TCWrapper.find('#terms-modal')).to.have.length(1);
    });

    it('should not render', () => {
        let mockData = {
            TCData: {data: emptyTerms.termsModel},
            acceptTerms: method,
            verificationToken: emptyTerms.token,
            termsState: {
                acceptedTerms: [],
                isTermsActive: false,
                exitTerms: false,
                errorTerms: false,
                currentTerm: null
            }
        }
        let TCWrapper = shallow(<TermsAndConditions {...mockData}/>);
        expect(TCWrapper.find('#terms-modal')).to.have.length(0);
    });


});
