import React from 'react';
import { expect } from 'chai';
import { shallow, mount, render } from 'enzyme';
import sinon from 'sinon';

import { ConfirmModal } from './../../../../src/client/js/components/termsconditions/ConfirmModal';
import * as Actions from  './../../../../src/client/js/actions/SummaryActions';

import { terms } from './../mock/terms';
import { emptyTerms } from './../mock/terms-empty';
import { multiTerms } from './../mock/terms-multiple';


const method = Actions.acceptTerms;
const termStateMethod = Actions.setTermsState;


describe('TermsAndConditions <ConfirmModal/>', function() {

    it('should render', () => {
        const mockData = {
            TCData: {data: terms.termsModel},
            acceptTerms: method,
            verificationToken: terms.token,
            termsState: {
                acceptedTerms: [
                    {
                        accepted: false,
                        id: 0
                    }
                ],
                isTermsActive: true,
                exitTerms: true,
                errorTerms: null,
                currentTerm: 0
            }
        };

        // stoooooooopid
        global.window = {
            'location': {
                'href': ''
            },
            '__CONFIG__': {
                'nmcDomain': 'http://test.test'
            }
        };

        let TCWrapper = shallow(<ConfirmModal {...mockData}/>);
        expect(TCWrapper.find('#confirm-modal')).to.have.length(1);
    });

    it('logout', () => {
        const mockData = {
            TCData: {data: terms.termsModel},
            acceptTerms: method,
            verificationToken: terms.token,
            termsState: {
                acceptedTerms: [
                    {
                        accepted: false,
                        id: 0
                    }
                ],
                isTermsActive: true,
                exitTerms: true,
                errorTerms: null,
                currentTerm: 0
            }
        };

        sinon.spy(ConfirmModal.prototype, 'exitConfirmModal');
        let exitConfirm = shallow(<ConfirmModal {...mockData}/>);

        exitConfirm.find('#exit-terms').simulate('click');

        expect(ConfirmModal.prototype.exitConfirmModal.calledOnce).to.be.equal(true);
    });

    it('view terms again', () => {
        const mockData = {
            TCData: {data: terms.termsModel},
            acceptTerms: method,
            verificationToken: terms.token,
            termsState: {
                acceptedTerms: [
                    {
                        accepted: false,
                        id: 0
                    }
                ],
                isTermsActive: true,
                exitTerms: true,
                errorTerms: null,
                currentTerm: 0
            },
            setTermsState: () => {}
        };

        sinon.spy(ConfirmModal.prototype, 'toggleExitTerms');
        let view = shallow(<ConfirmModal {...mockData}/>);

        view.find('#view-terms').simulate('click');

        expect(ConfirmModal.prototype.toggleExitTerms.calledOnce).to.be.equal(true);
    });

});
