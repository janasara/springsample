import React from 'react';
import { expect } from 'chai';
import { shallow, mount, render } from 'enzyme';
import sinon from 'sinon';

import { ErrorModal } from './../../../../src/client/js/components/termsconditions/ErrorModal';
import * as Actions from  './../../../../src/client/js/actions/SummaryActions';

import { terms } from './../mock/terms';
import { emptyTerms } from './../mock/terms-empty';
import { multiTerms } from './../mock/terms-multiple';


const method = Actions.acceptTerms;
const termStateMethod = Actions.setTermsState;


describe('TermsAndConditions <ErrorModal/>', function() {

    it('should render', () => {
        let mockData = {
            TCData: {data: terms.termsModel},
            acceptTerms: method,
            verificationToken: terms.token,
            termsState: {
                acceptedTerms: [
                    {
                        accepted: false,
                        id: 0
                    }
                ],
                isTermsActive: true,
                exitTerms: null,
                errorTerms: true,
                currentTerm: 0
            }
        }
        let TCWrapper = shallow(<ErrorModal {...mockData}/>);
        expect(TCWrapper.find('#error-modal')).to.have.length(1);
    });

    it('logout', () => {
        let mockData = {
            TCData: {data: terms.termsModel},
            acceptTerms: method,
            verificationToken: terms.token,
            termsState: {
                acceptedTerms: [
                    {
                        accepted: false,
                        id: 0
                    }
                ],
                isTermsActive: true,
                exitTerms: true,
                errorTerms: null,
                currentTerm: 0
            }
        }
        sinon.spy(ErrorModal.prototype, 'exitConfirmModal');
        let exitConfirm = shallow(<ErrorModal {...mockData}/>);

        exitConfirm.find('#exit-terms').simulate('click');

        expect(ErrorModal.prototype.exitConfirmModal.calledOnce).to.be.equal(true);
    });

    it('view terms again', () => {
        let mockData = {
            TCData: {data: terms.termsModel},
            acceptTerms: method,
            verificationToken: terms.token,
            termsState: {
                acceptedTerms: [
                    {
                        accepted: false,
                        id: 0
                    }
                ],
                isTermsActive: true,
                exitTerms: true,
                errorTerms: null,
                currentTerm: 0
            },
            setTermsState: termStateMethod
        }
        sinon.spy(ErrorModal.prototype, 'resetTermsAndConditions');
        let view = shallow(<ErrorModal {...mockData}/>);

        view.find('#view-terms').simulate('click');

        expect(ErrorModal.prototype.resetTermsAndConditions.calledOnce).to.be.equal(true);
    });


});
