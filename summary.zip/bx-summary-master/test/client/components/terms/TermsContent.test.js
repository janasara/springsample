import React from 'react';
import { expect } from 'chai';
import { shallow, mount, render } from 'enzyme';

import {TermsContent} from './../../../../src/client/js/components/termsconditions/TermsContent';
import * as Actions from  './../../../../src/client/js/actions/SummaryActions';

import terms from './../mock/terms.json';
import { emptyTerms } from './../mock/terms-empty';
import { multiTerms } from './../mock/terms-multiple';


const method = Actions.acceptTerms;


describe('TermsAndConditions <TermsContent/>', function() {

    it('should render', () => {
        let mockData = {
            TCData: terms.termsAndConditions.data,
            acceptTerms: method,
            verificationToken: terms.token,
            termsState: {
                acceptedTerms: [],
                isTermsActive: true,
                exitTerms: false,
                errorTerms: false,
                currentTerm: ''
            },
            currentTerm: 0,
            acceptedTerms: []
        };
        let TCWrapper = shallow(<TermsContent {...mockData}/>);
        expect(TCWrapper.find('#terms-conditions-content')).to.have.length(1);
    });

});
