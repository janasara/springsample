import React from 'react';
import { expect } from 'chai';
import { shallow, mount, render } from 'enzyme';
import sinon from 'sinon';
import { Messages } from './../../../src/client/js/components/Messages';
import * as Actions from  './../../../src/client/js/actions/SummaryActions';

import { messageData } from './mock/messages';

const method = Actions.setSessionStorageData;

describe("<Message/>", function() {

    it('Should have 2 messages', () => {
        let message = shallow(<Messages messages={messageData} setSessionStorageData={method}/>);
        expect(message.find('.message').length).to.be.equal(2);
    });

    it('Service message should be dimissable', () => {
        sinon.spy(Messages.prototype, 'handleClick');
        let message = shallow(<Messages messages={messageData} setSessionStorageData={method}/>);

        message.find('.dismiss-sys-msg').simulate('click', { preventDefault() {} });

        expect(Messages.prototype.handleClick.calledOnce).to.be.equal(true);
    });

});
