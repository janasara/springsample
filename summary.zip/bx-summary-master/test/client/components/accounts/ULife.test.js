import React from 'react';
import { expect } from 'chai';
import { shallow, mount } from 'enzyme';
import { Accounts } from './../../../../src/client/js/components/Accounts';
import ULife from './../../../../src/client/js/components/accounts/ULife';
import { mockState } from './../mock/mock-state';

const mockGroupData = mockState.accounts.ulifeData;
const accounts = shallow(<Accounts {...mockState.accounts} hasFetched />);
const ulife = mount(<ULife ulifeData={accounts.instance().props.ulifeData} />);

describe('<ULife/>', () => { //eslint-disable-line
    it('Should render when it has data', () => { //eslint-disable-line
        expect(ulife.find('table').length).to.be.equal(1);
    });

    it('Should not render when it doesnt', () => { //eslint-disable-line
        const ulife = mount(<ULife ulifeData={[]} />);
        expect(ulife.find('table').length).to.be.equal(0);
    });

    it('Should have 5 total groups', () => { //eslint-disable-line
        expect(ulife.find('.solo-row').length).to.be.equal(5);
    });

    it('Should display the Group Policy Data', () => { //eslint-disable-line
        const tableRows = ulife.find('.solo-row');
        tableRows.forEach((row, index) => {
            const rowData = row.find('td');
            const groupPolicy = mockGroupData[index];
            const expectedgroupPolicyData = [
                `${groupPolicy.groupName} - ${groupPolicy.groupNumberMasked}${(groupPolicy.policyCount > 1) ?
                ` ${groupPolicy.policyCount} Policies` : ''}`,
                `${groupPolicy.netDeathBenefit}`,
                `${groupPolicy.contractFundInvestedAssetsValue}`,
                `${groupPolicy.cashSurrenderValue}`,
                `${groupPolicy.costBasisValue}`];
            rowData.forEach((column, index) => {
                expect(column.text().trim()).to.be.equal(expectedgroupPolicyData[index]);
            });
        });
    });
});
