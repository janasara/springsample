import React from 'react';
import { expect } from 'chai';
import { shallow, mount } from 'enzyme';

import { Accounts } from './../../../../src/client/js/components/Accounts';
import Disability from './../../../../src/client/js/components/accounts/Disability';
import DisabilityMobile from './../../../../src/client/js/components/accounts/DisabilityMobile';

import { mockState } from './../mock/mock-state';

describe('<Disability/>', () => { //eslint-disable-line
    it('Should render when it has data', () => { //eslint-disable-line
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const disability = shallow(<Disability diData={insurance.instance().props.bdiData} />);

        expect(disability.find('table').length).to.be.equal(1);
    });

    it('Should not render when it doesnt', () => { //eslint-disable-line
        const disability = shallow(<Disability diData={[]} />);

        expect(disability.find('table').length).to.be.equal(0);
    });

    it('Should have 10 rows', () => { //eslint-disable-line
        const insurance = shallow(<Accounts {...mockState.accounts} />);
        const disability = mount(<Disability diData={insurance.instance().props.bdiData} />);

        expect(disability.find('.solo-row').length).to.be.equal(10);
    });

    it('Should display the DI Policy Data', () => { //eslint-disable-line
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const life = mount(<Disability diData={insurance.instance().props.bdiData} />);
        const tableRows = life.find('.solo-row');
        tableRows.forEach((row, index) => {
            const rowData = row.find('td');
            const diPolicy = insurance.instance().props.bdiData[index];
            let expectedDIPolicyData = [
                `${diPolicy.accountTypeDetail} - ${diPolicy.accountNumberMasked}`,
                `${diPolicy.benefit}`,
                `${diPolicy.annualizedPremium}`
            ];
            // Convert undefined to N/A as that transformation is done in component
            expectedDIPolicyData = expectedDIPolicyData.map(attr => (attr === 'undefined' ? 'N/A' : attr));
            rowData.forEach((column, index) => {
                expect(column.text().trim()).to.be.equal(expectedDIPolicyData[index]);
            });
        });
    });
});

describe('<DisabilityMobile/>', () => { //eslint-disable-line
    it('Should render when it has data', () => { //eslint-disable-line
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const disability = mount(<DisabilityMobile data={insurance.instance().props.bdiData} />);

        expect(disability.find('.di-list').length).to.be.equal(1);
    });

    it('Should not render when it doesnt', () => { //eslint-disable-line
        const disability = shallow(<DisabilityMobile data={[]} />);

        expect(disability.find('.life-list').length).to.be.equal(0);
    });

    it('Should have 10 rows', () => { //eslint-disable-line
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const disability = mount(<DisabilityMobile data={insurance.instance().props.bdiData} />);

        expect(disability.find('.top-row').length).to.be.equal(10);
    });
});
