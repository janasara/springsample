import React from 'react';
import { expect } from 'chai';
import { shallow, mount } from 'enzyme';

import { Accounts } from './../../../../src/client/js/components/Accounts';
import Life from './../../../../src/client/js/components/accounts/Life';
import LifeMobile from './../../../../src/client/js/components/accounts/LifeMobile';

import { mockState } from './../mock/mock-state';

describe('<Life/>', () => { //eslint-disable-line
    it('Should render when it has data', () => {
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const life = mount(<Life lifeData={insurance.instance().props.lifeData} />);
        expect(life.find('table').length).to.be.equal(1);
    });

    it('Should not render when it doesnt', () => { //eslint-disable-line
        const life = mount(<Life lifeData={[]} />);
        expect(life.find('table').length).to.be.equal(0);
    });

    it('Should have 23 total products', () => { //eslint-disable-line
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const life = mount(<Life lifeData={insurance.instance().props.lifeData} />);
        expect(life.find('.solo-row').length).to.be.equal(23);
    });

    it('Should display the Life Policy Data', () => { //eslint-disable-line
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const life = mount(<Life lifeData={insurance.instance().props.lifeData} />);
        const tableRows = life.find('.solo-row');
        tableRows.forEach((row, index) => {
            const rowData = row.find('td');
            const lifePolicy = insurance.instance().props.lifeData[index];
            let expectedLifePolicyData = [
                `${lifePolicy.accountTypeDetail} - ${lifePolicy.accountNumberMasked}`,
                `${lifePolicy.benefit}`,
                `${lifePolicy.value}`,
                `${lifePolicy.annualizedPremium}`
            ];
            // Convert undefined to N/A as that transformation is done in component
            expectedLifePolicyData = expectedLifePolicyData.map(attr => (attr === 'undefined' ? 'N/A' : attr));
            rowData.forEach((column, index) => {
                expect(column.text().trim()).to.be.equal(expectedLifePolicyData[index]);
            });
        });
    });
});


describe('<LifeMobile/>', () => { //eslint-disable-line
    it('Should render when it has data', () => { //eslint-disable-line
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const life = mount(<LifeMobile data={insurance.instance().props.lifeData} title="Life Insurance" />);
        expect(life.find('.life-list').length).to.be.equal(1);
    });

    it('Should not render when it doesnt', () => { //eslint-disable-line
        const disability = shallow(<LifeMobile data={{}} title="Life Insurance" />);
        expect(disability.find('.life-list').length).to.be.equal(0);
    });

    it('Should have 2 rows', () => { //eslint-disable-line
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const life = mount(<LifeMobile data={insurance.instance().props.lifeData} title="Life Insurance" />);
        expect(life.find('.top-row').length).to.be.equal(23);
    });
});
