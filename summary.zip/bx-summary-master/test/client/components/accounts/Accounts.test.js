import React from 'react';
import { expect, assert } from 'chai';
import { shallow } from 'enzyme';
import { Accounts } from './../../../../src/client/js/components/Accounts';
import { mockState } from './../mock/mock-state';

describe('<Accounts/>', () => {
    it('Should render', () => {
        const accounts = shallow(<Accounts {...mockState.accounts} hasContent />);
        expect(accounts.html().length).to.be.greaterThan(1);
        const props = accounts.instance().props;
        assert.isTrue(props.hasFetched);
        assert.isTrue(props.hasContent);
        assert.isFalse(props.hasError);

        // Check length of different account types data
        assert.equal(props.ulifeData, mockState.accounts.ulifeData);
        assert.equal(props.lifeData, mockState.accounts.lifeData);
        assert.equal(props.investmentData, mockState.accounts.investmentData);
        assert.equal(props.annuityData, mockState.accounts.annuityData);
        assert.equal(props.varLifeData, mockState.accounts.varLifeData);
        assert.equal(props.bdiData, mockState.accounts.bdiData);
    });

    it('Should not render', () => {
        const accountsData = {
            lifeData: [],
            ulifeData: [],
            varLifeData: [],
            bdiData: [],
            investmentData: [],
            annuityData: []
        };
        const accounts = shallow(<Accounts {...accountsData} hasContent />);
        expect(accounts.html()).to.be.null;
    })
});
