import React from 'react';
import { expect } from 'chai';
import { shallow, mount } from 'enzyme';

import { Accounts } from './../../../../src/client/js/components/Accounts';
import Annuity from './../../../../src/client/js/components/accounts/Annuity';
import AnnuityMobile from './../../../../src/client/js/components/accounts/AnnuityMobile';

import { mockState } from './../mock/mock-state';

describe("<Annuity/>", () => {
    it('Should render when it has data', () => {
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const annuity = mount(<Annuity annuityData={insurance.instance().props.annuityData} />);
        expect(annuity.find('table').length).to.be.equal(1);
    });

    it('Should not render when it doesnt', () => {
        const annuity = mount(<Annuity data={[]} />);
        expect(annuity.find('table').length).to.be.equal(0);
    });

    it('Should have 2 total products', () => {
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const annuity = mount(<Annuity annuityData={insurance.instance().props.annuityData} />);
        expect(annuity.find('.solo-row').length).to.be.equal(2);
    });

    it('Should display the Annuity Policy Data', () => {
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const annuity = mount(<Annuity annuityData={insurance.instance().props.annuityData} />);
        const tableRows = annuity.find('.solo-row');
        tableRows.forEach((row, index) => {
            const rowData = row.find('td');
            const annuityPolicy = insurance.instance().props.annuityData[index];
            let expectedannuityPolicyData = [
                `${annuityPolicy.ownerName}${annuityPolicy.accountType} - ${annuityPolicy.accountNumberMasked}`,
                `${annuityPolicy.accountTypeDetail}`,
                `${annuityPolicy.value}`,
                `${annuityPolicy.valueAsOfDate}`
            ];
            // Convert undefined to N/A as that transformation is done in component
            expectedannuityPolicyData = expectedannuityPolicyData.map(attr => (attr === 'undefined' ? 'N/A' : attr));
            rowData.forEach((column, index) => {
                expect(column.text().trim()).to.be.equal(expectedannuityPolicyData[index]);
            });
        });
    });
});


describe("<AnnuityMobile/>", () => {
    it('Should render when it has data', () => {
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const annuity = mount(<AnnuityMobile data={insurance.instance().props.annuityData} />);
        expect(annuity.find('.annuity-list').length).to.be.equal(1);
    });

    it('Should not render when it doesnt', () => {
        const annuity = shallow(<AnnuityMobile data={{}} />);
        expect(annuity.find('.life-list').length).to.be.equal(0);
    });

    it('Should have 2 rows', () => {
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const annuity = mount(<AnnuityMobile data={insurance.instance().props.annuityData} />);
        expect(annuity.find('.top-row').length).to.be.equal(2);
    });
});
