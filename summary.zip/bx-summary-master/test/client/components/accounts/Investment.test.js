import React from 'react';
import { expect } from 'chai';
import { shallow, mount } from 'enzyme';

import { Accounts } from './../../../../src/client/js/components/Accounts';
import Investments from './../../../../src/client/js/components/accounts/Investments';
import InvestmentsMobile from './../../../../src/client/js/components/accounts/InvestmentsMobile';

import { mockState } from './../mock/mock-state';

describe("<Investment/>", () => {
    it('Should render when it has data', () => {
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const investment = mount(<Investments investmentData={insurance.instance().props.investmentData} />);
        expect(investment.find('table').length).to.be.equal(1);
    });

    it('Should not render when it doesnt', () => {
        const investment = mount(<Investments investmentData={[]} />);
        expect(investment.find('table').length).to.be.equal(0);
    });

    it('Should have 5 total products', () => {
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const investment = mount(<Investments investmentData={insurance.instance().props.investmentData} />);
        expect(investment.find('.solo-row').length).to.be.equal(5);
    });

    it('Should display the investment Policy Data', () => {
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const investment = mount(<Investments investmentData={insurance.instance().props.investmentData} />);
        const tableRows = investment.find('.solo-row');
        tableRows.forEach((row, index) => {
            const rowData = row.find('td');
            const investmentPolicy = insurance.instance().props.investmentData[index];
            let expectedinvestmentPolicyData = [
                `${investmentPolicy.ownerName}${investmentPolicy.accountNumberMasked}`,
                `${investmentPolicy.accountTypeDetail}`,
                `${investmentPolicy.value}`,
                `${investmentPolicy.valueAsOfDate}`
            ];
            // Convert undefined to N/A as that transformation is done in component
            expectedinvestmentPolicyData = expectedinvestmentPolicyData.map(attr => (attr === 'undefined' ? 'N/A' : attr));
            rowData.forEach((column, index) => {
                expect(column.text().trim()).to.be.equal(expectedinvestmentPolicyData[index]);
            });
        });
    });
});


describe("<InvestmentsMobile/>", () => {
    it('Should render when it has data', () => {
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const investment = mount(<InvestmentsMobile data={insurance.instance().props.investmentData} title="Investment Insurance" />);
        expect(investment.find('.investment-list').length).to.be.equal(1);
    });

    it('Should not render when it doesnt', () => {
        const disability = shallow(<InvestmentsMobile data={{}} title="Investment Insurance" />);
        expect(disability.find('.investment-list').length).to.be.equal(0);
    });

    it('Should have 5 rows', () => {
        const insurance = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const investment = mount(<InvestmentsMobile data={insurance.instance().props.investmentData} title="Investment Insurance" />);
        expect(investment.find('.top-row').length).to.be.equal(5);
    });
});
