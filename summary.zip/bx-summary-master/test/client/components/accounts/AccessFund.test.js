import React from 'react';
import { expect } from 'chai';
import { shallow, mount } from 'enzyme';

import { Accounts } from './../../../../src/client/js/components/Accounts';
import AccessFunds from './../../../../src/client/js/components/accounts/AccessFunds';
import AccessFundsMobile from './../../../../src/client/js/components/accounts/AccessFundsMobile';

import { mockState } from './../mock/mock-state';

describe('<AccessFund/>', () => {
    it('Should render when it has data', () => {
        const accounts = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const accessFund = shallow(<AccessFunds accessFundsData={accounts.instance().props.accessFundsData} />);

        expect(accessFund.find('table').length).to.be.equal(1);
    });

    it('Should not render when it doesnt', () => {
        const accessFund = shallow(<AccessFunds accessFundsData={[]} />);

        expect(accessFund.find('table').length).to.be.equal(0);
    });

    it('Should have 1 row', () => {
        const accounts = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const accessFund = mount(<AccessFunds accessFundsData={accounts.instance().props.accessFundsData} />);
        expect(accessFund.find('.solo-row').length).to.be.equal(1);
    });

    it('Should display the Access Fund Policy Data', () => {
        const accounts = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const accessFund = shallow(<AccessFunds accessFundsData={accounts.instance().props.accessFundsData} />);
        const tableRows = accessFund.find('.solo-row');
        tableRows.forEach((row, index) => {
            const rowData = row.find('td');
            const accessFundPolicy = accounts.instance().props.accessFundsData[index];
            const expectedaccessFundPolicyData = [
                `${accessFundPolicy.ownerName}${accessFundPolicy.accountNumberMasked}`,
                `${accessFundPolicy.value}`
            ];
            rowData.forEach((column, index) => {
                expect(column.text().trim()).to.be.equal(expectedaccessFundPolicyData[index]);
            });
        });
    });
});

describe('<AccessFundsMobile/>', () => {
    it('Should render when it has data', () => {
        const accounts = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const accessFund = shallow(<AccessFundsMobile data={accounts.instance().props.accessFundsData} />);

        expect(accessFund.find('.access-funds-list').length).to.be.equal(1);
    });

    it('Should not render when it doesnt', () => {
        const accessFund = shallow(<AccessFundsMobile data={[]} />);

        expect(accessFund.find('.access-funds-list').length).to.be.equal(0);
    });

    it('Should have 1 row', () => {
        const accounts = shallow(<Accounts {...mockState.accounts} hasFetched />);
        const accessFund = shallow(<AccessFundsMobile data={accounts.instance().props.accessFundsData} />);
        expect(accessFund.find('.top-row').length).to.be.equal(1);
    });
});
