import React from 'react';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import sinon from 'sinon';
import * as SummaryActions from  './../../../src/client/js/actions/SummaryActions';
import ConnectedActions, { Actions } from './../../../src/client/js/components/Actions';
import app from  './../../../src/client/js/reducers/rootReducer';

const dismissAction = SummaryActions.dismissAction;
const goPaperless = SummaryActions.goPaperless;
const addAccounts = SummaryActions.addAccounts;
const payNow = SummaryActions.payNow;
const actionCount = SummaryActions.actionCount;

let store = createStore(app)

const actionData = {
    hasError: false,
    hasFetched: true,
    items: [
        {
            "actionText": "<strong>Your $7,000.00 payment is due 2/1/2014</strong><br/> Insurance Service Account 1269731.",
            "buttonText": "Pay Now",
            "href": "/billing/1269731",
            "type": "payments",
            "actionId": "ISA-2"
        }, {
            "actionText": "Choose eDelivery for your documents and stop having paper copies mailed to you.",
            "buttonText": "Go Paperless",
            "href": "/Preferences?selection=DocDelivery",
            "type": "paperless",
            "actionId": "PL-1"
        }, {
            "actionText": "Its a great idea for you to link outside accounts.",
            "buttonText": "Link Now",
            "href": "/Preferences?selection=DocDelivery",
            "type": "accounts",
            "actionId": "ACCT-1"
        }
    ]
};

describe("<Action/>", function() {

    it('Should render with 3 actions', () => {
        let mockData = {
            actions: actionData,
            dismissAction: dismissAction,
            goPaperless: goPaperless,
            addAccounts: addAccounts,
            payNow: payNow,
            actionCount: actionCount,
            hasSVGFilter: false
        }

        let action = shallow(<Actions {...mockData} />);
        expect(action.find('.action-item')).to.have.length(3);
    });

    it('Should not render if there are no actions.', () => {
        let mockData = {
            actions: {
                hasError: false,
                hasFetched: true,
                items: []
            },
            dismissAction: dismissAction,
            goPaperless: goPaperless,
            addAccounts: addAccounts,
            payNow: payNow,
            hasSVGFilter: false,
        }
        let action = shallow(<Actions {...mockData} />);
        expect(action.html()).to.be.equal(null);
    });

    it('Count pill should be 3', () => {
        let mockData = {
            actions: actionData,
            dismissAction: dismissAction,
            goPaperless: goPaperless,
            addAccounts: addAccounts,
            payNow: payNow,
            actionCount: actionCount,
            hasSVGFilter: false
        }

        let action = shallow(<Actions {...mockData} />);
        expect(action.find('.count-pill').text()).to.be.equal('3');
    });

});
