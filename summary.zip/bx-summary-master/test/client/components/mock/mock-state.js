import accounts from './accounts.json';
import messages from './messages.json';
import meta from './meta.json';
import financialreps from './financialreps.json';
import terms from './terms.json';

export const mockState = {
    actions: {},
    dismissed: [],
    terms: terms,
    meta: meta,
    spending: {},
    networth: {},
    exceptions: [],
    financialreps: financialreps,
    messages: messages,
    footnotes: {},
    billing: {},
    accounts: accounts
};
