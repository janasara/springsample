export const messageData = [
    {
        "messageCode": "AnyRestriction",
        "messageTxt": "Products and values shown do not include all policies. <a href=\"/ContactUs\">Contact your financial representative</a> for additional information.",
        "displayLevel": 1,
        "messageType": 0,
        "messageLevel": 0,
        "messageLevelValue": ""
    },
    {
        "messageCode": null,
        "messageTxt": "System Message - Display Until 12/31/2017<br/>",
        "displayLevel": 2,
        "messageType": 1,
        "messageLevel": 6,
        "messageLevelValue": ""
    }
];
