export const emptyTerms = {
  "token": "hlo1f8rrL8ZugYoa5KXlaoORmOMrmVr5O6S0zlpTXEgRKt1ZNvVB3W1eRetMD3G5BDsuBifQMrgNsDEy7VT04SRCj5ZQYApIPTgvQI2wv3M1",
  "termsModel": []
};
