import React from 'react';
import { expect } from 'chai';
import { shallow, mount, render } from 'enzyme';

import mockRecurring from './../../../../../src/server/mock/billing/premium/recurring.json';
import mockLarge from './../../../../../src/server/mock/billing/premium/large-quarterly-due.json';

import DirectOrRecurring from './../../../../../src/client/js/components/billing/shared/DirectOrRecurring';

describe("Billing <DirectOrRecurring/>", function() {
    it('should render', () => {
        let cardData = mockRecurring[0];
        let isaData = mockRecurring[0].insuredList;
        let type = 'PremiumRecurring';
        let wrapper = shallow(<DirectOrRecurring cardData={cardData} isaData={isaData} type={type}/>);
        expect(wrapper.find('.isa-card-content-container')).to.have.length(1)
    });

    it('render message column', () => {
        let cardData = mockRecurring[0];
        let isaData = mockRecurring[0].insuredList;
        let type = 'PremiumRecurring';
        let wrapper = shallow(<DirectOrRecurring cardData={cardData} isaData={isaData} type={type}/>);
        expect(wrapper.find('.isa-card-2-column-container')).to.have.length(2)
    });

    it('render payment footer', () => {
        let cardData = mockLarge[0];
        let isaData = mockLarge[0].insuredList;
        let type = 'PremiumDirectDue';
        let wrapper = shallow(<DirectOrRecurring cardData={cardData} isaData={isaData} type={type}/>);
        expect(wrapper.find('.billing-multi-col')).to.have.length(2)
    });

});
