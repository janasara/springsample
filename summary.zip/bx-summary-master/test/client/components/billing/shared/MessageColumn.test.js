import React from 'react';
import { expect } from 'chai';
import { shallow, mount, render } from 'enzyme';
import { isaViewDetails, isaLoanPayLink } from  './../../../../../src/client/js/actions/SummaryActions';


import mockRecurring from './../../../../../src/server/mock/billing/premium/recurring.json';

import { MessageColumn } from './../../../../../src/client/js/components/billing/shared/MessageColumn';

describe("Billing <MessageColumn/>", function() {
    it('should render', () => {
        let totalPaymentDue = mockRecurring[0].amountDue;
        let dueDate = mockRecurring[0].dueDate;
        let frequency = mockRecurring[0].frequency;
        let isaUrl = mockRecurring[0].isaUrl;
        let type = 'Recurring';
        let isaTotal = mockRecurring[0].isaTotal;

        let wrapper = shallow(<MessageColumn totalPaymentDue={totalPaymentDue} dueDate={dueDate}
            frequency={frequency} isaUrl={isaUrl} type={type} isaTotal={isaTotal}
            isaViewDetails={isaViewDetails} isaLoanPayLink={isaLoanPayLink}/>);
        expect(wrapper.find('.cta-container')).to.have.length(1)
    });

    // render loan, annuity, recurring, due
    //should render button
        //see details vs make payment vs make contribution

    //should render loan link


});
