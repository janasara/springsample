import React from 'react';
import { expect } from 'chai';
import { shallow, mount, render } from 'enzyme';

import mockRecurring from './../../../../../src/server/mock/billing/premium/recurring.json';

import LeftColumnTotal from './../../../../../src/client/js/components/billing/shared/LeftColumnTotal';

describe("Billing <LeftColumnTotal/>", function() {
    it('should render', () => {
        let totalPaymentDue = mockRecurring[0].amountDue;
        let wrapper = shallow(<LeftColumnTotal totalPaymentDue={totalPaymentDue}/>);
        expect(wrapper.find('.isa-card-insured-product__total-row-container')).to.have.length(1)
    });
});
