import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';

import mock from './../../../../../src/server/mock/billing/premium-due-service-charge.json';

import AdditionalPayments from './../../../../../src/client/js/components/billing/shared/AdditionalPayments';

describe("Billing <AdditionalPayments/>", function() {
    it('should render both', () => {
        var serviceCharge = '$1.00';
        var additionalPayment = '$1.00';
        let wrapper = shallow(<AdditionalPayments serviceCharge={serviceCharge} additionalPayment={additionalPayment}/>);
        expect(wrapper.text()).to.contain('Service Charge');
        expect(wrapper.text()).to.contain('Additional Payment');
    });

    it('render service charge only', () => {
        var serviceCharge = '$1.00';
        var additionalPayment = '$0.00';
        let wrapper = shallow(<AdditionalPayments serviceCharge={serviceCharge} additionalPayment={additionalPayment}/>);
        expect(wrapper.text()).to.contain('Service Charge');
        expect(wrapper.text()).to.not.contain('Additional Payment');
    });

    it('render additional payment only', () => {
        var serviceCharge = '$0.00';
        var additionalPayment = '$1.00';
        let wrapper = shallow(<AdditionalPayments serviceCharge={serviceCharge} additionalPayment={additionalPayment}/>);
        expect(wrapper.text()).to.not.contain('Service Charge');
        expect(wrapper.text()).to.contain('Additional Payment');
    });
});
