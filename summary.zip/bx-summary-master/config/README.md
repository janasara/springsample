#Testing Remote Services

Here's how the start the app locally, using mock data.
```javascript
    npm run dev
```

Here's how to start the app locally, using int services.  NMC calls will throw CORS warnings and won't work though...
```javascript
    npm run dev:int
```
