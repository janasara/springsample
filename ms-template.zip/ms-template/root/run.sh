#!/bin/bash

sudo docker rm -f $(docker ps -a | awk '/{%= name %}/{print $1}')
docker run -e "NODE_CONFIG_STRICT_MODE=1 NODE_ENV=production NODE_APP_INSTANCE=development" -d --name {%= name %} -p 8080:80 regt.nmlv.nml.com:5000/{%= name %}
docker ps
