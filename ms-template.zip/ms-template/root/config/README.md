### Config's Multiple Node Instances
https://github.com/lorenwest/node-config/wiki/Multiple-Node-Instances

#### nodejs 6+ naming standard is:
```
<NODE_ENV>-<NODE_APP_INSTANCE>.json
```

where NODE_APP_INSTANCE in {int, qa, perf, prod} and NODE_ENV = production (these variables are set in the int/qa/perf/prod environments by Kubernetes Config Maps - see your kubernetes.yml file for the setting of these variables from the map)

**production.json does NOT refer to the production environment. (production-prod.json refers to the to production environment.)** It is the default config. attributes here are inherited in any config file that starts with 'production-'

The reason for this is to enable express performance optimizations.

Your config directory should have:
- README.md
- development-int.json  <== Local development, inherits from development.json
- development.json      <== Local development defaults
- production-int.json   <== Int environment, inherits from production.json
- production-perf.json  <== Perf environment, inherits from production.json
- production-prod.json  <== Prod environment, inherits from production.json
- production-qa.json    <== QA environment, inherits from production.json
- production.json       <== defaults

#### nodejs 4 naming standard is:
```
<NODE_ENV>.json
```

where NODE_ENV in {int, qa, perf, prod}

default.json is the default config. attributes here are inherited in any config file that matches <NODE_ENV>.json

Your config directory should have:
- default.json      <== Local development defaults
- int.json          <== Int environment, inherits from production.json
- perf.json         <== Perf environment, inherits from production.json
- prod.json         <== Prod environment, inherits from production.json
- qa.json           <== QA environment, inherits from production.json
