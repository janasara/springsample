/* eslint-disable */

const shell = require("shelljs");

function handlePassFail(shellCmd, secondaryCheck = false) {
  if (shellCmd.code !== 0) {
    shell.echo("❗\ FAIL");
    shell.exit(1);
  } else if (secondaryCheck) {
    shell.echo("❗\ FAIL");
    shell.exit(1);
  } else {
    shell.echo("✅ \ PASS");
  }
}

shell.echo("RUNNING PRE-DEPLOY CHECKS...");

shell.echo("1) LINTING...");
const lint = shell.exec("./node_modules/.bin/eslint ./");
handlePassFail(lint);

shell.echo("2) TESTS...");
const test = shell.exec("npm run test");
handlePassFail(test);

shell.echo("3) CHECKING FOR SECUIRTY FLAGS ON DEPS...");
const nsp = shell.exec("./node_modules/nsp/bin/nsp check");
handlePassFail(nsp);

shell.echo("4) CHECKING FOR UNUSED DEPENDENCIES...");
const depcheck = shell.exec(
  "./node_modules/depcheck/bin/depcheck --ignores=pre-commit,nsp"
);
handlePassFail(depcheck, depcheck.stdout !== "No depcheck issue\n");

shell.echo("5) CHECKING DEPENDENCIES VERSIONS...");
const ncu = shell.exec(
  "./node_modules/npm-check-updates/bin/npm-check-updates --packageFile package.json"
);
handlePassFail(ncu);

shell.echo("PRE-DEPLOY CHECKS COMPLETE ...");

shell.echo(
  "🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀\  🚀"
);
