const newrelic = require("newrelic");

const GIT_SHA = process.env.GIT_COMMIT;

module.exports = () => (req, res, next) => {
  newrelic.addCustomParameter(
    "nmUniqueId",
    req.headers["x-nm-nm_uid"] || "no_user"
  );
  newrelic.addCustomParameter(
    "employeeType",
    req.headers["x-nm-user-type"] || "no_user_type"
  );
  newrelic.addCustomParameter("GIT_SHA", GIT_SHA);

  if (req.cookies && req.cookies.X_NM_CLIENT_CONTEXT) {
    const parsedCookie = JSON.parse(req.cookies.X_NM_CLIENT_CONTEXT);
    if (parsedCookie.clientNmUniqueId) {
      newrelic.addCustomParameter(
        "clientNmUniqueId",
        parsedCookie.clientNmUniqueId
      );
    }
    if (parsedCookie.worksForNmUniqueId) {
      newrelic.addCustomParameter(
        "worksForNmUniqueId",
        parsedCookie.worksForNmUniqueId
      );
    }
    if (parsedCookie.worksForEmployeeType) {
      newrelic.addCustomParameter(
        "worksForEmployeeType",
        parsedCookie.worksForEmployeeType
      );
    }
  }
  next();
};
