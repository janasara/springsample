const express = require("express");
const cookieParser = require("cookie-parser");
const log = require("nmlvhub-node-logger");

const basePath = "/api/v1/{%= contextRoot %}";
const app = express();
const memwatch = require("memwatch-next");
const errorHandlingMiddleware = require("./middleware/error-handling");
const loggingMiddleware = require("./middleware/logging");
const newrelicMiddleware = require("./middleware/new-relic");

const getHealth = require("./routes/get-health");
const getDoc = require("./routes/get-doc");

// Disable per IRM
app.disable("x-powered-by");

memwatch.on("leak", info => {
  log.warn(info, "Memory leak was detected");
});

app.use(loggingMiddleware.requestStart());
app.use(cookieParser());
app.use(loggingMiddleware.requestComplete());
app.use(newrelicMiddleware());

/* ----------API ENDPOINTS ---------- */
const api = express.Router();
// 'swagger' docs ENDPOINT
api.route("/doc").get(getDoc);
// 'health' ENDPOINT USED TO VALIDATE SERVICE IS UP AND HEALTHY.
api.route("/health").get(getHealth);
// BASE URL PATH
app.use(basePath, api);
/* ----------END API ENDPOINTS ---------- */

app.use(errorHandlingMiddleware.validation());
app.use(errorHandlingMiddleware.notFound());
app.use(errorHandlingMiddleware.error());

module.exports = app;
