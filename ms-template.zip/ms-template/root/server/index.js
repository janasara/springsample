require("newrelic");

const https = require("https");
const http = require("http");
const nmlvLastMileCerts = require("nmlvhub-node-certs-lastmile");
const log = require("nmlvhub-node-logger");

const config = require("config");

const app = require("./app");

// Override default ports when running on windows or mac
const httpListenerPort = (() => {
  if (!process.env.KUBERNETES_SERVICE_HOST) {
    // Override default ports when running on windows or mac
    return 8080;
  }
  return 80;
})();
const httpsListenerPort = (() => {
  if (!process.env.KUBERNETES_SERVICE_HOST) {
    // Override default ports when running on windows or mac
    return 8443;
  }
  return 443;
})();

log.info(`NODE_ENV: ${config.util.getEnv("NODE_ENV")}`);
log.info(`NODE_APP_INSTANCE: ${config.util.getEnv("NODE_APP_INSTANCE")}`);
log.info(`NODE_CONFIG_DIR: ${config.util.getEnv("NODE_CONFIG_DIR")}`);
log.levels(
  0,
  process.env.BUNYAN_LOG_LEVEL
    ? parseInt(process.env.BUNYAN_LOG_LEVEL, 10)
    : 30 /* INFO */
);

log.info(`log.levels(): ${log.levels()}`);

const httpServer = http.createServer(app).listen(httpListenerPort, () => {
  log.info(`app is listening at localhost:${httpListenerPort}`);
});

const httpsServer = https
  .createServer(nmlvLastMileCerts.apiCerts, app)
  .listen(httpsListenerPort, () => {
    log.info(`app is listening at localhost:${httpsListenerPort}`);
  });

process.on("SIGTERM", () => {
  httpServer.close(() => {
    log.info("SIGTERM issued...app is shutting down");
    process.exit(0);
  });
  httpsServer.close(() => {
    log.info("SIGTERM issued...app is shutting down");
    process.exit(0);
  });
});
