const os = require('os')

/* Health check for app. */
function getHealth(req, res) {
  // Add any custom code here, if needed
  req.log.info({
    responseCode: 200
  }, 'Health check request complete')

  return res.json({
    'Node Host': os.hostname(),
    'Git SHA': process.env.GIT_COMMIT
  })
})

module.exports = getHealth
