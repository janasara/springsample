const fs = require("fs");

const swaggerFile = JSON.parse(fs.readFileSync("swagger.json").toString());

/* Health check for app. */
function getDocs(req, res) {
  return res.json(swaggerFile);
}

module.exports = getDocs;
