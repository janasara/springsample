const asyncFunc = require("asyncawait/async");
const awaitFunc = require("asyncawait/await");
const Promise = require("bluebird");
const query = Promise.promisify(require("nmlvhub-mysql-pool").query);
const os = require("os");

/* Health check for app. */
const getHealth = asyncFunc((req, res, next) => {
  try {
    const results = awaitFunc(
      query({ sql: "select @@hostname as mysqlhost", log: req.log })
    )[0];
    req.log.info(
      {
        responseCode: 200
      },
      "Health check request complete"
    );
    return res.json({
      "Node Host": os.hostname(),
      "biipcloud Host": results,
      "Git SHA": process.env.GIT_COMMIT
    });
  } catch (err) {
    req.log.info(
      {
        responseCode: 500
      },
      `Health check request failed${err}`
    );
    return next(err);
  }
});

module.exports = getHealth;
