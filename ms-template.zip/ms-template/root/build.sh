#!/bin/bash

sudo docker build -t regt.nmlv.nml.com:5000/{%= name %} .