'use strict'

var apikey = process.env.apikey

exports.appendApikeyHeader = function (requestParams, context, ee, next) {
  if (!requestParams.headers) {
    requestParams.headers = {}
  }
  requestParams.headers.apikey = apikey
  next()
}
