/* eslint-env jasmine */
var request = require("supertest");
var express = require("express");
var app = express();
var contextCookieParser = require("../../middleware/context-cookie-parser.js");
app.use(contextCookieParser());
app.use("/", (req, res, next) => {
  console.log("COOKIE HEADERS", req.headers.cookie);
  return res.json(req.headers.cookie);
});

describe("context cookie parser", () => {
  it("should parse the context cookie", done => {
    request(app)
      .get("/")
      .set(
        "cookie",
        "X_NM_CLIENT_CONTEXT=eyJjbGllbnRObVVuaXF1ZUlkIjogInRlc3QiLCAid29ya3NGb3JObVVuaXF1ZUlkIjogInRlc3QiLCAid29ya3NGb3JFbXBsb3llZVR5cGUiOiAidGVzdCJ9"
      )
      .expect("Content-Type", /json/)
      .expect(200)
      .end((err, res) => {
        if (err) {
          return done.fail(err);
        }
        expect(res.body).toEqual(
          'X_NM_CLIENT_CONTEXT={"clientNmUniqueId": "test", "worksForNmUniqueId": "test", "worksForEmployeeType": "test"}; '
        );
        return done();
      });
  });

  it("should parse the context cookie - non-NM cookie", done => {
    request(app)
      .get("/")
      .set("cookie", "cookie")
      .expect("Content-Type", /json/)
      .expect(200)
      .end((err, res) => {
        if (err) {
          return done.fail(err);
        }
        expect(res.body).toEqual("");
        return done();
      });
  });

  it("should parse the context cookie - NM non-client cookie", done => {
    request(app)
      .get("/")
      .set("cookie", 'X_NM_Cookie={"cookie": "cookie"}')
      .expect("Content-Type", /json/)
      .expect(200)
      .end((err, res) => {
        if (err) {
          return done.fail(err);
        }
        expect(res.body).toEqual('X_NM_Cookie={"cookie": "cookie"}; ');
        return done();
      });
  });

  it('app route: should be able to parse a base64 encoded X_NM_CLIENT_CONTEXT cookie (Add 1 "=")', function(
    done
  ) {
    request(app)
      .get("/")
      .set(
        "cookie",
        "X_NM_CLIENT_CONTEXT=eyJjbGllbnRObVVuaXF1ZUlkIjogInRlc3QiLCAid29ya3NGb3JObVVuaXF1ZUlkIjogInRlc3QiLCAid29ya3NGb3JFbXBsb3llZVR5cGUiOiAidGVzdCJ9Cg="
      )
      .expect("Content-Type", /json/)
      .expect(200)
      .end((err, res) => {
        if (err) {
          return done.fail(err);
        }
        expect(res.body).toEqual(
          'X_NM_CLIENT_CONTEXT={"clientNmUniqueId": "test", "worksForNmUniqueId": "test", "worksForEmployeeType": "test"}\n; '
        );
        done();
      });
  });

  it('app route: should be able to parse a base64 encoded X_NM_CLIENT_CONTEXT cookie (Add 2 "=")', function(
    done
  ) {
    request(app)
      .get("/")
      .set(
        "cookie",
        "X_NM_CLIENT_CONTEXT=eyJjbGllbnRObVVuaXF1ZUlkIjogInRlc3QiLCAid29ya3NGb3JObVVuaXF1ZUlkIjogInRlc3QiLCAid29ya3NGb3JFbXBsb3llZVR5cGUiOiAidGVzdCJ9Cg"
      )
      .expect("Content-Type", /json/)
      .expect(200)
      .end((err, res) => {
        if (err) {
          return done.fail(err);
        }
        expect(res.body).toEqual(
          'X_NM_CLIENT_CONTEXT={"clientNmUniqueId": "test", "worksForNmUniqueId": "test", "worksForEmployeeType": "test"}\n; '
        );
        done();
      });
  });
});
