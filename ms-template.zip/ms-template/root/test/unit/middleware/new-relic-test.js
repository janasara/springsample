/* eslint-env jasmine */
process.env.NODE_ENV = "development";
process.env.NODE_APP_INSTANCE = "int";
var request = require("supertest");
var express = require("express");
var app = express();
var newrelicMiddleware = require("../../middleware/new-relic.js");
var newrelic = require("newrelic");
var cookieParser = require("cookie-parser");

app.use(cookieParser());
app.use(newrelicMiddleware());
app.use("/", (req, res, next) => {
  return res.json({});
});

describe("new relic middleware", () => {
  it("should add the new relic custom parameters", done => {
    spyOn(newrelic, "addCustomParameter");
    request(app)
      .get("/")
      .set("x-nm-nm_uid", "test4")
      .set("x-nm-user-type", "test5")
      .set("Cookie", [
        'X_NM_CLIENT_CONTEXT={"clientNmUniqueId": "test1", "worksForNmUniqueId": "test2", "worksForEmployeeType": "test3"}'
      ])
      .expect("Content-Type", /json/)
      .expect(200)
      .end((err, res) => {
        if (err) {
          return done.fail(err);
        }
        expect(newrelic.addCustomParameter).toHaveBeenCalledWith(
          "nmUniqueId",
          "test4"
        );
        expect(newrelic.addCustomParameter).toHaveBeenCalledWith(
          "employeeType",
          "test5"
        );
        expect(newrelic.addCustomParameter).toHaveBeenCalledWith(
          "clientNmUniqueId",
          "test1"
        );
        expect(newrelic.addCustomParameter).toHaveBeenCalledWith(
          "worksForNmUniqueId",
          "test2"
        );
        expect(newrelic.addCustomParameter).toHaveBeenCalledWith(
          "worksForEmployeeType",
          "test3"
        );
        return done();
      });
  });

  it("should add the new relic custom parameters when no headers are present", done => {
    spyOn(newrelic, "addCustomParameter");
    request(app)
      .get("/")
      .expect("Content-Type", /json/)
      .expect(200)
      .end((err, res) => {
        if (err) {
          return done.fail(err);
        }
        expect(newrelic.addCustomParameter).toHaveBeenCalledWith(
          "nmUniqueId",
          "no_user"
        );
        expect(newrelic.addCustomParameter).toHaveBeenCalledWith(
          "employeeType",
          "no_user_type"
        );
        return done();
      });
  });
});
