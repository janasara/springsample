/* eslint-env jasmine */
"use strict";
var request = require("supertest");
var proxyquire = require("proxyquire");
var express = require("express");
var log = require("nmlvhub-node-logger");
var fake = express.Router();
fake.use("/error", function(req, res, next) {
  next(new Error("test error"));
});
fake.use(function(req, res) {
  res.json({});
});
var app = proxyquire("../../server/app", {
  "../../server/routes/get-health": fake,
  "../../server/routes/get-doc": fake,
  "nmlvhub-node-logger": log
});
var memwatch = require("memwatch-next");

describe("the {%= contextRoot %} application path", function() {
  it("should be registered for health", function(done) {
    request(app)
      .get("/api/v1/{%= contextRoot %}/health")
      .expect("Content-Type", /json/)
      .expect(200)
      .end(function(err) {
        if (err) {
          return done.fail(err);
        }
        done();
      });
  });

  it("should be registered for doc", function(done) {
    request(app)
      .get("/api/v1/{%= contextRoot %}/doc")
      .expect("Content-Type", /json/)
      .expect(200)
      .end(function(err) {
        if (err) {
          return done.fail(err);
        }
        done();
      });
  });

  it("should set child logger on request with correlation id", function(done) {
    spyOn(log, "child").and.callThrough();
    request(app)
      .get("/api/v1/{%= contextRoot %}/health")
      .set("x-nmlvhub-corid", "test")
      .set("host", "testHost")
      .set("user-agent", "superagent")
      .expect("Content-Type", /json/)
      .expect(200)
      .end(function(err) {
        expect(log.child).toHaveBeenCalledWith({
          requestPath: "/api/v1/{%= contextRoot %}/health",
          environment: "int",
          correlationId: "test",
          httpVerb: "GET",
          params: {},
          headers: {
            host: "testHost",
            "accept-encoding": "gzip, deflate",
            "user-agent": "superagent",
            "x-nmlvhub-corid": "test",
            connection: "close"
          }
        });
        if (err) {
          return done.fail(err);
        }
        done();
      });
  });

  it("should set log memory leak", function(done) {
    spyOn(log, "warn").and.callThrough();
    memwatch.emit("leak", "bad memory leak");
    expect(log.warn).toHaveBeenCalled();
    done();
  });

  it("should provide a 400 response for invalid paths", function(done) {
    request(app).get("/api/v1/badaddress").expect(400).end(function(err) {
      if (err) {
        return done.fail(err);
      }
      done();
    });
  });

  it("should provide a 500 error when a route throws an error", function(done) {
    request(app)
      .get("/api/v1/{%= contextRoot %}/health/error")
      .expect(500)
      .end(function(err) {
        if (err) {
          return done.fail(err);
        }
        done();
      });
  });

  it("should provide a 500 error when a route throws an error - fake prod env", function(
    done
  ) {
    process.env.NODE_APP_INSTANCE = "prod";

    request(app)
      .get("/api/v1/{%= contextRoot %}/health/error")
      .expect(500)
      .end(function(err) {
        if (err) {
          return done.fail(err);
        }
        delete process.env.NODE_APP_INSTANCE;
        done();
      });
  });
});
