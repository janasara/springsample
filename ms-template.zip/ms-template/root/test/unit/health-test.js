/* eslint-env jasmine */
"use strict";
var request = require("supertest");
var express = require("express");
var proxyquire = require("proxyquire");
var fakeOS = {
  hostname: function() {
    return "testOS";
  }
};

var app = express();

app.use(function(req, res, next) {
  req.log = require("nmlvhub-node-logger");
  next();
});

var route = proxyquire("../../server/routes/get-health.js", { os: fakeOS });

app.use(function(req, res, next) {
  req.log = require("nmlvhub-node-logger");
  next();
});

app.use(route);

process.env.GIT_COMMIT = "A12345";

describe("health", function() {
  it("should return the node server name and Git SHA", function(done) {
    request(app)
      .get("/")
      .expect("Content-Type", /json/)
      .expect(200)
      .end(function(err, res) {
        if (err) {
          return done.fail(err);
        }
        expect(res.body["Node Host"]).toEqual("testOS");
        expect(res.body["Git SHA"]).toEqual("A12345");
        done();
      });
  });
});
