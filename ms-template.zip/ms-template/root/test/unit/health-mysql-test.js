/* eslint-env jasmine */
"use strict";
var request = require("supertest");
var proxyquire = require("proxyquire");
var express = require("express");
var mockPool = require("nmlvhub-mysql-mockpool");
var fakeOS = {
  hostname: function() {
    return "testOS";
  }
};

var app = express();

app.use(function(req, res, next) {
  req.log = require("nmlvhub-node-logger");
  next();
});

var route = proxyquire("../../server/routes/get-health.js", {
  "nmlvhub-mysql-pool": mockPool,
  os: fakeOS
});

app.use(route);

process.env.GIT_COMMIT = "A12345";

describe("health", function() {
  it("should return the mysql and node server name, and Git SHA", function(
    done
  ) {
    mockPool.setResult([{ mysqlhost: "test" }]);
    request(app)
      .get("/")
      .expect("Content-Type", /json/)
      .expect(200)
      .end(function(err, res) {
        if (err) {
          return done.fail(err);
        }
        expect(res.body["Mysql Host"]).toEqual("test");
        expect(res.body["Node Host"]).toEqual("testOS");
        expect(res.body["Git SHA"]).toEqual("A12345");
        done();
      });
  });

  it("should return a 500 if a connection cannot be established", function(
    done
  ) {
    mockPool.failConnection();
    request(app)
      .get("/")
      .expect("Content-Type", "text/html")
      .expect(500)
      .end(function(err) {
        expect(err).toBeDefined();
        done();
      });
  });

  it("should return a 500 if query failed", function(done) {
    mockPool.failQuery();
    request(app)
      .get("/")
      .expect("Content-Type", "text/html")
      .expect(500)
      .end(function(err) {
        expect(err).toBeDefined();
        done();
      });
  });
});
