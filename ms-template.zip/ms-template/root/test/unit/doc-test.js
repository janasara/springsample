/* eslint-env jasmine */
"use strict";
var request = require("supertest");
var express = require("express");
var fs = require("fs");
var swagger = JSON.parse(fs.readFileSync("swagger.json").toString());

var app = express();

var route = require("../../server/routes/get-doc.js");
app.use(route);

describe("doc", function() {
  it("should return the swagger doc", function(done) {
    request(app)
      .get("/")
      .expect("Content-Type", /json/)
      .expect(200)
      .end(function(err, res) {
        if (err) {
          return done.fail(err);
        }
        expect(res.body).toEqual(swagger);
        done();
      });
  });
});
