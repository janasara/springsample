# nmlvhub-ms-template

> Create an nmlvhub microservice with [grunt-init][].

[grunt-init]: http://gruntjs.com/project-scaffolding

## Installation
If you haven't already done so, install [grunt-init][].

Once grunt-init is installed, it is recommended that you clone this template to your `~/.grunt-init/` directory.
```
git clone https://git.nmlv.nml.com/lvhub/nmlvhub-ms-template-v2.git ~/.grunt-init/nmlvhub-ms-template-v2
```
_(Windows users, see [the documentation][grunt-init] for the correct destination directory path)_

__Note:__ If you prefer to clone this template to a directory outside grunt-init you will need to follow the alternate usage below.

## Usage

At the command-line, cd into an empty directory, run this command and follow the prompts.

```
grunt-init nmlvhub-ms-template-v2
```
_Note that this template will generate files in the current directory, so be sure to create to a new project directory first._

#### Alternate Usage
To run a template that is outside the grunt-init directory run grunt-init with path to the template.

```
grunt-init /my/path/to/nmlvhub-ms-template-v2
```

## IMPORTANT NOTE

**Remember to add a project variable called ZABBIX_MONITOR_TEAM to your repo, with the appropriate value for your team (i.e. lvhub, lvpx, indigo, yellow, blanco, or cxid) !!!!!**

## Options

Like [npm init](https://docs.npmjs.com/cli/init), grunt-init will ask a bunch of questions to help setup your project and create your package.json file.  In addition to the standard project questions the following are available to help customize your project.

<dl>
    <dt>mysql (default: Y)</dt>
    <dd>Adds mysql package dependencies and nmlvhub connection pool module.  Also customizes the health check to verify the database is up</dd>
</dl>