"use strict";
var fs = require("fs");

// Basic template description.
exports.description = "Scaffolds a new project with GruntJS.";

// Template-specific notes to be displayed after question prompts.
exports.after =
  "You should now install project dependencies with _npm " +
  "install_. For more information about installing and configuring Grunt, please see " +
  "the Getting Started guide:" +
  "\n\n" +
  "http://gruntjs.com/getting-started";

// Any existing file or directory matching this wildcard will cause a warning.
exports.warnOn = "*";

// The actual init template.
exports.template = function(grunt, init, done) {
  init.process(
    {},
    [
      // Prompt for these values.
      {
        name: "name",
        message: "GitLab Repo Name (i.e. ms-accounts) ?",
        default: "",
        validator: /^[a-z0-9\-]{1,23}$/,
        warning: "Must only be lowercase letters, numbers, and dashes, and must be < 24 characters!!!"
      },
      {
        name: "description",
        message: "Project Description ?",
        default: ""
      },
      {
        name: "version",
        message: "Version (i.e. 0.0.1) ?",
        default: "0.0.1"
      },
      {
        name: "contextRoot",
        message: "Context Root (i.e. accounts) ?",
        default: ""
      },
      {
        name: "mysql",
        message: "Using MySQL ?",
        default: "Y"
      },
      {
        name: "ZABBIX_MONITOR_TEAM",
        message: "Zabbix Monitor Team - Contact LV Hub Team if you do not know ?",
        validator: function(line) {
          var validTeams = [
            "lvhub",
            "lvpx",
            "banyanlabs",
            "cxid",
            "indigo",
            "yellow",
            "blanco",
            "teal",
            "blackops",
            "ips",
            "unknown"
          ];
          if (validTeams.indexOf(line) > -1) {
            return true;
          } else {
            return false;
          }
        },
        default: "unknown",
        warning: "Must only be a valid Zabbix Monitoring Team (lvhub, lvpx, banyanlabs, cxid, indigo, yellow, blanco, teal, blackops, or ips)!!!"
      }
    ],
    function(err, props) {
      if (err) {
        return done(err);
      }

      if (!props.contextRoot) {
        props.contextRoot = props.name;
      }
      if (props.mysql) {
        props.mysql = props.mysql.toUpperCase();
      }

      // Files to copy (and process).
      var files = init.filesToCopy(props);

      // If mysql property is set include mysql health check
      if (props.mysql === "Y") {
        files["server/routes/health.js"] =
          "nmlvhub-ms-template-v2/root/server/routes/health-mysql.js";
        files["test/unit/health-test.js"] =
          "nmlvhub-ms-template-v2/root/test/unit/health-mysql-test.js";
        files["test/integration/test-spec.js"] =
          "nmlvhub-ms-template-v2/root/test/integration/int-test-mysql.js";
        files["swagger.json"] =
          "nmlvhub-ms-template-v2/root/swagger-mysql.json";
      }

      if (props.ZABBIX_MONITOR_TEAM) {
        fs.writeFileSync("./.zabbix", props.ZABBIX_MONITOR_TEAM);
      }

      // Actually copy (and process) files.
      init.copyAndProcess(files, props);

      // Generate package.json file, used by npm and grunt.
      var dependencies = {
        asyncawait: "1.0.6",
        artillery: "1.5.0-20",
        async: "2.1.4",
        bluebird: "3.5.0",
        config: "1.24.0",
        "cookie-parser": "1.4.3",
        "deep-diff": "0.3.4",
        express: "4.15.2",
        "express-validation": "1.0.2",
        joi: "10.4.1",
        lodash: "4.17.4",
        "memwatch-next": "0.3.0",
        mocha: "3.2.0",
        newrelic: "1.38.2",
        "nmlvhub-node-certs-lastmile": "1.0.1",
        "nmlvhub-node-integrationtests-diffreport": "1.0.0",
        "nmlvhub-node-logger": "1.2.3",
        request: "2.79.0",
        supertest: "2.0.1"
      };
      var devDependencies = {
        depcheck: "0.6.7",
        eslint: "3.19.0",
        "eslint-config-airbnb": "14.1.0",
        "eslint-plugin-import": "2.2.0",
        "eslint-plugin-jsx-a11y": "4.0.0",
        "eslint-plugin-react": "6.10.3",
        istanbul: "0.4.5",
        "flow-bin": "0.42.0",
        nodemon: "1.11.0",
        "npm-check-updates": "2.10.5",
        nsp: "2.6.3",
        "pre-commit": "1.2.2",
        shelljs: "0.7.7",
        proxyquire: "1.7.10",
        "swagger-model-validator": "2.1.8"
      };

      // If mysql property is set include mysql dependencies
      if (props.mysql === "Y") {
        dependencies.mysql = "2.6.2";
        dependencies["nmlvhub-mysql-pool"] = "1.1.2";
        dependencies["nmlvhub-util-decryption"] = "2.0.3";
        devDependencies["nmlvhub-mysql-mockpool"] = "1.1.2";
      }

      // Create package.json
      init.writePackageJSON(
        "package.json",
        {
          name: props.name,
          description: props.description,
          version: props.version,
          dependencies: dependencies,
          devDependencies: devDependencies,
          "pre-commit": ["run-checks"],
          scripts: {
            predebug: "npm install --production",
            debug: "node-inspector --no-preload & nodemon -L --max-old-space-size=512 --debug  --trace-sync-io server",
            dev: "NODE_CONFIG_STRICT_MODE=1 NODE_ENV=development nodemon --trace-sync-io server",
            start: "NODE_CONFIG_STRICT_MODE=1 node server/index.js",
            test: "node_modules/istanbul/lib/cli.js cover node_modules/.bin/_mocha `find test/unit -type f -name '*-test.js'`",
            "dev-int": "NODE_CONFIG_STRICT_MODE=1 NODE_ENV=development NODE_APP_INSTANCE=int nodemon server",
            checks: "NODE_CONFIG_STRICT_MODE=1 NODE_ENV=development NODE_APP_INSTANCE=int node run-checks",
            depcheck: "./node_modules/depcheck/bin/depcheck --ignores=pre-commit,nsp",
            ncu: "./node_modules/npm-check-updates/bin/npm-check-updates;",
            "deps:update": "ncu -u",
            lint: "eslint ./ --fix",
            "flow-start": "flow start",
            "flow-stop": "flow stop",
            "flow-status": "flow status",
            "flow-coverage": "flow coverage",
            integration: "mocha ./test/integration/int-test.js",
            "integration-local": "pkill '^node$'; export GIT_COMMIT=<your gitsha> ; NODE_CONFIG_STRICT_MODE=1 NODE_ENV=development NODE_APP_INSTANCE=int node index.js & sleep 5 ; apikey=<your api key> mocha --grep functional ./test/integration/int-test.js && pkill '^node$'",
            "integration-int": "GIT_COMMIT=<your gitsha> environment=int apikey=<your api key> mocha ./test/integration/int-test.js",
            "performance-int": "GIT_COMMIT=<your gitsha> environment=int apikey=<your api key> mocha ./test/integration/int-test.js --grep performance",
            clean: "rm -rf ./build ./node_modules"
          },
          repository: {
            type: "git",
            url: "http://git.nmlv.nml.com/lvhub/" + props.name + ".git"
          }
        },
        function(pkg, props) {
          pkg.private = true;
          return pkg;
        }
      );

      if (props.ZABBIX_MONITOR_TEAM === "unknown") {
        console.log(
          "\x1b[31m%s\x1b[0m",
          "\n\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
        );
        console.log(
          "\x1b[31m%s\x1b[0m",
          "!!!!! NOTE: Your ZABBIX_MONITOR_TEAM is unknown, which means you will not get alerted when your API is not responding to Zabbix health checks!     !!!!!"
        );
        console.log(
          "\x1b[31m%s\x1b[0m",
          "!!!!!       Please work with the NMLV Hub Team to get Zabbix Monitoring set up for your team.                                                      !!!!!"
        );
        console.log(
          "\x1b[31m%s\x1b[0m",
          "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n\n"
        );
      }

      return done();
    }
  );
};
