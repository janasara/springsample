# nmlv-web-template

> Create an nmlv web app with [grunt-init][].

[grunt-init]: http://gruntjs.com/project-scaffolding

## Installation
If you haven't already done so, install [grunt-init][].

Once grunt-init is installed, it is recommended that you clone this template to your `~/.grunt-init/` directory.
```
git clone https://git.nmlv.nml.com/nmc/nmlv-web-template.git ~/.grunt-init/nmlv-web-template
```
_(Windows users, see [the documentation][grunt-init] for the correct destination directory path)_

__Note:__ If you prefer to clone this template to a directory outside grunt-init you will need to follow the alternate usage below.

## Usage

At the command-line, cd into an empty directory, run this command and follow the prompts.

```
grunt-init nmlv-web-template
```
_Note that this template will generate files in the current directory, so be sure to create to a new project directory first._

#### Alternate Usage
To run a template that is outside the grunt-init directory run grunt-init with path to the template.

```
grunt-init /my/path/to/nmlv-web-template
```

## Options

Like [npm init](https://docs.npmjs.com/cli/init), grunt-init will ask a bunch of questions to help setup your project and create your package.json file.  In addition to the standard project questions the following are available to help customize your project.


## ESLint - Code quality! Code quality! Code quality!

This builder includes an eslint file and cofigurations based on AirBnB's recommend lint config. Linting is a great way to ensure all developers are formatting their code and adhering to
common JavaScript best practices.

To run the linter, run the command
```
npm run lint:watch
```

The lint:watch task is used for development purposes and should be used by developers when they are working locally.

There is another lint command in the package json that you will see as well.
```
npm run lint
```

This command is meant to run by your build runner... Originally created for the jenkins build runner that nmlv-cx-sumarry runs after pull requests and daily
to make sure the build is stable. It will export the eslint results to junit format which can be reported in the Jenkins build page.

_Note - This is meant to be a baseline. Configuration changes can be made based on your individual project needs.