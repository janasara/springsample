import path from 'path';
import express from 'express';
import compression from 'compression';
import favicon from 'serve-favicon';
import serveStatic from 'serve-static';
import cacheResponseDirective from 'express-cache-response-directive';
import IS_DEV from './utils/isDev';
import root from './routes/root';
import info from './routes/info';
import health from './routes/health';
import logger from './utils/logger';
import message from './routes/api/message';

const app = express();

if (IS_DEV) {
    require('piping')(); // eslint-disable-line
}

app.disable('x-powered-by');
app.use(compression());
app.use('/{%= appPath %}/favicon', favicon(path.join(__dirname, '/components/favicon.ico')));
app.use('/{%= appPath %}/static', express.static(path.join(__dirname, '/../../build/static'), {
    maxAge: '365d'
}));
app.use('/{%= appPath %}/whatsnew', serveStatic(path.join(__dirname, '/routes/whatsnew'), {
    maxAge: '7d' // todo: fingerprint our assets, cache longer
}));
app.use(cacheResponseDirective());
app.use((req, res, next) => {
    res.cacheControl('no-store');
    next();
});
app.use(logger.middleware);
app.use('/{%= appPath %}', root);
app.use('/{%= appPath %}/info', info);
app.use('/{%= appPath %}/health', health);
app.use('/{%= appPath %}/api/message', message);

app.use((req, res, next) => {
    const err = new Error('Not found');
    err.status = 404;
    err.url = req.url;
    next(err);
});

app.use((err, req, res) => {
    const log = logger.getLogger(req);
    log.error(err.stack);
    let errorMessage = 'Internal application error';
    const okForClient = (err.status && err.message);// explicit errors thrown by us
    if (IS_DEV || okForClient) {
        errorMessage = err.message;
        res.statusMessage = err.message;
    }
    res.status(err.status || 500).json({ error: errorMessage });
});

export default app;
