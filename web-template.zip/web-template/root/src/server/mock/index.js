import express from 'express';
import jsonServer from 'json-server';

import message from './message.json';

const PORT = process.env.PORT || 8090;
const app = express();
const db = {
    message
};

app.use(jsonServer.defaults());
app.use('/mock/api', jsonServer.router(db));

const httpServer = app.listen(PORT, () => {
    console.log(`Mock API on http://localhost:${PORT} [${app.settings.env}]`);
});

process.on('SIGTERM', () => {
    httpServer.close(() => {
        process.exit(0);
    });
});
