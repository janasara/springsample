import fetch from 'isomorphic-fetch';
import config from 'config';
import { getHeaders } from './../utils/headersUtils';
import { parseResponse, checkStatus, normalizeJSON } from './../utils/apiUtils';
const url = `${config.domains.nmlvhub}${config.serverUrls.message}`;

export function fetchMessage(req) {
    const headers = getHeaders(req);
    return fetch(url, { headers })
    .then(parseResponse)
    .then(checkStatus)
    .then(normalizeJSON);
}
