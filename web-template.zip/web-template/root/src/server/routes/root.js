/*
 the idea is to make this 'lazy universal' - we don't have to pre fetch and pre render everything,
 but we can bootstrap whatever initialState or raw data that makes sense - balance speed w/ server and
 client side fetching
 */
import { Router } from 'express';
import configureStore from '../../client/js/store/configureStore';
import AppShell from '../components/AppShell';
import UnsupportedBrowser from '../components/UnsupportedBrowser';
import { getUsername, getBrowser } from './../utils/headersUtils';
import config from 'config';
import fs from 'fs';

const router = Router();

const clientConfig = { // only expose stuff that is ok on client
    domains: config.domains,
    clientUrls: config.clientUrls
};

let assetManifest;

router.get('/', (req, res) => {
    const username = getUsername(req);
    const ua = getBrowser(req);

    const initialState = {
        meta: {
            title: '{%= appPath %}',
            username,
            ua
        }
    };

    const store = configureStore(initialState);

    const finalState = store.getState();

    if (!assetManifest) {
        assetManifest = JSON.parse(fs.readFileSync('./build/static/asset-manifest.json', 'utf8'));
    }

    const html = (ua.ie && ua.version < 10) ?
        UnsupportedBrowser(assetManifest, clientConfig) :
        AppShell(assetManifest, clientConfig, '', finalState);

    res.send(html);
});

export default router;
