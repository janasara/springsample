import { Router } from 'express';
import git from 'git-rev';
import fs from 'fs';

const pjson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const router = Router();

function getGitHash() {
    return new Promise((resolve) => {
        git.long(resolve);
    });
}

router.get('/', (req, res) => {
    const hash = getGitHash();

    hash.then((gitHash) => {
        res.send({
            name: pjson.name,
            description: pjson.description,
            version: pjson.version,
            gitHash
        });
    });
});

export default router;
