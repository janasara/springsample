import { fetchMessage } from '../../models/message';
import { Router } from 'express';
const router = Router();

router.get('/', (req, res, next) => {
    fetchMessage(req)
        .then((data) => res.json(data))
        .catch((err) => next(err));
});

export default router;
