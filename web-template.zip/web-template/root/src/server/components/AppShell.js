/*eslint-disable*/
import { minify } from 'html-tagged-literals';

const AppShell = (assetManifest, clientConfig, initialHTML, initialState) => {
    const { meta } = initialState;
    const { vendor, main, criticalpath } = assetManifest;
    const hasPreload = (meta.ua.chrome);

    return minify`
    <!DOCTYPE html>
    <html>
        <head>
          <meta charset="utf-8">
          <title>${meta.title}</title>
          <meta name="viewport" content="width=device-width, initial-scale=1">

          <link rel="dns-prefetch" href="${clientConfig.domains.nmc}">
          ${hasPreload ? `
              <link rel="preload" href="${vendor.js}" as="script">
              <link rel="preload" href="${main.js}" as="script">
              ${main.css ? `<link rel="preload" href="${main.css}" as="style">` : ''}
          ` : `
              <link rel="prefetch" href="${vendor.js}">
              <link rel="prefetch" href="${main.js}">
              ${main.css ? `<link rel="prefetch" href="${main.css}">` : ''}
          `}
          <script>
            window.__INITIAL_STATE__ = ${JSON.stringify(initialState)};
            window.__CONFIG__ = ${JSON.stringify(clientConfig)};
          </script>
            ${criticalpath.css ? `<link rel="stylesheet" href="${criticalpath.css}">` : ''}
            ${main.css ? `<link rel="stylesheet" href="${main.css}">` : ''}
            <link rel="icon" href="/{%= appPath %}/favicon/favicon.ico">
        </head>
        <body>
            <!--# include virtual="/{%= cxOrPx %}/header" -->
            <div id="root">${initialHTML}</div>
            <!--# include virtual="/{%= cxOrPx %}/footer" -->

            <script src="${vendor.js}"></script>
            <script src="${main.js}"></script>
            <script>
                window.whatsnew = {
                    version: '1.0.0',
                    app: '{%= appPath %}',
                    url: '${clientConfig.domains.plan}/{%= appPath %}/whatsnew/slides.json'
                };
            </script>
            <script type="javascript" src="${clientConfig.domains.plan}/whatsnew/frame.js" async></script>
        </body>
    </html>`;
};

export default AppShell;
