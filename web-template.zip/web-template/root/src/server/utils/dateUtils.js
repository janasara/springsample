import Moment from 'moment';

export function formatDateMMDDYYY(dateString) {
    const date = Moment(dateString, Moment.ISO_8601);
    return date.format('MM/DD/YYYY');
}
