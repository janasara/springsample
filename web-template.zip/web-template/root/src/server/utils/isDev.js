module.exports = (process.env.BABEL_ENV && process.env.BABEL_ENV === 'development');
