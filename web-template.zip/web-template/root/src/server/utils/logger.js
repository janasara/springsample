import winston from 'winston';
import winstonConfig from 'winston/lib/winston/config';
import config from 'config';
import _forOwn from 'lodash/forOwn';
import fs from 'fs';
import { Router } from 'express';

const router = Router();
const pjson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const LV_ENV = process.env.NODE_ENV;
const LOG_FORMAT = config.get('logFormat');

function formatLog(logObject) {
    if (LOG_FORMAT === 'string') {
        let logString = '';

        _forOwn(logObject, (value, key) => {
            logString += ` ${key}=${value}`;
        });

        return logString.trim();
    }
    return JSON.stringify(logObject);
}

const getLogger = (req) => {
    let nmUid;

    if (req) {
        nmUid = req.headers['x-nm-nm_uid'];
    }

    return new (winston.Logger)({
        colors: {
            info: 'green',
            warn: 'yellow',
            error: 'red'
        },
        transports: [
            new (winston.transports.Console)({
                timestamp: false,
                colorize: true,
                formatter: (options) => {
                    const logObject = {
                        log_level: LOG_FORMAT === 'string' ? winstonConfig.colorize(options.level) : options.level,
                        nmUid,
                        log: `${options.message || ''}`.replace(/(?:\r\n|\r|\n)/g, ''),
                        lv_environment: LV_ENV,
                        appname: pjson.name
                    };

                    return formatLog(logObject);
                }
            })
        ]
    });
};

router.use((req, res, next) => {
    const logger = getLogger(req);
    req.logger = logger;
    logger.info('%s %s', req.method, req.originalUrl);
    next();
});

export default {
    getLogger,
    middleware: router
};
