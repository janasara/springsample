export function parseResponse(response) {
    return response.json().then((json) => ({ json, response }));
    // provide parsed response and original response
}

export function checkStatus({ json, response }) {
    if (!response.ok) { // status in the range 200-299 or not
        // reject & let catch decide how to handle/throw
        return Promise.reject(new Error(response.statusText || 'Status not OK'));
    }

    return { json, response };
}

export function normalizeJSON({ json }) {
    return json;
}
