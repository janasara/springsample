import { createStore, applyMiddleware, compose } from 'redux';
import rootReducer from '../reducers';
import thunk from 'redux-thunk';
import IS_BROWSER from '../utils/isBrowser';
import { analytics } from '../middleware';

const middleware = IS_BROWSER ? [thunk, analytics] : [thunk];

export default function configureStore(initialState = {}) {
    const store = createStore(rootReducer, initialState, compose(
        applyMiddleware(...middleware),
        IS_BROWSER && window.devToolsExtension ? window.devToolsExtension() : (f) => f
    ));

    if (module.hot) {
        module.hot.accept('../reducers', () => {
            const nextRootReducer = require('../reducers').default; // eslint-disable-line
            store.replaceReducer(nextRootReducer);
        });
    }

    return store;
}
