import numeral from 'numeral';

export function formatAsDollars(number) {
    return numeral(number).format('$0,0.00');
}
