const OPTIONS = {
    credentials: 'include',
    headers: {
        'Accept': 'application/json', // eslint-disable-line
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest'
    }
};

function parseResponse(response) {
    return response.json().then((json) => ({ json, response })); // provide parsed response and original response
}

function checkStatus({ json, response }) {
    if (!response.ok) { // status in the range 200-299 or not
        return Promise.reject(new Error(response.statusText || 'Status not OK')); // reject & let catch decide how to handle/throw
    }

    return { json, response };
}

function normalizeJSON({ json }) {
    return json;
}

export function startAction(type) {
    return { type };
}

export function successAction(type, json) {
    return { type, payload: json, meta: { receivedAt: Date.now() } };
}

export function failureAction(type, error) {
    return { type, payload: error, error: true, meta: { receivedAt: Date.now() } };
}

export function makeFetch(url, options) {
    return fetch(url, options || OPTIONS)
        .then(parseResponse)
        .then(checkStatus)
        .then(normalizeJSON);
}
