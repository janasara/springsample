export default typeof window !== 'undefined';
