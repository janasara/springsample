import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators, compose } from 'redux';
import { onlyUpdateForKeys } from 'recompose';
import { fetchMessage } from '../actions/messageActions';
import Message from './Message';

export const App = ({ msg, fetchMessageHandler }) => (
    <div className="grid-container">
        <h1 className="margin-top-medium margin-bottom-medium">test</h1>

        <div className="card small-12">
            <Message msg={msg} fetchMessageHandler={fetchMessageHandler} />
        </div>
    </div>
);

App.propTypes = {
    msg: PropTypes.string.isRequired,
    fetchMessageHandler: PropTypes.func.isRequired
};

const mapStateToProps = (state) => ({ msg: state.message.message });

const mapDispatchToProps = (dispatch) => (
    bindActionCreators({
        fetchMessageHandler: fetchMessage
    }, dispatch));

const enhance = compose(
    onlyUpdateForKeys(['msg']),
    connect(mapStateToProps, mapDispatchToProps)
);

export default enhance(App);
