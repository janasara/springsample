import React, { PropTypes } from 'react';

const Message = ({ msg, fetchMessageHandler }) => (
    <div>
        <p>{msg}</p>
        <button onClick={fetchMessageHandler}>Fetch Health</button>
    </div>
);

Message.propTypes = {
    msg: PropTypes.string.isRequired,
    fetchMessageHandler: PropTypes.func.isRequired
};

export default Message;
