import keyMirror from 'keymirror';

const actionTypes = keyMirror({
    MESSAGE_REQUEST: null,
    MESSAGE_SUCCESS: null,
    MESSAGE_FAILURE: null
});

export default actionTypes;
