import React from 'react';
import { render } from 'react-dom';
import configureStore from './store/configureStore';
import Root from './components/Root';
import ensurePolyfills from './utils/ensurePolyfills';
import { persistStore } from 'redux-persist';

ensurePolyfills(() => {
    const initialState = window.__INITIAL_STATE__; // eslint-disable-line
    const store = configureStore(initialState);

    persistStore(store, { whitelist: [] }, (/* err ,persistedState */) => {

    });

    render(
        <Root store={store} />,
        document.getElementById('root')
    );
});
