import analytics from 'redux-analytics';

export default analytics(({ type, payload }, state) => {
    try {
        _satellite.setVar('payload', payload); // eslint-disable-line
        _satellite.track(type); // eslint-disable-line
    } catch (grr) {
        console.log(grr);
        console.log(type, { ...state.analytics, ...payload });
    }
});
