import { startAction, successAction, failureAction, makeFetch } from '../utils/actionUtils';
import actionTypes from '../constants/actionTypes';
import config from '../utils/config';

export function fetchMessage() {
    return (dispatch) => {
        dispatch(startAction(actionTypes.MESSAGE_REQUEST));
        return makeFetch(config.clientUrls.message)
            .then((json) => dispatch(successAction(actionTypes.MESSAGE_SUCCESS, json)))
            .catch((error) => dispatch(failureAction(actionTypes.MESSAGE_FAILURE, error)));
    };
}
