import { combineReducers } from 'redux';
import meta from './meta';
import message from './message';

const rootReducer = combineReducers({
    message,
    meta
});

export default rootReducer;
