export const initialState = {
    title: '{%= name %}',
    username: null,
    ua: null
};

const meta = (state = initialState) => state;

export default meta;
