import actionTypes from '../constants/actionTypes';

export const initialState = {
    message: ''
};

function message(state = initialState, { type, payload }) {
    switch (type) {
        case actionTypes.MESSAGE_SUCCESS:
            return Object.assign({}, state, payload);
        default:
            return state;
    }
}

export default message;
