# {%= name %}
node microapp for {%= name %} (/{%= appPath %})

## Features

- React, Redux, Webpack, PostCSS, ES6, Babel, UITK
- npm scripts for build, lint, serve, tests
- hot module reloading (js, css), chrome redux devtools
- service worker, app shell caching
- lazy universal rendering

## Getting Started

Make sure that [Node v5](https://nodejs.org/en/download/releases/) is installed.
Use iterm2 instead of terminal https://www.iterm2.com/

``` bash
$ cd /path/to/your/favorite/directory
$ git clone https://github.com/lvtech/nmlv-cx-summary.git
$ npm install
$ npm run dev
```

## Development

``` bash
$ npm run dev
```
will fire up a development express server w/ hot module reloading, devtools, etc.  

server running on [localhost:8080](http://localhost:8080).  
mock api will run on [localhost:8080/api](http://localhost:8080/api).  
install chrome devtools for redux:  https://chrome.google.com/webstore/detail/redux-devtools/lmhkpmbekcpmknklioeibfkpmmfibljd   

``` bash
$ npm run dev-int
```
will run local server pointing to int api's

## Production

``` bash
$ npm run build
$ npm start
```
will build a static /build/static with our assets and fire up a production express server.  

The server will run on [localhost:8080](http://localhost:8080).

## Testing

``` bash
$ npm run test
```
## Testing (development)

``` bash
$ npm run test:watch
```

## Linting

``` bash
$ npm run lint
```

## Updating package.json

Use npm-check-updates to suggest latest versions
``` bash
$ npm install -g npm-check-updates
$ npm-check-updates
```

Update package.json with new versions if you agree
``` bash
$ npm-check-updates -u
```

run clean install
``` bash
$ rm -rf node_modules
$ npm install
```

## Tools

- JavaScript is written in **[ES6](https://github.com/lukehoban/es6features)** and transpiled with **[Babel](https://babeljs.io/)**.
- CSS is written and transpiled with **[Sass](http://sass-lang.com/)** and **[PostCSS](http://postcss.org/)**.
- Front-end assets (HTML, CSS, JS, images) are built with **[webpack](http://webpack.github.io/)**.
- UI components are built with **[React](http://facebook.github.io/react/)**, and application state is managed with **[Redux](https://github.com/gaearon/redux)** and **[Immutable.js](https://facebook.github.io/immutable-js/)**.
- Asynchronous actions are handled with **[redux-thunk](https://github.com/gaearon/redux-thunk)** and **[isomorphic-fetch](https://github.com/matthew-andrews/isomorphic-fetch)**.
- A local dev and mock API server is built with **[express](http://expressjs.com/)** and **[json-server](https://github.com/typicode/json-server)**.
- Linting is handled with **[ESLint](http://eslint.org/)**.
- Unit tests are written with **[Mocha](https://mochajs.org/)** and **[Chai](http://chaijs.com/)** and managed with **[Karma](https://karma-runner.github.io/0.13/index.html)**.
- Code coverage is provided by **[Istanbul](https://github.com/gotwarlost/istanbul)** and **[karma-coverage](https://github.com/karma-runner/karma-coverage)**.

## License

None

## Author

Northwestern Mutual
