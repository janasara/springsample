import IS_DEV from '../src/server/utils/isDev';
import path from 'path';
import webpack from 'webpack';
import ExtractTextPlugin from 'extract-text-webpack-plugin';
import CleanWebpackPlugin from 'clean-webpack-plugin';
import CaseSensitivePathsPlugin from 'case-sensitive-paths-webpack-plugin';
import StartServerPlugin from "start-server-webpack-plugin";

const hash = IS_DEV ? '[name]' : '[name]-[chunkhash]';
const root = process.cwd();
const styleLoaders = ['css?minimize&sourceMap&importLoaders=5', 'postcss', 'sass?sourceMap'];
const prefetches = ['react', 'redux'];

var plugins = [
    new CaseSensitivePathsPlugin(),
    new CleanWebpackPlugin(['build/server'], {'root': path.join(__dirname, '../'), 'verbose': false }),
    new webpack.DefinePlugin({
      'IS_BROWSER': false,
      'IS_DEV': IS_DEV,
      'process.env.NODE_ENV': JSON.stringify(IS_DEV ? 'development' : 'production')
    }),
    new ExtractTextPlugin(hash + '.css', {allChunks: true}),
    ...prefetches.map((i) => new webpack.PrefetchPlugin(i)),
    ...(IS_DEV ? [
            new webpack.HotModuleReplacementPlugin(),
            new StartServerPlugin()
        ] : []
    )
];

module.exports = {
    devtool: "inline-sourcemap",
    entry: {
        index: IS_DEV ? [
            "webpack/hot/poll?1000",
            path.join(root, 'src/server')
        ] : [
            path.join(root, 'src/server')
        ]
    },
    output: {
        devtoolModuleFilenameTemplate: "[absolute-resource-path]",
        libraryTarget: "commonjs2",
        path: "./build/server",
        filename: "[name].js"
    },
    plugins: plugins,
	externals: /^[a-z\-0-9]+$/,
    module: {
        loaders: [{
            loader: "babel",
            exclude: /node_modules/,
            query: {
                compact: false
            },
            test: /\.js$/
        },
        {
            test: /\.json$/, loader: 'json'
        },
        {
            test: /\.(jpe?g|png|gif)([\?]?.*)$/,
            include: [path.join(root, 'src/client')],
            loaders: [
                'url?limit=100',
                'image-webpack?bypassOnDebug&optimizationLevel=7&interlaced=false'
            ]
        },
        {
           test: /\.(woff|woff2|eot|ttf|svg)([\?]?.*)$/,
           loader: 'file?name=[name].[ext]' //name fonts to enable de-dup shared header/footer fonts
       },
        {
            test: /.s?css$/,
            include: [path.join(root, 'src/client'), path.resolve(root, 'node_modules')],
            loader: ExtractTextPlugin.extract('style', styleLoaders)
        }
        ]
    },
    postcss: function () {
        return [
          require('autoprefixer')({ browsers: ['last 2 versions'] })
        ];
    },
    node: {
      __filename: true,
      __dirname: true,
    },
    target: "node"
};
