'use strict';

// Basic template description.
exports.description = 'Scaffolds a new web project.';

// Template-specific notes to be displayed after question prompts.
exports.after = 'You should now install project dependencies with _npm ' +
                'install_. For more information about installing and configuring Grunt, please see ' +
                'the Getting Started guide:' + '\n\n' +
                'http://gruntjs.com/getting-started';

// Any existing file or directory matching this wildcard will cause a warning.
exports.warnOn = '*';

// The actual init template.
exports.template = function (grunt, init, done) {

    init.process({}, [
        // Prompt for these values.
        init.prompt('name'),
        init.prompt('description'),
        init.prompt('version'),
        init.prompt('appPath'),
        init.prompt('cxOrPx')
    ], function (err, props) {
        // Files to copy (and process).
        var files = init.filesToCopy(props);

        // Actually copy (and process) files.
        init.copyAndProcess(files, props);

        // Generate package.json file, used by npm and grunt.
        var dependencies = {
            'compression': '1.6.2',
            'config': '1.21.0',
            'express': '4.14.0',
            'express-cache-response-directive': '1.0.0',
            'isomorphic-fetch': '2.2.1',
            'lodash': '4.13.1',
            'moment': '2.13.0',
            'numeral': '1.5.3',
            'serve-favicon': '2.3.0',
            'serve-static': '1.11.1',
            'useragent': '2.1.9',
            'winston': '2.2.0',
            'recompose': '0.20.2'
        };
        var devDependencies = {
            'babel-cli': '6.10.1',
            'assets-webpack-plugin': '3.4.0',
            'autoprefixer': '6.3.6',
            'babel-core': '6.10.4',
            'babel-eslint': '6.1.0',
            'babel-loader': '6.2.4',
            'babel-plugin-transform-object-assign': '6.8.0',
            'babel-plugin-transform-object-rest-spread': '6.8.0',
            'babel-plugin-transform-react-constant-elements': '6.9.1',
            'babel-plugin-transform-react-inline-elements': '6.8.0',
            'babel-plugin-transform-react-remove-prop-types': '0.2.7',
            'babel-plugin-transform-runtime': '6.9.0',
            'babel-polyfill': '6.9.1',
            'babel-preset-es2015': '6.9.0',
            'babel-preset-react': '6.11.0',
            'babel-preset-react-hmre': '1.1.1',
            'babel-register': '6.9.0',
            'case-sensitive-paths-webpack-plugin': '1.1.1',
            'chai': '3.5.0',
            'classnames': '2.2.5',
            'clean-webpack-plugin': '0.1.9',
            'css-loader': '0.23.1',
            'd3': '3.5.17',
            'enzyme': '2.3.0',
            'es6-promise': '3.2.1',
            'eslint': '2.13.1',
            'eslint-config-airbnb': '9.0.1',
            'eslint-plugin-babel': '3.3.0',
            'eslint-plugin-import': '1.10.0',
            'eslint-plugin-jsx-a11y': '1.5.3',
            'eslint-plugin-react': '5.2.2',
            'extract-text-webpack-plugin': '1.0.1',
            'fetch-mock': '4.5.4',
            'file-loader': '0.9.0',
            'git-rev': '0.2.1',
            'html-tagged-literals': '1.0.1',
            'ignore-styles': '4.0.0',
            'image-webpack-loader': '1.8.0',
            'imports-loader': '0.6.5',
            'jsdom': '9.3.0',
            'json-loader': '0.5.4',
            'json-server': '0.8.14',
            'keymirror': '0.1.1',
            'mocha': '2.5.3',
            'mocha-junit-reporter': '1.11.1',
            'node-sass': '3.8.0',
            'piping': '1.0.0-rc.2',
            'postcss-loader': '0.9.1',
            'proxyquire': '1.7.9',
            'react': '15.1.0',
            'react-addons-test-utils': '15.1.0',
            'react-css-transition-replace': '1.2.0-beta',
            'react-dom': '15.1.0',
            'react-redux': '4.4.5',
            'react-responsive': '1.1.3',
            'redux': '3.5.2',
            'redux-analytics': '0.3.0',
            'redux-mock-store': '1.1.1',
            'redux-persist': '3.2.2',
            'redux-thunk': '2.1.0',
            'reselect': '2.5.1',
            'sass-loader': '3.2.2',
            'sinon': '1.17.4',
            'start-server-webpack-plugin': '2.0.1',
            'style-loader': '0.13.1',
            'supertest': '1.2.0',
            'ui-toolkit': '1.6.4',
            'url-loader': '0.5.7',
            'webpack': '1.13.1',
            'webpack-dev-middleware': '1.6.1',
            'webpack-hot-middleware': '2.11.0'
        };

        // Create package.json
        init.writePackageJSON('package.json', {
            'name': props.name,
            'description': props.description,
            'version': props.version,
            'dependencies': dependencies,
            'devDependencies': devDependencies,
            'scripts': {
                'build': 'npm run build:client',
                'build:client': 'BABEL_ENV=production webpack --progress --config ./webpack/webpack.client.babel.js',
                'build:server': 'BABEL_ENV=production webpack --progress --config ./webpack/webpack.server.babel.js',
                'start': 'BABEL_ENV=production babel-node ./src/server',
                'start:mock': 'NODE_ENV=development BABEL_ENV=development babel-node ./src/server/mock',
                'dev': 'NODE_ENV=development BABEL_ENV=development babel-node ./webpack/webpack-dev-server.js & NODE_ENV=development BABEL_ENV=development babel-node ./src/server & npm run start:mock',
                'dev-int': 'NODE_ENV=development NODE_APP_INSTANCE=int BABEL_ENV=development babel-node ./webpack/webpack-dev-server.js & NODE_ENV=development BABEL_ENV=development babel-node ./src/server & npm run start:mock',
                'clean': 'rm -r ./build ./node_modules',
                'lint': 'eslint src -f junit > ./test_results/eslint.xml',
                'lint:watch': 'eslint src',
                'lint:fix': 'eslint src --fix',
                'test': 'NODE_ENV=production BABEL_ENV=production MOCHA_FILE=./test_results/unit.xml mocha --opts test/mocha.opts',
                'test:watch': 'npm test -- --watch --reporter spec'
            },
            'repository': {
                'type': 'git',
                'url': 'https://github.com/lvtech/' + props.name + '.git'
            },
            'license': 'UNLICENSED',
            'author': 'Northwestern Mutual',
            'homepage': 'https://github.com/lvtech/' + props.name + '#readme',
        });

        // All done!
        done();
    });
};
