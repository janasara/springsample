'use strict';
require('newrelic');
var app = require('./app');
var https = require('https');
var http = require('http');
var nmlvLastMileCerts = require('nmlvhub-node-certs-lastmile');
var log = require('nmlvhub-node-logger');
var httpListenerPort = 80;
var httpsListenerPort = 443;

// Override default ports when running on windows or mac
if (!process.env.KUBERNETES_SERVICE_HOST) {
    httpListenerPort = 8080;
    httpsListenerPort = 8443;
}

log.levels(0, process.env.BUNYAN_LOG_LEVEL ? parseInt(process.env.BUNYAN_LOG_LEVEL, 10) : 30 /* INFO */);

var httpServer = http.createServer(app).listen(httpListenerPort, function () {
    log.info('app is listening at localhost:' + httpListenerPort);
});

var httpsServer = https.createServer(nmlvLastMileCerts.apiCerts, app).listen(httpsListenerPort, function () {
    log.info('app is listening at localhost:' + httpsListenerPort);
});

process.on('SIGTERM', function () {
    httpServer.close(function () {
        log.info('SIGTERM issued...app is shutting down');
        process.exit(0);
    });
    httpsServer.close(function () {
        log.info('SIGTERM issued...app is shutting down');
        process.exit(0);
    });
});
