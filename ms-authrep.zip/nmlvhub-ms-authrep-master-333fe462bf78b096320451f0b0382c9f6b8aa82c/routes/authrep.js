'use strict';
var express = require('express');
var router = express.Router();
var getClientDetailsV3 = require('../soap/GetClientsDetailsV3/getClientsDetailsV3.js');
var executeRegistrationRulesV5 = require('../soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5.js');
const isAuthRep = require('./is-auth-rep');
var async = require('async');
var config = require('config');
var _ = require('lodash');

function getCXIDAction(executeRegistrationRulesData) {
    /*jshint camelcase:false*/
    /*jscs:disable requireCamelCaseOrUpperCaseIdentifiers*/
    //Check for business login eligibility and identify the applicable action
    if (executeRegistrationRulesData.personal_status_cde === '2' && executeRegistrationRulesData.business_status_cde === '0') {
        return 1;
    } else if (executeRegistrationRulesData.personal_status_cde === '0' && executeRegistrationRulesData.business_status_cde === '2') {
        return 2;
    } else if (executeRegistrationRulesData.personal_status_cde === '3' & executeRegistrationRulesData.business_status_cde === '3') {
        return 3;
    } else if (executeRegistrationRulesData.personal_status_cde === '2' && executeRegistrationRulesData.business_status_cde === '2') {
        return 4;
    } else {
        //If no conditions are satisfied, then client is not eligible for business login so
        //return -1
        return -1;
    }
}

function getClientInfo(req, loginID, next) {
    getClientDetailsV3 (req.params.nmuniqueid, loginID, req.log, function (error, clientIdentityDataList) {
        if (error) {
            next(error, null);
        } else {
            next(null, clientIdentityDataList);
        }
    });
}

function executeRegistration(req, loginID, clientIdentityDataList, next) {
    var responseData = {
        cxidAction: -1,
        cxidUrl: ''
    };
    //Get the first LegalEntity which has CltLifecycleCde=2 so that pre clients are excluded
    var legalEntityData = _.find (clientIdentityDataList, function (item) {
        return item.CltLifecycleCde === '2';
    });
    if (legalEntityData !== undefined) {
        //Get the first ClientIdentity which has LoginUsageTypeCde=2 (indicates business login elegibility)
        var clientIdentityData = _.find(legalEntityData.ClientIdentity, item => item.LoginUsageTypeCde === '2');
        if (clientIdentityData !== undefined) {
            var legalEntityInputData = ({
                'LegalEntityId': legalEntityData.LegalEntityId,
                'LegEntIdSrcCde': legalEntityData.LegEntIdSrcCde
            });
            executeRegistrationRulesV5 (loginID, legalEntityInputData, req.log, function (error, executeRegistrationRulesData) {
                if (error) {
                    next(null, null, error);
                } else {
                    var cxidAction = getCXIDAction(executeRegistrationRulesData);

                    if (cxidAction > 0) {
                        responseData.cxidAction = cxidAction;
                        responseData.cxidUrl = config.cxidUrl + responseData.cxidAction + '&backURL=' + config.backUrl;
                    }
                    next(null, responseData, null);
                }
            });
        } else {
            next(null, responseData, null);
        }
    } else {
        next(null, responseData, null);
    }
}

function executeRegistrationData(executeRegistrationRulesData, err, next) {
    if (err) {
        next(err, null);
    } else {
        next(null, executeRegistrationRulesData);
    }
}

router.get('/isauthrep', isAuthRep);

router.get('/:nmuniqueid', function (req, res, callback) {
    var loginID;

    if (req.headers['x-nm-login-id']) {
        loginID = req.headers['x-nm-login-id'].toLowerCase();
    } else {
        return callback(new Error('No x-nm-login-id provided'));
    }

    async.waterfall([
            function (next) {
                getClientInfo(req, loginID, next);
            },
            function (clientIdentityDataList, next) {
                executeRegistration(req, loginID, clientIdentityDataList, next);
            },
            function (executeRegistrationRulesData, err, next) {
                executeRegistrationData(executeRegistrationRulesData, err, next);
            }
        ],
        function (err, result) {
            if (err != null) {
                return callback(err, null);
            } else {
                return res.json(result);
            }
        });
});

module.exports = router;
