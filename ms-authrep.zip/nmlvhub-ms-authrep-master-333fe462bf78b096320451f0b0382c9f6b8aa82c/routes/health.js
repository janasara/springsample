'use strict';
var express = require('express');
var router = express.Router();
var os = require('os');

/* Health check for app. */
router.get('/', function (req, res) {
    var apiStartTime = new Date().getTime();

    // Add any custom code here, if needed

    var apiResponseTime = (new Date().getTime()) - apiStartTime;

    req.log.info({
        responseCode: 200,
        apiResponseTime: apiResponseTime
    }, 'Health check request complete');

    return res.json({
        'Node Host': os.hostname()
    });
});

module.exports = router;
