'use strict';

var bPromise = require('bluebird');
var query = bPromise.promisify(require('nmlvhub-mysql-pool').query);
var sql = 'SELECT role_type_cde FROM biipcloud.client_role WHERE nm_unique_id = ? AND role_type_cde = 653 LIMIT 1';
function check(data) {
    return data[0] ? true : false;
}
module.exports = function isAuthRep(req, res, next) {
    const nmUnquieId = req.headers['x-nm-nm_uid'];
    if (!nmUnquieId) {
        return next(new Error('"x-nm-nm_uid" required in header'));
    }
    query({ sql: sql, values: nmUnquieId, log: req.log })
    .then(check)
    .then(function (data) {
        return res.json(data);
    })
    .catch(function (err) {
        return next(err);
    });
};
