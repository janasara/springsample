#!/bin/bash
# Purpose:
# 1. jasmine-node runs all tests in parallel and provides 
# no way to stop execution after a failure. this makes it 
# difficult to view the errors on the console.
# workaround: tee grunt output to a file and open sublime
# 2. No unit tests should make external datasource connections.
# the build runner, Teamcity, will fail if external datasource connections
# are being made due to differences in firewall rules on aws. we'd like to
# be notified if a unit test is incorrect before Teamcity reports it.
# workaround: create a temporary firewall rule that blocks all traffic

if [[ $(whoami) = 'root' ]]
then
    echo "ERROR: this script cannot be run as root" >&2
    exit 100
fi

echo
echo "INFO: this script requires password-less sudo"
echo "visudo"
echo "add a line e.g."
echo "abc1234 ALL=(ALL) NOPASSWD: ALL"
echo

if [[ $(uname) = 'Darwin' ]] ; then
    #find the device for the default route
    DEV=$(ip route | awk '/default/ {print $5}' | head -n1)
    #test the firewall rule
    (sudo pfctl -sr 2>/dev/null; echo "block drop quick on $DEV proto tcp from any to any") | sudo pfctl -nf - 2>/dev/null
    #add the firewall rule to block all traffic
    (sudo pfctl -sr 2>/dev/null; echo "block drop quick on $DEV proto tcp from any to any") | sudo pfctl -e -f - 2>/dev/null
    #list firewall rules
    sudo pfctl -sr 2>/dev/null
fi

#save the log so it can be easily searched
grunt | tee /tmp/grunt.log
grep -q "Aborted due to warnings" /tmp/grunt.log
if [[ $? -eq 0 ]] ; then
    sublime /tmp/grunt.log
fi

if [[ $(uname) = 'Darwin' ]] ; then
    #remove the firewall rule to block all traffic 
    #(sudo pfctl -sr 2>/dev/null | fgrep -v "block drop quick on lo0 proto tcp from any to any port = 1234") | sudo pfctl -f -
    sudo pfctl -f /etc/pf.conf 2>/dev/null
    #list firewall rules
    sudo pfctl -sr 2>/dev/null
fi

git grep -qE "console.log|console.dir"
if [[ $? -eq 0 ]] ; then
    echo
    echo "WARN: you have console statements in your source" >&2 
    echo "WARN: this should be converted to use the logger so they show up in kibana" >&2 
    echo
    git grep -E "console.log|console.dir"
fi
