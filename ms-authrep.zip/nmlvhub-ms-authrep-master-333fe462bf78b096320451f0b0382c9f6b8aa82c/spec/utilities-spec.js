'use strict';
var proxyquire = require('proxyquire');

describe('utilites', function () {

    //PLACE COMMON TESTCASE SETUP HERE
    beforeEach(function (done) {
        //set environment variable only in local
        if (!process.env.KUBERNETES_SERVICE_HOST) {
            console.log('setting as yes');
            process.env.KUBERNETES_SERVICE_HOST = 'yes';
        }
        done();
    });

    it('should return generic id credentials when running under kube cluster', function (done) {
        var fakeFs = {
            readFileSync: function () {
                return 'test data';
            }
        };
        var getSecrets = proxyquire('../utilities/getsecrets.js', {
            fs: fakeFs
        });

        var credentials = getSecrets.getSecrets();
        expect(credentials).toEqual({
            'genericID': 'test data',
            'genericPass': 'test data'
        });
        done();
    });

    it('should throw error when running under kube cluster', function (done) {
        var fakeFsError = {
            readFileSync: function () {
                throw Error('test data error');
            }
        };
        var getSecretsError = proxyquire('../utilities/getsecrets.js', {
            fs: fakeFsError
        });

        expect(getSecretsError.getSecrets).toThrow();
        delete process.env.KUBERNETES_SERVICE_HOST;
        done();
    });

    it('should throw NOENT error when running under kube cluster', function (done) {
        var fakeFsErrorNoEnt = {
            readFileSync: function () {
                throw {
                    'code': 'ENOENT'
                };
            }
        };
        var getSecretsErrorNoEnt = proxyquire('../utilities/getsecrets.js', {
            fs: fakeFsErrorNoEnt
        });

        expect(getSecretsErrorNoEnt.getSecrets).toThrow();
        delete process.env.KUBERNETES_SERVICE_HOST;
        done();
    });
});
