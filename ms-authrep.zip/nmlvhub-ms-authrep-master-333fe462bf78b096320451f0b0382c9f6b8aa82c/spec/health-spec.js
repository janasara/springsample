'use strict';
var request = require('supertest');
var express = require('express');
var proxyquire = require('proxyquire');
var app = express();
var fakeOS = {
    hostname: function () {
        return 'testOS';
    }
};
var route = proxyquire('../routes/health.js', { 'os': fakeOS });

app.use(function (req, res, next) {
    req.log = require('nmlvhub-node-logger');
    next();
});

app.use(route);

describe('health', function () {
    it('should return the node server name', function (done) {
        request(app)
            .get('/')
            .expect('Content-Type', /json/)
            .expect(200)
            .end(function (err, res) {
                if (err) {
                    return done.fail(err);
                }
                expect(res.body['Node Host']).toEqual('testOS');
                done();
            });
    });
});
