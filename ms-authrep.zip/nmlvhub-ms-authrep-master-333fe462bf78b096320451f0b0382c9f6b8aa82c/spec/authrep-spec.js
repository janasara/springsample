'use strict';
var request = require('supertest');
var express = require('express');
var proxyquire = require('proxyquire');
var cookieParser = require('cookie-parser');
var validate = require('express-validation');
var fs = require('fs');
var log = require('nmlvhub-node-logger');

describe('authrep suite: test input parameters', function () {

    //PLACE COMMON TESTCASE SETUP HERE
    beforeEach(function (done) {
        this.app = express();
        // For parsing cookies
        this.app.use(cookieParser());
        this.app.use(function (req, res, next) {
            req.log = log;
            next();
        });
        done();
    });

    it('should return a 400 error when no corid header provided', function (done) {
        var route = proxyquire('../routes/authrep.js', {});
        this.app.use('/', route);
        this.app.use(function (err, req, res, next) {
            // specific for validation errors
            if (err instanceof validate.ValidationError) {
                return res.status(err.status).json(err);
            } else {
                next(err);
            }
        });

        request(this.app)
            .get('/')
            .expect(400)
            .end(function (err, res) {

                expect(res.statusCode).toEqual(404);

                done();
            });
    });

    it('should return NmUniqueIdKey not found for non-existent input data', function (done) {

        //GLOBAL SETUP FOR EACH TESTCASE IN THIS SUITE
        var fakeGetClientsDetailsV3Request = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/GetClientsDetailsV3/getClientsDetailsV3ResponseNMUIDNotFound.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var getClientsDetailsV3Stub = proxyquire('../soap/GetClientsDetailsV3/getClientsDetailsV3.js', {
            'request': fakeGetClientsDetailsV3Request
        });

        var route = proxyquire('../routes/authrep.js', {
            '../soap/GetClientsDetailsV3/getClientsDetailsV3.js': getClientsDetailsV3Stub
        });

        this.app.use(route);
        this.app.use(function (err, req, res, next) {
            // specific for validation errors
            if (err instanceof validate.ValidationError) {
                return res.status(err.status).json(err);
            } else {
                next(err);
            }
        });

        request(this.app)
            .get('/1111111111')
            .set('x-nm-login-id', '52520DJZ')
            .set('X-NM-USER-TYPE', 'C')
            .set('Cookie', 'X_NM_CLIENT_CONTEXT={"worksForLoginId": "","worksForNmUniqueId": ""}')
            .end(function (err, res) {
                expect(res.text.includes('NmUniqueIdKey not found: 1111111111')).toBe(true);
                done();
            });
    });

    it('should return 4 for cxidAction when loginUsageTypeCode = 2', function (done) {

        var fakeGetClientsDetailsV3Request = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/GetClientsDetailsV3/getClientDetailsV3ResponsePass2.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var getClientsDetailsV3Stub = proxyquire('../soap/GetClientsDetailsV3/getClientsDetailsV3.js', {
            'request': fakeGetClientsDetailsV3Request
        });

        var fakeGetExecuteRegistrationRulesV5 = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5Response.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var executeRegistrationRulesV5Stub = proxyquire('../soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5.js', {
            'request': fakeGetExecuteRegistrationRulesV5
        });

        var route = proxyquire('../routes/authrep.js', {
            '../soap/GetClientsDetailsV3/getClientsDetailsV3.js': getClientsDetailsV3Stub,
            '../soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5.js': executeRegistrationRulesV5Stub
        });

        this.app.use(route);
        this.app.use(function (err, req, res, next) {
            // specific for validation errors
            if (err instanceof validate.ValidationError) {
                return res.status(err.status).json(err);
            } else {
                next(err);
            }
        });
        this.app.use(function (err, req, res, next) {
            if (req && req.log) {
                req.log.error(err);
            } else {
                log.error(err);
            }
            res.status(err.status || 500);
            res.json({
                'msg': err.message
            });
            next(err);
        });

        request(this.app)
            .get('/NUFBAEC52')
            .set('x-nm-login-id', 'NIM1795')
            .end(function (err, res) {
                console.log('>>>>>>>>>>>>>>>>>>>>>>> res: ', res);
                expect(res.body).toEqual({
                    cxidAction: 4,
                    cxidUrl: 'https://int.login.northwesternmutual.com/login/nmcManageLogin?action=4&backURL=https://nmctest.northwesternmutual.com'
                });
                done();
            });
    });

    it('should return 3 for cxidAction when loginUsageTypeCode = 2', function (done) {

        var fakeGetClientsDetailsV3Request = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/GetClientsDetailsV3/getClientDetailsV3ResponsePass2.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var fakeConfig = proxyquire('config', {});
        //Override default values to increate coverage around branches
        fakeConfig.showCAPReqRes.enabled = false;
        fakeConfig.executeRegistrationRulesV5.consumerID = undefined;

        var getClientsDetailsV3Stub = proxyquire('../soap/GetClientsDetailsV3/getClientsDetailsV3.js', {
            'request': fakeGetClientsDetailsV3Request,
            'config': fakeConfig
        });

        var fakeGetExecuteRegistrationRulesV5 = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5Response1.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var executeRegistrationRulesV5Stub = proxyquire('../soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5.js', {
            'request': fakeGetExecuteRegistrationRulesV5,
            'config': fakeConfig
        });

        var route = proxyquire('../routes/authrep.js', {
            '../soap/GetClientsDetailsV3/getClientsDetailsV3.js': getClientsDetailsV3Stub,
            '../soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5.js': executeRegistrationRulesV5Stub
        });

        this.app.use(route);
        this.app.use(function (err, req, res, next) {
            // specific for validation errors
            if (err instanceof validate.ValidationError) {
                return res.status(err.status).json(err);
            } else {
                next(err);
            }
        });
        this.app.use(function (err, req, res, next) {
            if (req && req.log) {
                req.log.error(err);
            } else {
                log.error(err);
            }
            res.status(err.status || 500);
            res.json({
                'msg': err.message
            });
            next(err);
        });

        request(this.app)
            .get('/NUFBAEC52')
            .set('x-nm-login-id', 'NIM1795')
            .end(function (err, res) {
                expect(res.body).toEqual({
                    cxidAction: 3,
                    cxidUrl: 'https://int.login.northwesternmutual.com/login/nmcManageLogin?action=3&backURL=https://nmctest.northwesternmutual.com'
                });
                done();
            });
    });

    it('should return 1 for cxidAction when loginUsageTypeCode = 2', function (done) {

        var fakeGetClientsDetailsV3Request = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/GetClientsDetailsV3/getClientDetailsV3ResponsePass2.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var getClientsDetailsV3Stub = proxyquire('../soap/GetClientsDetailsV3/getClientsDetailsV3.js', {
            'request': fakeGetClientsDetailsV3Request
        });

        var fakeGetExecuteRegistrationRulesV5 = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5Response2.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var executeRegistrationRulesV5Stub = proxyquire('../soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5.js', {
            'request': fakeGetExecuteRegistrationRulesV5
        });

        var route = proxyquire('../routes/authrep.js', {
            '../soap/GetClientsDetailsV3/getClientsDetailsV3.js': getClientsDetailsV3Stub,
            '../soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5.js': executeRegistrationRulesV5Stub
        });

        this.app.use(route);
        this.app.use(function (err, req, res, next) {
            // specific for validation errors
            if (err instanceof validate.ValidationError) {
                return res.status(err.status).json(err);
            } else {
                next(err);
            }
        });
        this.app.use(function (err, req, res, next) {
            if (req && req.log) {
                req.log.error(err);
            } else {
                log.error(err);
            }
            res.status(err.status || 500);
            res.json({
                'msg': err.message
            });
            next(err);
        });

        request(this.app)
            .get('/NUFBAEC52')
            .set('x-nm-login-id', 'NIM1795')
            .end(function (err, res) {
                expect(res.body).toEqual({
                    cxidAction: 1,
                    cxidUrl: 'https://int.login.northwesternmutual.com/login/nmcManageLogin?action=1&backURL=https://nmctest.northwesternmutual.com'
                });
                done();
            });
    });

    it('should return -1 for cxidAction when loginUsageTypeCode = 1', function (done) {

        var fakeGetClientsDetailsV3Request = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/GetClientsDetailsV3/getClientDetailsV3ResponsePass.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var getClientsDetailsV3Stub = proxyquire('../soap/GetClientsDetailsV3/getClientsDetailsV3.js', {
            'request': fakeGetClientsDetailsV3Request
        });

        var route = proxyquire('../routes/authrep.js', {
            '../soap/GetClientsDetailsV3/getClientsDetailsV3.js': getClientsDetailsV3Stub
        });

        this.app.use(route);
        this.app.use(function (err, req, res, next) {
            // specific for validation errors
            if (err instanceof validate.ValidationError) {
                return res.status(err.status).json(err);
            } else {
                next(err);
            }
        });

        request(this.app)
            .get('/NUFBAEC52')
            .set('x-nm-login-id', 'NIM1795')
            .end(function (err, res) {
                expect(res.body).toEqual({
                    cxidAction: -1,
                    cxidUrl: ''
                });
                done();
            });
    });

    it('should return data power error for ExecuteRegistrationRulesV5', function (done) {
        var fakeExecuteRegistrationRulesV5Request = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5DPEx.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var executeRegistrationRulesV5Stub = proxyquire('../soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5.js', {
            'request': fakeExecuteRegistrationRulesV5Request
        });

        var fakeGetClientsDetailsV3Request = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/GetClientsDetailsV3/getClientDetailsV3ResponsePass2.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var getClientsDetailsV3Stub = proxyquire('../soap/GetClientsDetailsV3/getClientsDetailsV3.js', {
            'request': fakeGetClientsDetailsV3Request
        });

        var route = proxyquire('../routes/authrep.js', {
            '../soap/GetClientsDetailsV3/getClientsDetailsV3.js': getClientsDetailsV3Stub,
            '../soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5.js': executeRegistrationRulesV5Stub
        });

        this.app.use(route);

        this.app.use(function (req, res, next) {
            var err = new Error('InvalidUri or InvalidHttpVerb');
            err.status = 400;
            next(err);
        });

        // production error handler
        // sends empty body and 500 error
        this.app.use(function (err, req, res, next) {
            if (req && req.log) {
                req.log.error(err);
            } else {
                log.error(err);
            }
            res.status(err.status || 500);
            res.json({
                'msg': err.message
            });
            next(err);
        });

        request(this.app)
            .get('/QTKBTF448')
            .set('x-nm-login-id', 'NIM1795')
            .set('X-NM-USER-TYPE', 'C')
            .set('Cookie', 'X_NM_CLIENT_CONTEXT={"worksForLoginId": "","worksForNmUniqueId": ""}')
            .expect(200)
            .end(function (err, res) {
                expect(res.text.includes('No ConsumerId found in WS-A header, HTTP Header, or in Message Body')).toBe(true);
                done();
            });
    });

    it('should return data power error for GetClientDetailsV3', function (done) {
        var fakeGetClientsDetailsV3Request = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/GetClientsDetailsV3/getClientsDetailsV3ResponseDataPower.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var getClientsDetailsV3Stub = proxyquire('../soap/GetClientsDetailsV3/getClientsDetailsV3.js', {
            'request': fakeGetClientsDetailsV3Request
        });

        var route = proxyquire('../routes/authrep.js', {
            '../soap/GetClientsDetailsV3/getClientsDetailsV3.js': getClientsDetailsV3Stub

        });

        this.app.use(route);

        this.app.use(function (req, res, next) {
            var err = new Error('InvalidUri or InvalidHttpVerb');
            err.status = 400;
            next(err);
        });

        // production error handler
        // sends empty body and 500 error
        this.app.use(function (err, req, res, next) {
            if (req && req.log) {
                req.log.error(err);
            } else {
                log.error(err);
            }
            res.status(err.status || 500);
            res.json({
                'msg': err.message
            });
            next(err);
        });

        request(this.app)
            .get('/QTKBTF448')
            .set('x-nm-login-id', 'NIM1795')
            .set('X-NM-USER-TYPE', 'C')
            .set('Cookie', 'X_NM_CLIENT_CONTEXT={"worksForLoginId": "","worksForNmUniqueId": ""}')
            .expect(200)
            .end(function (err, res) {
                expect(res.text.includes('Incoming message has token type')).toBe(true);
                done();
            });
    });

    it('should return soap fault exception for ExecuteRegistrationRulesV5', function (done) {
        var fakeExecuteRegistrationRulesV5Request = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5SoapFault.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var executeRegistrationRulesV5Stub = proxyquire('../soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5.js', {
            'request': fakeExecuteRegistrationRulesV5Request
        });

        var fakeGetClientsDetailsV3Request = function (soapOptions, callback) {
            var fakeRes = fs.readFileSync('soap/GetClientsDetailsV3/getClientDetailsV3ResponsePass2.xml');
            return callback(null, fakeRes, fakeRes);
        };

        var getClientsDetailsV3Stub = proxyquire('../soap/GetClientsDetailsV3/getClientsDetailsV3.js', {
            'request': fakeGetClientsDetailsV3Request
        });

        var route = proxyquire('../routes/authrep.js', {
            '../soap/GetClientsDetailsV3/getClientsDetailsV3.js': getClientsDetailsV3Stub,
            '../soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5.js': executeRegistrationRulesV5Stub
        });

        this.app.use(route);

        this.app.use(function (req, res, next) {
            var err = new Error('InvalidUri or InvalidHttpVerb');
            err.status = 400;
            next(err);
        });

        // production error handler
        // sends empty body and 500 error

        request(this.app)
            .get('/QTKBTF448')
            .set('x-nm-login-id', 'NIM1795')
            .set('X-NM-USER-TYPE', 'C')
            .set('Cookie', 'X_NM_CLIENT_CONTEXT={"worksForLoginId": "","worksForNmUniqueId": ""}')
            .expect(200)
            .end(function (err, res) {
                expect(res.text.includes('N KLREG05001 LEGAL_ENTITY_ID NOT FOUND')).toBe(true);
                done();
            });
    });
});
