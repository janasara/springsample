'use strict';
var fs = require('fs');

exports.getSecrets = function () {
    var genericID;
    var genericPass;
    if (process.env.KUBERNETES_SERVICE_HOST) {
        try {
            genericID = fs.readFileSync('/var/run/secrets/kubernetes.io/nmhub/id', 'utf8');
            genericPass = fs.readFileSync('/var/run/secrets/kubernetes.io/nmhub/password', 'utf8');
        } catch (err) {
            var error;
            if (err.code === 'ENOENT') {
                error = new Error('Service is running inside kube cluster, but nmhub credentials are not found.', err);
                error.code = 'ENOENT';
                throw (error);
            } else {
                error = new Error('Service is running inside kube cluster, but an unknown error occured', err);
                error.code = 'UNKNOWN_ERR';
                throw (error);
            }
        }
    } else if (process.platform === 'darwin') {
        try {
            // this code may appear useless since these variable remain undefined
            // but it's here so that the developer can easily change these values for debugging
            genericID = fs.readFileSync('/tmp/nmhubuser', 'utf8');
            genericPass = fs.readFileSync('/tmp/nmhubpass', 'utf8');
        } catch (err) {
            console.log('local credentials were not found, skipping...');
            //throw (err);
        }
    }

    var credentials = {
        'genericID': genericID,
        'genericPass': genericPass
    };
    return credentials;
};
