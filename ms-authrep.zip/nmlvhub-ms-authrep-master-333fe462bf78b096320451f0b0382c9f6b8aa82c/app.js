'use strict';
var express = require('express');

var health = require('./routes/health');
var doc = require('./routes/doc');
var authrep = require('./routes/authrep');
var log = require('nmlvhub-node-logger');
var basePath = '/api/v1/authrep';
var app = express();
var memwatch = require('memwatch-next');
var authrep = require('./routes/authrep');
var newrelic = require('newrelic');

//Disable per IRM
app.disable('x-powered-by');

memwatch.on('leak', function (info) {
    log.warn(info, 'Memory leak was detected');
});

// Logging incoming request
app.use(function (req, res, next) {
    req.log = log.child({
        requestPath: req.url,
        environment: process.env.NODE_APP_INSTANCE || process.env.NODE_ENV,
        correlationId: req.headers['x-nmlvhub-corid'],
        httpVerb: req.method,
        params: req.params,
        headers: req.headers
    });
    req.log.info('Request received');
    next();
});

// Health check route used to validate service is up and healthly

app.use(function (req, res, next) {
    var start = Date.now();
    res.on('finish', function () {
        var duration = Date.now() - start;
        req.log.info('Service Response Time: ' + duration);
    });
    next();
});

app.use(function (req, res, next) {
    newrelic.addCustomParameter('nmUniqueId', req.headers['x-nm-nm_uid'] || 'no_user');
    newrelic.addCustomParameter('employeeType', req.headers['x-nm-user-type'] || 'no_user_type');
    next();
});

app.use(basePath + '/health', health);
app.use(basePath + '/doc', doc);
app.use(basePath + '/', authrep);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('InvalidUri or InvalidHttpVerb');
    err.status = 400;
    next(err);
});

// production error handler
// sends empty body and 500 error
app.use(function (err, req, res, next) {
    if (req && req.log) {
        req.log.error(err);
    } else {
        log.error(err);
    }
    res.status(err.status || 500);
    res.json({
        'msg': err.message
    });
    next(err);
});

module.exports = app;
