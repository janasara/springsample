'use strict';
var fs = require('fs');
var request = require('request');
var config = require('config');
var showCAPReqRes = config.get('showCAPReqRes').enabled;
var serviceConfig = config.get('executeRegistrationRulesV5');
var _ = require('lodash');
var XmlStream = require('xml-stream');
var Stream = require('stream');
var Readable = Stream.Readable;
var pd = require('pretty-data').pd;
var secrets = require(__dirname + '/../../utilities/getsecrets.js');
var executeRegistrationRulesV5Request = fs.readFileSync('soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5Request.xml', {
    'encoding': 'utf8'
});
var executeRegistrationRulesV5RequestTemplate = _.template(executeRegistrationRulesV5Request);
var executeRegistrationRulesV5RequestDP = fs.readFileSync('soap/ExecuteRegistrationRulesV5/executeRegistrationRulesV5RequestDP.xml', {
    'encoding': 'utf8'
});
var executeRegistrationRulesV5RequestDPTemplate = _.template(executeRegistrationRulesV5RequestDP);

function executeRegistrationRulesV5Details(body, log, callback) {
    var stream = new Readable();
    let dataPowerErr;
    let providerErr;

    stream.push(body);
    stream.push(null);
    var xml = new XmlStream(stream);

    //TODO: Need to check for other type of errors also
    //Provider Faults
    xml.collect('soapenv:Fault');
    xml.on('endElement: SOAP-ENV:Fault', function (executeRegistrationRulesV5Exception) {
        var providerErr = checkSoapFaultMessages(executeRegistrationRulesV5Exception, log)
        return callback(new Error(providerErr));
    })

    //DP Faults
    xml.collect('env:Body');
    xml.on('endElement: env:Fault', function (dataPowerException) {
        dataPowerErr = checkDataPowerFault(dataPowerException, log);
          return callback(new Error(dataPowerErr));
    });

    xml.collect('Registration_Rules_V5');
    //TODO: Check on whether to send back the response on "end" function
    xml.on('endElement: Registration_Rules_V5', function (item) {
        return callback(null, item);
    });
}

function checkDataPowerFault(dataPowerException, log) {
    var message = 'executeRegistrationRulesV5 completed with Datapower-originated error';
    var errObj = {
        errMsg: message,
        errDetailMsg: dataPowerException.faultcode + ' ' + dataPowerException.faultstring
    };
    log.error(errObj, message);
    return JSON.stringify(errObj);
}

function checkSoapFaultMessages(executeRegistrationRulesV5Exception, log) {
    //TODO: Handle different type of errors
    var errObj = {
        errMsg: executeRegistrationRulesV5Exception.faultstring,
        errDetailMsg: executeRegistrationRulesV5Exception.detail['ati:GeneralApplicationFault'].$text
    };
    log.error(errObj, 'executeRegistrationRulesV5 completed with provider-originated error');
    return JSON.stringify(errObj);
}

module.exports = function (userId, clientIdentityData, log, callback) {
    var header;
    if (serviceConfig.consumerID) {
        var creds = secrets.getSecrets(); //get generic id and pass

        header = executeRegistrationRulesV5RequestDPTemplate({
            address: serviceConfig.uri,
            consumerID: serviceConfig.consumerID,
            namespace: serviceConfig.namespace,
            genericIdUsername: creds.genericID,
            genericIdPassword: creds.genericPass
        });
    }

    //TEMPLATE OUT SOAP REQUEST
    var xmlRequest = executeRegistrationRulesV5RequestTemplate({
        'msgClientOperId': userId,
        'msgSenderApplId': config.appId,
        //TODO: This needs to be eventually replaced by just the NMUID
        'legalEntityId': clientIdentityData.LegalEntityId,
        'legEntIdSrcCde': clientIdentityData.LegEntIdSrcCde,
        'soapHeader': header
    });

    //HTTP REQUEST TO DATAPOWER
    var soapOptions = {
        rejectUnauthorized: false,
        uri: serviceConfig.uri,
        headers: {
            'Content-Type': 'text/xml; charset=utf-8',
            'Connection': 'keep-alive'
        },
        method: 'POST',
        body: xmlRequest.toString('utf-8')
    };
    if (showCAPReqRes) {
        log.info(pd.xml(xmlRequest + ''));
    }
    var reqStart = new Date().getTime();

    //FIRE OFF REQUEST TO DATAPOWER
    request(soapOptions, function (error, response, body) {
        var reqStop = new Date().getTime();
        log.info({
                requestResponseTime: (reqStop - reqStart)
            },
            'executeRegistrationRulesV5 completed');

        if (error) {
            return callback(error);
        }
        executeRegistrationRulesV5Details(body, log, function (error, registrationRules) {
            if (error) {
                return callback(error);
            }
            return callback(null, registrationRules);
        });
    });
};
