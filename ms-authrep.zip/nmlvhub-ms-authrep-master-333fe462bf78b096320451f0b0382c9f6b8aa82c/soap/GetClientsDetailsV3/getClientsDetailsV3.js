'use strict';
var fs = require('fs');
var request = require('request');
var config = require('config');
var showCAPReqRes = config.get('showCAPReqRes').enabled;
var serviceConfig = config.get('getClientInfoV3');
var _ = require('lodash');
var XmlStream = require('xml-stream');
var Stream = require('stream');
var Readable = Stream.Readable;
var pd = require('pretty-data').pd;
var secrets = require(__dirname + '/../../utilities/getsecrets.js');

var getClientDetailsV3Request = fs.readFileSync('soap/GetClientsDetailsV3/getClientsDetailsV3Request.xml', {
    'encoding': 'utf8'
});
var getClientDetailsV3RequestTemplate = _.template(getClientDetailsV3Request);
var getClientsDetailsV3RequestDP = fs.readFileSync('soap/GetClientsDetailsV3/getClientsDetailsV3RequestDP.xml', {
    'encoding': 'utf8'
});
var getClientsDetailsV3RequestDPTemplate = _.template(getClientsDetailsV3RequestDP);

function getLoginUsageTypeCode(body, log, callback) {

    let clientDetailsArray = [];
    let providerErr;
    let dataPowerErr;
    var stream = new Readable();
    stream.push(body);
    stream.push(null);
    var xml = new XmlStream(stream);

    //Provider Faults
    xml.collect('soapenv:Fault');
    //TODO: Need to check for other type of errors also
    xml.on('endElement: ns2:GetClientInfoV3Exception', function (getClientInfoException) {
        providerErr = checkSoapFaultMessages(getClientInfoException, log);
    });

    //DP Faults
    xml.collect('env:Body');
    xml.on('endElement: env:Fault', function (dataPowerException) {

        dataPowerErr = checkDataPowerFault(dataPowerException, log);
    });

    xml.collect('ClientIdentity');
    xml.on('endElement: LegalEntity', function (item) {
        clientDetailsArray.push(item);
    });
    xml.on('end', function () {
        if (providerErr !== undefined) {
            return callback(new Error(providerErr));
        }
        if (dataPowerErr !== undefined) {
            return callback(new Error(dataPowerErr));
        }
        return callback(null, clientDetailsArray);
    });
}

function checkDataPowerFault(dataPowerException, log) {
    var message = 'getClientsDetailsV3 completed with Datapower-originated error';
    var errObj = {
        errMsg: message,
        errDetailMsg: dataPowerException.faultcode + ' ' + dataPowerException.faultstring
    };
    log.error(errObj, message);
    return JSON.stringify(errObj);
}

function checkSoapFaultMessages(getClientInfoException, log) {
    //TODO: Handle different type of errors
    var errObj = {
        errMsg: 'getClientsDetailsV3 completed with provider-originated error',
        errDetailMsg: getClientInfoException.Message + ' ' + getClientInfoException.CauseException
    };
    log.error(errObj, 'getClientsDetailsV3 completed with provider-originated error');
    return JSON.stringify(errObj);
}

module.exports = function (nmUniqueId, userId, log, callback) {
    var header;
    if (serviceConfig.consumerID) {
        var creds = secrets.getSecrets(); //get generic id and pass

        header = getClientsDetailsV3RequestDPTemplate({
            address: serviceConfig.uri,
            consumerID: serviceConfig.consumerID,
            namespace: serviceConfig.namespace,
            genericIdUsername: creds.genericID,
            genericIdPassword: creds.genericPass
        });
    }

    //TEMPLATE OUT SOAP REQUEST
    var xmlRequest = getClientDetailsV3RequestTemplate({
        'msgClientOperId': userId,
        'msgSenderApplId': config.appId,
        'apigeeCorrId': log.fields.correlationId,
        'nmUniqueId': nmUniqueId,
        'soapHeader': header
    });

    //HTTP REQUEST TO DATAPOWER
    var soapOptions = {
        rejectUnauthorized: false,
        uri: serviceConfig.uri,
        headers: {
            'Content-Type': 'text/xml; charset=utf-8',
            'Connection': 'keep-alive'
        },
        method: 'POST',
        body: xmlRequest.toString('utf-8')
    };
    if (showCAPReqRes) {
        log.info(pd.xml(xmlRequest + ''));
    }
    var reqStart = new Date().getTime();

    //FIRE OFF REQUEST TO DATAPOWER
    request(soapOptions, function (error, response, body) {
        if (showCAPReqRes) {
            log.info(pd.xml(body + ''));
        }
        var reqStop = new Date().getTime();
        log.info({
                requestResponseTime: (reqStop - reqStart)
            },
            'getClientsDetailsV3 completed');

        if (error) {
            return callback(error);
        }
        getLoginUsageTypeCode(body, log, function (error, legalEntityData) {
            if (error) {
                return callback(error);
            }
            return callback(null, legalEntityData);
        });
    });
};
