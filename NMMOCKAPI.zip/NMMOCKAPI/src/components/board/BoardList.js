import React, { PropTypes } from 'react';
import { Link } from 'react-router';

const BoardList = ({boards}) => {
    return (
        <table className="table">
            <tbody>
                {boards.map(board =>
                    <tr key={board._id}>
                        <td><Link to={'/board/' + board._id}>{board.title}</Link></td>
                    </tr>
                )}
            </tbody>
        </table>
    );
};

BoardList.propTypes = {
    boards: PropTypes.array.isRequired
};

export default BoardList;