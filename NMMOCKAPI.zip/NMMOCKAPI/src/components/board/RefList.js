import React from 'react';


const RefList = ({noterefs,onEdit}) => { 
  return (
    <form> 
    <br></br>
    <table className="table">
            <tbody>
                {noterefs.map(noteref =>
                    <tr key={noteref.id}>
                        <td><a href={noteref.link} target="_blank">{noteref.title}</a></td>
                        <td><input type="button" id={noteref.id} className="btn btn-link" value="Edit" onClick={onEdit} /> </td>
                        
                    </tr>
                )}
            </tbody>
        </table>

    </form>
  );
};

RefList.propTypes = {
  noterefs: React.PropTypes.object.isRequired,
  onEdit: React.PropTypes.func.isRequired
 
  
};

export default RefList;
