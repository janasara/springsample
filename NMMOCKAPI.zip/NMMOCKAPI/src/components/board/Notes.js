import React from 'react';
import {connect} from 'react-redux';
import {Link} from 'react-router';

class Notes extends React.Component {
  render() {
    const {notes} = this.props;

    return (
        <table className="table">
            <tbody>
                {notes.map(note =>
                    <tr key={note._id}>
                        <td><Link to={'/note/' +note.bid +"/"+note._id}>{note.task}</Link></td>
                    </tr>
                )}
            </tbody>
        </table>
    );
  }
}

export default connect()(Notes);

