import React from 'react';
import TextInput from '../common/TextInput';


const RefForm = ({nrefer, onChange, errors, onSave, onCancel}) => {

  return (
    <form>
        <div>
          <TextInput
            name="title"
            label="Ref Title "
            value={nrefer.title}
            onChange={onChange}
            errors={errors.reftitle}
            />


          <TextInput
            name="link"
            label="Ref Link "
            value={nrefer.link}
            onChange={onChange}
            errors={errors.reflink}
            />
            <input
            type="submit"
            value='Save'
            className="btn btn-sm"
            onClick={onSave} /> &nbsp; &nbsp;
            
            <input
            type="button"
            value="Cancel"
            className="btn btn-sm"
            onClick={onCancel} />
            

        </div>


    
    </form>
  );
};

RefForm.propTypes = {
  nrefer: React.PropTypes.object.isRequired,
  onChange: React.PropTypes.func.isRequired,
  onCancel: React.PropTypes.func.isRequired,
  onSave: React.PropTypes.func.isRequired,
  errors: React.PropTypes.object  
};

export default RefForm;