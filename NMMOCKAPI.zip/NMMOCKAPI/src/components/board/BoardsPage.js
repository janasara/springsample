import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as boardActions from '../../actions/boardActions';
import BoardList from './BoardList';
import { browserHistory } from 'react-router';

class BoardsPage extends React.Component {

  constructor(props, context) {
    super(props, context);
    this.redirectToAddBoardPage = this.redirectToAddBoardPage.bind(this);

  }

  boardRow(board, index) {
    return <div key={index} > {board.title}</div>;
  }

  redirectToAddBoardPage() {
    browserHistory.push('/board');
  }
  render() {
    const {boards} = this.props;
    return (
      <div>
        <h1>Boards</h1>


        <BoardList boards={boards} />
      </div>
    );
  }

}

BoardsPage.propTypes = {
  boards: PropTypes.array.isRequired,
  actions: PropTypes.object.isRequired
};

function mapStateToProps(state) {
  return {
    boards: state.boards
  };

}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(boardActions, dispatch)
  };
}
export default connect(mapStateToProps, mapDispatchToProps)(BoardsPage);