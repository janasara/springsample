import React from 'react';


class HomePage extends React.Component {
  render() {
    return (
      <div >
        <h1>Kanban Board</h1>
        <p>Dashboard</p>

      </div>
    );
  }
}

export default HomePage;
