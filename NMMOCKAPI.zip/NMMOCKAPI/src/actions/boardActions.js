import ActionTypes from '../constants/actionTypes';
import boardApi from '../api/mockBoardApi';

export function loadBoardsSucess(boards) {
  return { type: ActionTypes.LOAD_BOARDS_SUCCESS, boards };

}

export function createBoardSuccess(board) {
  return { type: ActionTypes.CREATE_BOARD_SUCCESS, board };
}

export function updateBoardSuccess(board) {
  return { type: ActionTypes.UPDATE_BOARD_SUCCESS, board };
}

export function loadBoards() {
  return function (dispatch) {
    return boardApi.getAllboards().then(boards => {
      dispatch(loadBoardsSucess(boards));
    }).catch(error => {
      throw (error);
    });
  };
}

export function saveBoard(board) {
  return function (dispatch, getState) {

    return boardApi.saveBoard(board).then(board => {
      board._id ? dispatch(updateBoardSuccess(board)) :
        dispatch(createBoardSuccess(board));
    }).catch(error => {

      throw (error);
    });
  };
}