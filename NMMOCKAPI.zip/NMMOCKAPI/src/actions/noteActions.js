import boardApi from '../api/mockBoardApi';
import ActionTypes from '../constants/actionTypes';


export function loadNotesSuccess(notes) {
  return { type: ActionTypes.LOAD_NOTES_SUCCESS, notes };

}

export function createNoteSuccess(note) {
  return { type: ActionTypes.CREATE_NOTE_SUCCESS, note };
}

export function updateNoteSuccess(note) {
  return { type: ActionTypes.UPDATE_NOTE_SUCCESS, note };
}

export function loadNotes() {
  return function (dispatch) {
    return boardApi.getAllnotes().then(notes => {
      dispatch(loadNotesSuccess(notes));
    }).catch(error => {
      throw (error);
    });
  };
}
export function saveNote(note) {
  return function (dispatch, getState) {

    return boardApi.saveNote(note).then(note => {
      note._id ? dispatch(updateNoteSuccess(note)) :
        dispatch(createNoteSuccess(note));
    }).catch(error => {

      throw (error);
    });
  };
}




