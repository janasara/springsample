import * as types from '../actions/noteActions';
import ActionTypes from '../constants/actionTypes';

const initialState = [];

export default function notes(state = initialState, action) {
  switch (action.type) {
    
    case ActionTypes.LOAD_NOTES_SUCCESS:
            return action.notes; 
    
    case ActionTypes.CREATE_NOTE_SUCCESS:
      
      const boardId = note.bid
      const laneId = note.lid;
      const noteId = note._id;
      const boardIndex = boards.findIndex(a => a._id == boardId);
      const board = boards[boardIndex];
      const laneindex = boards[boardIndex].lanes.findIndex(a => a._id == laneId);
      const lane=boards[boardIndex].lanes[laneindex]

      return [
                ...state,
                Object.assign({}, action.note)
            ];

   
          return Object.assign({},board, Object.assign({}, lane, {
            notes: [...lane.notes, noteId]
      }));
   
    case ActionTypes.UPDATE_NOTE_SUCCESS:
    
      const uboardId = action.note.bid
      const ulaneId = action.note.lid;
      const unoteId = action.note._id;
            return [
                ...state.filter(note => note._id !== action.note._id),
                Object.assign({}, action.note)
            ];      



    default:
      return state;
  }
}
