// Set up your root reducer here...
 import { combineReducers } from 'redux';
 import boards from './boardReducer';
 
 import notes from './noteReducer';
 const rootReducer=combineReducers({
     boards,    
     notes
 });

 export default rootReducer;