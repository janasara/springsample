import ActionTypes from '../constants/actionTypes';

export default function boardReducer(state = [], action) {
    switch (action.type) {
        case ActionTypes.LOAD_BOARDS_SUCCESS:
            return action.boards;

        case ActionTypes.CREATE_BOARD_SUCCESS:
            return [
                ...state,
                Object.assign({}, action.board)
            ];

        case ActionTypes.UPDATE_BOARD_SUCCESS:
            return [
                ...state.filter(board => board._id !== action.board._id),
                Object.assign({}, action.board)
            ];

        default:
            return state;
    }

}