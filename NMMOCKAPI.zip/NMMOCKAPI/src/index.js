// Set up your application entry point here...
/*eslint-disable import/default */
import 'babel-polyfill';
import React from 'react';
import { render } from 'react-dom';
import { Router, browserHistory } from 'react-router';
import configureStore from './store/configureStore';
import { Provider } from 'react-redux';
import routes from './routes';
import { loadBoards } from './actions/boardActions';
import { loadNotes } from './actions/noteActions';

import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

const store = configureStore();

store.dispatch(loadBoards());
store.dispatch(loadNotes());


render(
    <Provider store={store}>
        <Router history={browserHistory} routes={routes} />
    </Provider>,
    document.getElementById('app')
);
