import delay from './delay';

// This file mocks a web API by working with the hard-coded data below.
// It uses setTimeout to simulate the delay of an AJAX call.
// All calls return promises.
const boards = [
  {
    _id: "App-Archa",
    title: "Leap Events ",
    lanes: [{ id: "l1", name: "Idea",  notes: ["Auto-resume", "Mainframe-to-Java"] },
    { id: "l2", name: "Started",  notes: [] },
    { id: "l3", name: "Completed", notes: ["IVR-deploy"] }
    ]

  },
  {
    _id: "App-Archb",
    title: "Tiger Team New Oreleans",
    lanes: [{ id: "l1", name: "Stage1", notes: ["Automation"] },
    { id: "l2", name: "Stage2",notes: ["Big-ticket-10"] }
    ]

  }
];


const notes = [
  { _id: "Auto-resume", task: "Auto resume", desc: "Auto resume Desc",edate:"2016-11-19T12:00:00.000Z",
   rlinks:[{id:"App-ref1",title:"App ref1",link:"http://dc.nml.com/Pages/default.aspx"},{id:"App-ref2",title:"App ref2",link:"http://wiki.nml.com/index.php?title=Interactive_Pattern"}],
    bid: "App-Archa", lid: "l1" },
  { _id: "Mainframe-to-Java", task: "Mainframe to Java", desc: "Mainframe to Java Desc",edate:"2016-11-19T12:00:00.000Z",
   rlinks:[{id:"App-ref1",title:"App ref1",link:"http://dc.nml.com/Pages/default.aspx"}],  
    bid: "App-Archa", lid: "l1" },
  { _id: "IVR-deploy", task: "IVR deploy", desc: "IVR deploy Desc",edate:"2016-11-19T12:00:00.000Z",
   rlinks:[{id:"App-ref1",title:"App ref1",link:"http://dc.nml.com/Pages/default.aspx"}],    
    bid: "App-Archa", lid: "l3" },
  { _id: "Automation", task: "Automation", desc: "Automation Desc",edate:"2016-11-19T12:00:00.000Z",
   rlinks:[{id:"App-ref1",title:"App ref1",link:"http://dc.nml.com/Pages/default.aspx"}],    
   bid: "App-Archb", lid: "l1" },
  { _id: "Big-ticket-10", task: "Big ticket 10", desc: "Big ticket 10 Desc",edate:"2016-11-19T12:00:00.000Z",
   rlinks:[{id:"App-ref1",title:"App ref1",link:"http://dc.nml.com/Pages/default.aspx"}],    
   bid: "App-Archb", lid: "l2" }

];


function replaceAll(str, find, replace) {
  return str.replace(new RegExp(find, 'g'), replace);
}

//This would be performed on the server in a real app. Just stubbing in.
const generateId = (board) => {
  return replaceAll(board.title, ' ', '-');
};

const generateNId = (note) => {
  return replaceAll(note.task, ' ', '-');
};


class BoardApi {
  static getAllboards() {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve(Object.assign([], boards));
      }, delay);
    });
  }

  static getAllnotes() {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve(Object.assign([], notes));
      }, delay);
    });
  }



  static saveBoard(board) {
  
    board = Object.assign({}, board); // to avoid manipulating object passed in.
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulate server-side validation
        //const minBoardTitleLength = 1;
        /*
        if (board.title.length < minBoardTitleLength) {
          reject(`Title must be at least ${minBoardTitleLength} characters.`);
        }
         */
        if (board._id) {
          const existingBoardIndex = boards.findIndex(a => a._id == board._id);
          boards.splice(existingBoardIndex, 1, board);
        } else {
          //Just simulating creation here.

          //Cloning so copy returned is passed by value rather than by reference.
          board._id = generateId(board);

          boards.push(board);
        }

        resolve(board);
      }, delay);
    });
  }

  static saveNote(note) {
    note = Object.assign({}, note); // to avoid manipulating object passed in.
    return new Promise((resolve, reject) => {
      {
        setTimeout(() => {
          // Simulate server-side validation
          const minNoteTitleLength = 1;
          if (note.task.length < minNoteTitleLength) {
            reject(`Title must be at least ${minNoteTitleLength} characters.`);
          }

          if (note._id) {
            const existingNoteIndex = notes.findIndex(a => a._id == note._id);
            notes.splice(existingNoteIndex, 1, note);
          } else {
            //Just simulating creation here.

            //Cloning so copy returned is passed by value rather than by reference.
            note._id = generateNId(note);

            notes.push(note);

            //generateBoardWithNote(note);


          }

          resolve(note);
        }, delay);
      }
    });
  }



  static deleteNote(noteId) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const indexOfNoteToDelete = notes.findIndex(note => {
          note._id == noteId;
        });
        notes.splice(indexOfNoteToDelete, 1);
        resolve();
      }, delay);
    });
  }
}

export default BoardApi;
