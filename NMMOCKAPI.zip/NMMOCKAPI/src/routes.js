import React from 'react';
import { Route, IndexRoute } from 'react-router';
import App from './components/App';
import HomePage from './components/home/Homepage';
import AboutPage from './components/about/Aboutpage';
import BoardsPage from './components/board/BoardsPage';
import ManageNotePage from './components/board/ManageNotePage';
import ManageBoardPage from './components/board/ManageBoardPage';

export default (
  <Route path="/" component={App}>
    <IndexRoute component={HomePage} />
    <Route path="boards" component={BoardsPage} />
    <Route path="about" component={AboutPage} />
    <Route path="board" component={ManageBoardPage} />
    <Route path="board/:id" component={ManageBoardPage} />
    <Route path="note/:bid" component={ManageNotePage} />
    <Route path="note/:bid/:id" component={ManageNotePage} />
  </Route>
);