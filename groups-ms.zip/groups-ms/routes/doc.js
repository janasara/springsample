
const express = require('express'),
    fs = require('fs'),
    swagger = JSON.parse(fs.readFileSync('swagger.json').toString()),
    router = express.Router();

/* Health check for app. */
router.get('/', (req, res) => res.json(swagger));

module.exports = router;
