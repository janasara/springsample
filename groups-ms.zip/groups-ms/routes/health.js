
const express = require('express'),
    router = express.Router(),
    os = require('os'),
    pool = require('nmlvhub-mysql-pool');

/* Health check for app. */
router.get('/', (req, res, next) => {
    pool.query({ sql: 'select @@hostname as mysqlhost', log: req.log }, (err, rows) => {
        if (err) {
            req.log.info({
                responseCode: 500
            }, 'Health check request failed');
            return next(err);
        }

        req.log.info({
            responseCode: 200
        }, 'Health check request complete');

        return res.json({
            'Node Host': os.hostname(),
            'Mysql Host': rows[0].mysqlhost,
            'Git SHA': process.env.GIT_COMMIT
        });
    });
});

module.exports = router;
