
const express = require('express'),
    async = require('async'),
    getGroupInfo = require('../utilities/getGroupInfo'),
    pool = require('nmlvhub-mysql-pool'),
    router = express.Router();

router.get('/:nmUniqueId', (req, res, callback) => {
    req.log.info('Request received');
    const nmUniqueId = [req.params.nmUniqueId];
    async.parallel([
        (next) => {
            getGroupInfo.getOrgNames(req, nmUniqueId, pool, next); // Fetch Organization Name
        },
        (next) => { // Fetch Market Group Plan Information
            getGroupInfo.getGroupPlans(req, nmUniqueId, pool, next);
        }
    ],
    (err, results) => {
        if (err) {
            callback(err, null);
        } else if (results) {
            /* (Parallel Exec)
              1. For each Market Group Plan , fetch the product level information
              2. Iterate over the product details -Execute the aggregate function
             */
            let asyncTasks = [];
            results[1].forEach((groupPlan) => {
                asyncTasks.push((next) => {
                    getGroupInfo.aggregateProducts(req, groupPlan, pool, next);
                });
            });
            async.parallel(asyncTasks,
          (error, groupDetails) => {
              if (error) {
                  callback(error, null);
              } else {
                  /* Form the JSON Object for the response*/
                  let groupPlans = [];
                  if (results[1]) {
                      results[1].map((groupPlan, index) => {
                          const groupDetail = groupDetails.find(grpDet =>
                            grpDet.mktGrpPlanId === groupPlan.mktGrpPlanId);
                          if (groupDetail) {
                              groupPlans[index] = Object.assign({}, {
                                  mktGrpPlanId: groupPlan.mktGrpPlanId,
                                  mktGrpPlanNum: groupPlan.mktGrpPlanNum,
                                  mktGrpPlanNumMasked: groupPlan.mktGrpPlanNumMasked,
                                  mktGrpPlanType: groupPlan.mktGrpPlanType,
                                  cashSurrenderValueAmount: groupDetail.netCashSurrenderValue,
                                  netDeathBenefitAmount: groupDetail.netDeathBenefitAmount,
                                  ctFundValueAmount: groupDetail.contractFundValue,
                                  costBasisValueAmount: groupDetail.netCostBasisValue,
                                  policyCount: groupDetail.policyCount
                              });
                          }
                          return groupPlans;
                      });
                  }
                  let aggsGroupDet = {
                      netDeathBenefitTotal: 0,
                      ctFundValueTotal: 0,
                      cashSurrenderValueTotal: 0,
                      costBasisValueTotal: 0
                  };
                  groupPlans.map(groupPlan => {
                      aggsGroupDet.netDeathBenefitTotal += groupPlan.netDeathBenefitAmount;
                      aggsGroupDet.ctFundValueTotal += groupPlan.ctFundValueAmount;
                      aggsGroupDet.cashSurrenderValueTotal += groupPlan.cashSurrenderValueAmount;
                      aggsGroupDet.costBasisValueTotal += groupPlan.costBasisValueAmount;
                      return aggsGroupDet;
                  });

                  res.json([{
                      companyName: results[0][0] && results[0][0].companyName,
                      entitlements: [{
                          marketPlanType: results[1][0] && results[1][0].marketPlanType,
                          groups: groupPlans,
                          netDeathBenefitTotal: aggsGroupDet.netDeathBenefitTotal,
                          ctFundValueTotal: aggsGroupDet.ctFundValueTotal,
                          cashSurrenderValueTotal: aggsGroupDet.cashSurrenderValueTotal,
                          costBasisValueTotal: aggsGroupDet.costBasisValueTotal

                      }]
                  }]);
              }
          });
        }
    });
});

router.get('/:groupId/accounts', (req, res, callback) => {
    const nmUniqueId = req.headers['x-nm-nm_uid'],
        groupId = [req.params.groupId];
    req.log.info('Request received');
    /* Fetch group detail and account details for a groupId(mgpId)*/
    async.parallel([
        (next) => { // Fetch Group info for groupId(mgpId)
            getGroupInfo.getMktGroupPlanInfo(req, groupId, pool, next);
        },
        (next) => { // Fetch all products within a market group plan
            getGroupInfo.getProducts(req, groupId, pool, next);
        },
        (next) => { // Fetch products that auth rep has access to
            getGroupInfo.getAuthRepVisibleProducts(req, nmUniqueId, pool, next);
        }
    ],
        (err, results) => {
            if (err) {
                callback(err, null);
            } else if (results) {
                /*
                 1. Fetch Group detail for mgpIdNum
                 2. Fetch account details for mgpIdNum and aggregate the amount
                 */
                let products = [],
                    aggsGroupDet = {
                        netDeathBenefitAmount: 0,
                        contractFundValue: 0,
                        netCashSurrenderValue: 0,
                        netCostBasisValue: 0
                    };
                /* Form JSON Object with product details for the response*/
                if (results[1]) {
                    results[1].map(product => {
                        aggsGroupDet.netDeathBenefitAmount += product.netDeathBenefitAmount;
                        aggsGroupDet.contractFundValue += product.ctFundValueAmount;
                        aggsGroupDet.netCashSurrenderValue += product.cashSurrenderValueAmount;
                        aggsGroupDet.netCostBasisValue += product.costBasisValueAmount;

                        /* Set isVisibleToAuthRep indicator if AuthRep
                       is entitled to view the product*/

                        product.isVisibleToAuthRep = (results[2].find((visibleProduct) =>
                      visibleProduct.accountId === product.accountId) && true) || false;

                        products.push(product);
                        return products;
                    });
                }
                res.json([{
                    marketPlanType: results[0][0] && results[0][0].marketPlanType,
                    mktGrpPlanNumMasked: results[0][0] && results[0][0].mktGrpPlanNumMasked,
                    mktGrpPlanType: results[0][0] && results[0][0].mktGrpPlanType,
                    accounts: products,
                    netDeathBenefitTotal: aggsGroupDet.netDeathBenefitAmount,
                    ctFundValueTotal: aggsGroupDet.contractFundValue,
                    cashSurrenderValueTotal: aggsGroupDet.netCashSurrenderValue,
                    costBasisValueTotal: aggsGroupDet.netCostBasisValue
                }]);
            }
        });
});

module.exports = router;
