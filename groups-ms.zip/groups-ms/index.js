'use strict';
require('newrelic');
var app = require('./app');
var https = require('https');
var http = require('http');
var nmlvLastMileCerts = require('nmlvhub-node-certs-lastmile');
var log = require('nmlvhub-node-logger');
var httpListenerPort = 80;
var httpsListenerPort = 443;

// Override default ports when running on windows or mac
if (process.platform === 'darwin' || process.platform === 'win32') {
    httpListenerPort = 8080;
    httpsListenerPort = 8443;
}

var httpServer = http.createServer(app).listen(httpListenerPort, function () {
  debugger;
    log.info('app is listening at localhost:' + httpListenerPort);
});

var httpsServer = https.createServer(nmlvLastMileCerts.apiCerts, app).listen(httpsListenerPort, function () {
    log.info('app is listening at localhost:' + httpsListenerPort);
});

process.on('SIGTERM', function () {
    httpServer.close(function () {
        log.info('SIGTERM issued...app is shutting down');
        process.exit(0);
    });
    httpsServer.close(function () {
        log.info('SIGTERM issued...app is shutting down');
        process.exit(0);
    });
});
