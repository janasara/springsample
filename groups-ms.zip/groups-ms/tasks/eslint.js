'use strict';
module.exports = function (grunt) {
    grunt.config('eslint', {
        eslint: {
            src: [
              'spec/*.js',
              'app.js',
              'routes/*.js',
              'models/*.js',
              'utilities/*.js'
            ],
            options: {
                eslintrc: './.eslintrc'
            }
        }
    });

    grunt.loadNpmTasks('gruntify-eslint');
};
