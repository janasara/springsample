'use strict';
module.exports = function (grunt) {
    grunt.config('jscs', {
        jscs: {
            src: [
                'spec/*.js',
                'app.js',
                'routes/*.js',
                'models/*.js',
                'utilities/*.js'
            ],
            options: {
                config: './.jscsrc'
            }
        }
    });

    grunt.loadNpmTasks('grunt-jscs');
};
