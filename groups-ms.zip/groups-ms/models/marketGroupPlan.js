const _ = require('lodash'),
    decryption = require('nmlvhub-util-decryption');
class MarketGroupPlan {
    constructor() { // jscs:ignore
        Object.assign(this,
            {
                marketPlanType: {},
                mktGrpPlanId: {},
                mktGrpPlanNum: {},
                mktGrpPlanNumMasked: {},
                mktGrpPlanType: {}
            });
    }
    mapSql(sqlObject, log) { // jscs:ignore
        sqlObject = _.omitBy(sqlObject, (value) => value === null || value === undefined);
        // jscs:disable requireCamelCaseOrUpperCaseIdentifiers
        Object.assign(this,
            {
                marketPlanType: sqlObject.market_pln_type_txt,
                mktGrpPlanId: sqlObject.mgp_id_num,
                mktGrpPlanNum: decryption.decrypt(sqlObject.mkt_group_plan_num, 'mkt_group_plan_num', log),
                mktGrpPlanNumMasked: decryption.decrypt(sqlObject.mask_mkt_group_plan_num, 'mask_mkt_group_plan_num', log),
                mktGrpPlanType: sqlObject.mgp_type_txt
            });
    }// jscs:enable requireCamelCaseOrUpperCaseIdentifiers
}

module.exports = MarketGroupPlan;
