const _ = require('lodash'),
    decryption = require('nmlvhub-util-decryption');

class Organization {
    constructor() { // jscs:ignore
        this.companyName = {};
    }
    mapSql(sqlObject, log) { // jscs:ignore
        sqlObject = _.omitBy(sqlObject, (value) => value === null || value === undefined);
        this.companyName = decryption.decrypt(sqlObject.orgztn_nam, 'orgztn_nam', log); // jscs:ignore requireCamelCaseOrUpperCaseIdentifiers
    }
}

module.exports = Organization;
