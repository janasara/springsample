const _ = require('lodash'),
    decryption = require('nmlvhub-util-decryption');

class Product {
    constructor() { // jscs:ignore
        Object.assign(this,
            {
                accountId: {},
                accountNumber: {},
                accountNumberMasked: {},
                clientName: {},
                policyDate: {},
                netDeathBenefitAmount: {},
                ctFundValueAmount: {},
                cashSurrenderValueAmount: {},
                costBasisValueAmount: {}
            });
    }

    mapSql(sqlObject, log) { // jscs:ignore
        sqlObject = _.omitBy(sqlObject, (value) => value === null || value === undefined);
        // jscs:disable requireCamelCaseOrUpperCaseIdentifiers
        Object.assign(this,
            {
                accountId: sqlObject.fin_prod_id_num,
                accountNumber: decryption.decrypt(sqlObject.fin_prod_num, 'fin_prod_num', log),
                accountNumberMasked: decryption.decrypt(sqlObject.mask_fin_prod_num, 'mask_fin_prod_num', log),
                clientName: sqlObject.owner_name_txt,
                policyDate: sqlObject.plcy_dte,
                netDeathBenefitAmount: sqlObject.tot_pc_value_amt,
                ctFundValueAmount: sqlObject.ct_fund_val_amt,
                cashSurrenderValueAmount: sqlObject.net_pc_sur_val_amt,
                costBasisValueAmount: sqlObject.cost_basis_val
            }
        );
        // jscs:enable requireCamelCaseOrUpperCaseIdentifiers
    }
}

module.exports = Product;
