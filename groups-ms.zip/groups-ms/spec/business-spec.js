
const request = require('supertest'),
    express = require('express'),
    proxyquire = require('proxyquire'),
    cookieParser = require('cookie-parser'),
    log = require('nmlvhub-node-logger'),
    swagger = require('../swagger.json'),
    Validator = require('swagger-model-validator'),
    validator = new Validator(),
    mockPool = require('nmlvhub-mysql-mockpool'),
    _ = require('lodash'),
    route = proxyquire('../routes/business.js', { 'nmlvhub-mysql-pool': mockPool }),
    app = express();

// For parsing cookies
app.use(cookieParser());

app.use((req, res, next) => {
    req.log = log;
    next();
});

app.use(route);

describe('business suite: test market group plan info', () => { //eslint-disable-line

    // PLACE COMMON TESTCASE SETUP HERE
    beforeEach(done => { //eslint-disable-line
        done();
    });

    // ///////////////////////////Test cases - Group Info/////////////////////////////
    it('should return group Info when one is found', done => { //eslint-disable-line
        // jscs:disable requireCamelCaseOrUpperCaseIdentifiers
        mockPool.setResult([{
            orgztn_nam: 'ABC Company',
            market_pln_type_txt: 'ulife',
            mgp_id_num: 1231456,
            mkt_group_plan_num: 'xxx00534',
            mask_mkt_group_plan_num: 'xxx917',
            mgp_type_txt: 'Key Person',
            fin_prod_id_num: 1,
            fin_prod_num: '12955186',
            mask_fin_prod_num: 'xxx00534',
            tot_pc_value_amt: 50000.00,
            ct_fund_val_amt: 50000.00,
            net_pc_sur_val_amt: 50000.00,
            cost_basis_val: 5000.00
        },
        {
            orgztn_nam: 'ABC Company',
            market_pln_type_txt: 'ulife',
            mgp_id_num: 1231456,
            mkt_group_plan_num: 'xxx00534',
            mask_mkt_group_plan_num: 'xxx917',
            mgp_type_txt: 'Key Person',
            fin_prod_id_num: 2,
            fin_prod_num: '12955186',
            mask_fin_prod_num: 'xxx00534',
            tot_pc_value_amt: 50000.00,
            ct_fund_val_amt: 50000.00,
            net_pc_sur_val_amt: 50000.00,
            cost_basis_val: 5000.00
        }]);
        // jscs:enable requireCamelCaseOrUpperCaseIdentifiers

        request(app)
              .get('/QRJBPG8CF')
              .expect('Content-Type', /json/)
              .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                // Verify result object matches query results
                expect(res.body[0].companyName).toEqual('ABC Company'); //eslint-disable-line
                expect(res.body[0].entitlements[0].marketPlanType).toEqual('ulife')  ; //eslint-disable-line
                expect(res.body[0].entitlements[0].groups[0]).toEqual({'mktGrpPlanId': 1231456, //eslint-disable-line
                    mktGrpPlanNum: 'xxx00534',
                    mktGrpPlanNumMasked: 'xxx917',
                    mktGrpPlanType: 'Key Person',
                    cashSurrenderValueAmount: 100000,
                    netDeathBenefitAmount: 100000,
                    ctFundValueAmount: 100000,
                    costBasisValueAmount: 10000,
                    policyCount: 2 });

                // Verify that all properties match swagger schema

                const requiredProps = _.cloneDeep(swagger.definitions.Group.properties),
                    validation = validator.validate(res.body, swagger.definitions.Group,
                      null, true, true);
                swagger.definitions.Group.required = _.keys(requiredProps);
                /* if (!validation.valid) {
                    console.log(validation.GetFormattedErrors());
                }*/
                expect(validation.valid).toBe(true); //eslint-disable-line
                return done();
            });
    });

    it('should return a 404 when no group is found', done  => { //eslint-disable-line
        mockPool.setResult([]);
        request(app)
            .get('/groups/QRJBPG8CF')
            .expect(404)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                expect(res.statusCode).toEqual(404); //eslint-disable-line
                return done();
            });
    });

    it('should return a 500 if a connection cannot be established',  done => { //eslint-disable-line
        mockPool.failConnection();
        request(app)
            .get('/QRJBPG8CF')
            .expect('Content-Type', /json/)
            .expect(500)
            .end(err => {
                expect(err).toBeDefined(); //eslint-disable-line
                return done();
            });
    });

    it('should return a 500 if query failed',  done => { //eslint-disable-line
        mockPool.failQuery();
        request(app)
            .get('/QRJBPG8CF')
            .expect('Content-Type', /json/)
            .expect(500)
            .end(err => {
                expect(err).toBeDefined(); //eslint-disable-line
                return done();
            });
    });

    it('should return group details when groupID is found',  done => { //eslint-disable-line
        // jscs:disable requireCamelCaseOrUpperCaseIdentifiers
        mockPool.setResult([{
            market_pln_type_txt: 'Universal Life Insurance',
            mask_mkt_group_plan_num: 'xxx00534',
            mgp_type_txt: 'Key Person',
            fin_prod_num: '12955186',
            mask_fin_prod_num: 'xxx00534',
            owner_name_txt: 'Abbott, George T',
            plcy_dte: '12/15/2004',
            tot_pc_value_amt: 50000.00,
            ct_fund_val_amt: 50000.00,
            net_pc_sur_val_amt: 50000.00,
            cost_basis_val: 5000.00,
            fin_prod_id_num: 1
        },
        {
            market_pln_type_txt: 'Universal Life Insurance',
            mask_mkt_group_plan_num: 'xxx00535',
            mgp_type_txt: 'Key Person',
            fin_prod_num: '12955187',
            mask_fin_prod_num: 'xxx00535',
            owner_name_txt: 'Abbott, George T',
            plcy_dte: '12/15/2004',
            tot_pc_value_amt: 50000.00,
            ct_fund_val_amt: 50000.00,
            net_pc_sur_val_amt: 50000.00,
            cost_basis_val: 5000.00,
            fin_prod_id_num: 2
        }
        ]);
        // jscs:enable requireCamelCaseOrUpperCaseIdentifiers
        request(app)
          .get('/94/accounts')
          .set('x-nm-nm_uid', 'QRJBPG8CF')
          .expect('Content-Type', /json/)
          .expect(200)
      .end((err, res) => {
          if (err) {
              return done(err);
          }
          /* Verify result object matches query results */
          expect(res.body).toEqual([//eslint-disable-line
              { marketPlanType: 'Universal Life Insurance',
                  mktGrpPlanNumMasked: 'xxx00534',
                  mktGrpPlanType: 'Key Person',
                  accounts: [
                      { accountId: 1,
                          accountNumber: '12955186',
                          accountNumberMasked: 'xxx00534',
                          clientName: 'Abbott, George T',
                          policyDate: '12/15/2004',
                          netDeathBenefitAmount: 50000,
                          ctFundValueAmount: 50000,
                          cashSurrenderValueAmount: 50000,
                          costBasisValueAmount: 5000,
                          isVisibleToAuthRep: true },
                      {
                          accountId: 2,
                          accountNumber: '12955187',
                          accountNumberMasked: 'xxx00535',
                          clientName: 'Abbott, George T',
                          policyDate: '12/15/2004',
                          netDeathBenefitAmount: 50000,
                          ctFundValueAmount: 50000,
                          cashSurrenderValueAmount: 50000,
                          costBasisValueAmount: 5000,
                          isVisibleToAuthRep: true

                      }],
                  netDeathBenefitTotal: 100000,
                  ctFundValueTotal: 100000,
                  cashSurrenderValueTotal: 100000,
                  costBasisValueTotal: 10000 }]);

          // Verify that all properties match swagger schema and no extra properties are present
          const requiredProps = _.cloneDeep(swagger.definitions.Account.properties),
              validation = validator.validate(res.body, swagger.definitions.Account,
                null, true, true);
          swagger.definitions.Account.required = _.keys(requiredProps);
          /* if (!validation.valid) {
              console.log(validation.GetFormattedErrors());
          }*/
          expect(validation.valid).toBe(true); //eslint-disable-line
          return done();
      });
    });

    it('should return a 404 when no account is found for a groupID', done => { //eslint-disable-line
        mockPool.setResult([]);
        request(app)
          .get('/groups/94/accounts')
          .expect(404)
      .end((err, res) => {
          if (err) {
              return done(err);
          }
          expect(res.statusCode).toEqual(404); //eslint-disable-line
          return done();
      });
    });

    it('should return a 500 if a connection cannot be established for group details',  done => { //eslint-disable-line
        mockPool.failConnection();
        request(app)
          .get('/94/accounts')
          .expect('Content-Type', /json/)
          .expect(500)
      .end(err => {
          expect(err).toBeDefined(); //eslint-disable-line
          return done();
      });
    });

    it('should return a 500 if query failed for group details', done => { //eslint-disable-line
        mockPool.failQuery();
        request(app)
          .get('/94/accounts')
          .expect('Content-Type', /json/)
          .expect(500)
      .end(err => {
          expect(err).toBeDefined(); //eslint-disable-line
          return done();
      });
    });
});

