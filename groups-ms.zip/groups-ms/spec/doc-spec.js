
const request = require('supertest'),
    express = require('express'),
    fs = require('fs'),
    swagger = JSON.parse(fs.readFileSync('swagger.json').toString()),
    app = express(),
    route = require('../routes/doc.js');
app.use(route);

describe('doc', () => { //eslint-disable-line
    it('should return the swagger doc',  done => { //eslint-disable-line
        request(app)
            .get('/')
            .expect('Content-Type', /json/)
            .expect(200)
            .end((err, res) => {
                if (err) {
                    return done(err);
                }
                expect(res.body).toEqual(swagger); //eslint-disable-line
                return done();
            });
    });
});
