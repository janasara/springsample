
const request = require('supertest'),
    proxyquire = require('proxyquire'),
    express = require('express'),
    log = require('nmlvhub-node-logger'),
    memwatch = require('memwatch-next'),
    fake = express.Router(),
    app = proxyquire('../app', {
        './routes/health': fake,
        './routes/doc': fake,
        'nmlvhub-node-logger': log
    });

fake.use('/error', (req, res, next) => {
    next(new Error('test error'));
});

fake.use((req, res) => {
    res.json({});
});

describe('the nmlvhub-ms-groups application path',  () => { //eslint-disable-line
    it('should be registered for health', done => { //eslint-disable-line
        request(app)
            .get('/api/v1/business/groups/health')
            .expect('Content-Type', /json/)
            .expect(200)
            .end(err => {
                if (err) {
                    return done(err);
                }
                return done();
            });
    });

    it('should be registered for doc', done => { //eslint-disable-line
        request(app)
            .get('/api/v1/business/groups/doc')
            .expect('Content-Type', /json/)
            .expect(200)
            .end(err => {
                if (err) {
                    return done(err);
                }
                return done();
            });
    });

    it('should set child logger on request with correlation id', done => { //eslint-disable-line
        spyOn(log, 'child').andCallThrough(); //eslint-disable-line
        request(app)
            .get('/api/v1/business/groups/health')
            .set('x-nmlvhub-corid', 'test')
            .set('host', 'testHost')
            .set('user-agent', 'superagent')
            .expect('Content-Type', /json/)
            .expect(200)
            .end(err => {
                expect(log.child).toHaveBeenCalledWith({ //eslint-disable-line
                    requestPath: '/api/v1/business/groups/health',
                    correlationId: 'test',
                    httpVerb: 'GET',
                    params: {},
                    headers: { host: 'testHost',
                        'accept-encoding': 'gzip, deflate',
                        'user-agent': 'superagent',
                        'x-nmlvhub-corid': 'test',
                        connection: 'close' }
                });
                if (err) {
                    return done(err);
                }
                return done();
            });
    });

    it('should set log memory leak', done => { //eslint-disable-line
        spyOn(log, 'warn').andCallThrough(); //eslint-disable-line
        memwatch.emit('leak', 'bad memory leak'); //eslint-disable-line
        expect(log.warn).toHaveBeenCalled(); //eslint-disable-line
        done();
    });

    it('should provide a 400 response for invalid paths', done => { //eslint-disable-line
        request(app)
            .get('/api/v1/badaddress')
            .expect(400)
            .end(err => {
                if (err) {
                    return done(err);
                }
                return done();
            });
    });

    it('should provide a 500 error when a route throws an error', done => { //eslint-disable-line
        request(app)
            .get('/api/v1/business/groups/health/error')
            .expect(500)
            .end(err => {
                if (err) {
                    return done(err);
                }
                return done();
            });
    });
});
