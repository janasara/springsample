
const request = require('supertest'),
    proxyquire = require('proxyquire'),
    express = require('express'),
    mockPool = require('nmlvhub-mysql-mockpool'),
    log = require('nmlvhub-node-logger'),
    fakeOS = {
        hostname: () => {
            return 'testOS';
        }
    },
    app = express(),
    route = proxyquire('../routes/health.js', {
        'nmlvhub-mysql-pool': mockPool,
        os: fakeOS
    });

app.use((req, res, next) => {
    req.log = log;
    next();
});

app.use(route);

process.env.GIT_COMMIT = 'A12345';

describe('business groups health', () => { //eslint-disable-line

    it('should return the mysql and node server name, and Git SHA', done=> { //eslint-disable-line

        mockPool.setResult([{ mysqlhost: 'test' }]);
        request(app)
          .get('/')
          .expect('Content-Type', /json/)
          .expect(200)
        .end((err, res) => {
            if (err) {
                return done(err);
            }
            expect(res.body['Mysql Host']).toEqual('test'); //eslint-disable-line
            expect(res.body['Node Host']).toEqual('testOS'); //eslint-disable-line
            expect(res.body['Git SHA']).toEqual('A12345'); //eslint-disable-line
            return done();
        });
    });

    it('should return a 500 if a mysql connection cannot be established', done => { //eslint-disable-line
        mockPool.failConnection();
        request(app)
            .get('/')
            .expect('Content-Type', 'text/html')
            .expect(500)
            .end((err) => {
                expect(err).toBeDefined(); //eslint-disable-line
                done();
            });
    });

    it('should return a 500 if mysql query failed', done => { //eslint-disable-line
        mockPool.failQuery();
        request(app)
            .get('/')
            .expect('Content-Type', 'text/html')
            .expect(500)
            .end((err)=> {
                expect(err).toBeDefined(); //eslint-disable-line
                done();
            });
    });
});
