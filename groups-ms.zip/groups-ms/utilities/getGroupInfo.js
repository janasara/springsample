
const Organization = require('../models/organization'),
    MarketGroupPlan = require('../models/marketGroupPlan'),
    Product = require('../models/product');

/* Function to Retrieve the Organizations viewed by the Auth Rep
 * @param req
 * @param nmUniqueId
 * @param pool
 * @param next
 */
const getOrgNames = (req, nmUniqueId, pool, next) => {
    const stmt = `select orgztn_nam
                     from biipcloud.client
                     where nm_unique_id in
                     ( select nm_unique_id
                          from  biipcloud.client_role
                          where role_type_cde = 15 and fin_prod_id_num in
                          ( select fin_prod_id_num
                               from biipcloud.client_role
                               where role_type_cde = 653 and nm_unique_id = ?))`;

    req.log.info('sql statement: ', stmt);

    pool.query({
        sql: stmt,
        values: nmUniqueId,
        log: req.log
    }, (err, rows) => {
        if (err) {
            return next(err, null);
        }

        req.log.info({
            params: nmUniqueId,
            rowsReturned: rows.length
        }, 'Organizations query completed');

        const organizations = [];
        /* For each added if in case we get multiple Orgs in Future */
        rows.forEach((row) => {
            const organization = new Organization();
            organization.mapSql(row, req.log);
            organizations.push(organization);
        });
        return next(null, organizations);
    });
};
/** Function getGroupPlans-To Retreive the Group Plan Details
 * @param req
 * @param nmUniqueId
 * @param pool
 * @param next
 */
const getGroupPlans = (req, nmUniqueId, pool, next) => {
    const stmt = `select  cmgp.market_pln_type_txt,
                            cmgp.mkt_group_plan_num,
                            cmgp.mgp_type_txt
                            from biipcloud.csv_mkt_group_plan cmgp
                            inner join biipcloud.entitlement_mgp emg
                            on  emg.mgp_id_num = cmgp.mkt_group_plan_num
                            inner join biipcloud.entitlement_rule etr
                            on etr.entitlement_num = emg.entitlement_num
                            and etr.nm_unique_id = 'QRJBPG8CF'`;
    /* const stmt = `select  cmgp.market_pln_type_txt,
                      cmgp.mgp_id_num,
                      cmgp.mkt_group_plan_num,
                      cmgp.mask_mkt_group_plan_num,
                      cmgp.mgp_type_txt
                  from biipcloud.csv_mkt_group_plan cmgp
                  inner join biipcloud.entitlement_mgp emg
                    on  emg.mgp_id_num = cmgp.mgp_id_num
                  inner join biipcloud.entitlement_rule  etr
                    on etr.entitlement_num = emg.entitlement_num
                           and etr.nm_unique_id =?`;*/

    pool.query({
        sql: stmt,
        values: nmUniqueId,
        log: req.log
    }, (err, rows) => {
        if (err) {
            return next(err, null);
        }
        req.log.info({
            params: nmUniqueId,
            rowsReturned: rows.length
        }, 'Group Plans query completed');

        const groupPlans = [];
        rows.forEach((row) => {
            const groupPlan = new MarketGroupPlan();
            groupPlan.mapSql(row, req.log);
            groupPlans.push(groupPlan);
        });

        return next(null, groupPlans);
    });
};

/** Function getMGPInfo-To Retreive the Market Group plan info based on the MGPID
 * @param req
 * @param groupId
 * @param pool
 * @param next
 */
const getMktGroupPlanInfo = (req, groupId, pool, next) => {
    /* const stmt = `select cmgp.market_pln_type_txt,
                           cmgp.mkt_group_plan_num,
                           cmgp.mask_mkt_group_plan_num,
                           cmgp.mgp_type_txt
                           from biipcloud.csv_mkt_group_plan cmgp
                           where cmgp.mgp_id_num = 20544`;*/
    const stmt = `select cmgp.market_pln_type_txt,
                          cmgp.mkt_group_plan_num,
                          cmgp.mask_mkt_group_plan_num,
                          cmgp.mgp_type_txt
                          from biipcloud.csv_mkt_group_plan cmgp
                          where cmgp.mgp_id_num = ?`;
    req.log.info('sql statement: ', stmt);
    req.log.info('sql parameters: ', groupId);

    pool.query({
        sql: stmt,
        values: groupId,
        log: req.log
    }, (err, rows) => {
        if (err) {
            return next(err, null);
        }
        req.log.info({
            params: groupId,
            rowsReturned: rows.length
        }, 'Market Group Plan detail query completed');

        const groupPlans = [];
        rows.forEach((row) => {
            const groupPlan = new MarketGroupPlan();
            groupPlan.mapSql(row, req.log);
            groupPlans.push(groupPlan);
        });
        return next(null, groupPlans);
    });
};
/**
 *
 * @param req
 * @param groupId
 * @param pool
 * @param next
 */
const getProducts = (req, groupId, pool, next) => {
    /*    const stmt = `select fin_prod_id_num,
             fin_prod_num,
             mask_fin_prod_num,
             "Abbott, George T" as owner_name_txt,
             "12/15/2004" as plcy_dte,
             50000.00 as tot_pc_value_amt,
             50000.00 as ct_fund_val_amt,
             50000.00 as net_pc_sur_val_amt,
             5000.00 as cost_basis_val
             from biipcloud.dashboard_financial_product Limit 5`;*/
    const stmt = `select dsp.fin_prod_id_num, dsp.mask_fin_prod_num,dsp.owner_name_txt,
          rp.fin_prd_anniv_dte,dsp.fin_prd_benefit_amt,
          upc.itd_prm_tx_bas_amt, upcd.itd_tot_pc_fnd_amt
          from biipcloud.dashboard_financial_product dsp
          inner join biipcloud.ulife_prod_crt upc on dsp.fin_prod_id_num = upc.fin_prod_id_num
          inner join biipcloud.risk_product rp on dsp.fin_prod_id_num = rp.fin_prod_id_num
          inner join biipcloud.ulife_prod_crt_daily upcd
          on dsp.fin_prod_id_num = upcd.fin_prod_id_num
          inner join biipcloud.csv_mgp_pc_rel cmpr on cmpr.fin_prod_id_num = dsp.fin_prod_id_num
          inner join biipcloud.load_partition lp
          on lp.partition_num = dsp.partition_num and lp.partition_num = upcd.partition_num
          where cmpr.mgp_id_num = ?
          and dsp.partition_num = (select partition_num from biipcloud.load_partition) limit 1`;

    req.log.info('sql statement: ', stmt);
    req.log.info('sql parameters: ', groupId);

    pool.query({
        sql: stmt,
        values: groupId,
        log: req.log
    }, (err, rows) => {
        if (err) {
            return next(err, null);
        }

        req.log.info({
            params: groupId,
            rowsReturned: rows.length
        }, 'Group Detail query completed');

        const products = [];

        rows.forEach((row) => {
            const product = new Product();
            product.mapSql(row, req.log);
            products.push(product);
        });
        return next(null, products);
    });
};

/**
 * @param req
 * @param nmUniqueId
 * @param pool
 * @param next
 */
const getAuthRepVisibleProducts = (req, nmUniqueId, pool, next) => {
    /*    const stmt = `select fin_prod_id_num
                      from biipcloud.dashboard_financial_product Limit 3`;*/
    const stmt = `select distinct ep.fin_prod_id_num
        from biipcloud.entitlement_rule er
        inner join biipcloud.entitlement_product ep
        on er.entitlement_num = ep.entitlement_num and er.nm_unique_id = ep.nm_unique_id
        inner join biipcloud.dashboard_financial_product as dfp on
        ep.fin_prod_id_num = dfp.fin_prod_id_num
        right outer join biipcloud.client_role as cr on
        dfp.fin_prod_id_num = cr.fin_prod_id_num
        inner join biipcloud.client as client on
        client.nm_unique_id = cr.nm_unique_id
        where er.nm_unique_id = 'A7FB1EA95'
        and dfp.partition_num = (select partition_num from biipcloud.load_partition)  limit 1`;

    req.log.info('sql statement: ', stmt);
    req.log.info('sql parameters: ', nmUniqueId);

    pool.query({
        sql: stmt,
        values: nmUniqueId,
        log: req.log
    }, (err, rows) => {
        if (err) {
            return next(err, null);
        }

        req.log.info({
            params: nmUniqueId,
            rowsReturned: rows.length
        }, 'Group Detail query completed');

        const products = [];

        rows.forEach((row) => {
            const product = new Product();
            product.mapSql(row, req.log);
            products.push(product);
        });
        return next(null, products);
    });
};
/**
 * Function for Aggregates
 * @param req
 * @param pool
 * @param groupPlan
 * @param callback
 */
const aggregateProducts = (req, groupPlan, pool, callback) => {
    getProducts(req, groupPlan.mktGrpPlanId, pool, (err, results) => {
        if (err) {
            callback(err, null);
        }
        const aggsGroupDet = {
            netDeathBenefitAmount: 0,
            contractFundValue: 0,
            netCashSurrenderValue: 0,
            netCostBasisValue: 0
        };
        results.forEach((row) => {
            aggsGroupDet.netDeathBenefitAmount += row.netDeathBenefitAmount;
            aggsGroupDet.contractFundValue += row.ctFundValueAmount;
            aggsGroupDet.netCashSurrenderValue += row.cashSurrenderValueAmount;
            aggsGroupDet.netCostBasisValue += row.costBasisValueAmount;
        });

        aggsGroupDet.mktGrpPlanId = groupPlan.mktGrpPlanId;
        aggsGroupDet.policyCount = results.length;
        callback(null, aggsGroupDet);
    });
};
module.exports = {
    getOrgNames,
    getGroupPlans,
    getMktGroupPlanInfo,
    getProducts,
    getAuthRepVisibleProducts,
    aggregateProducts
};
