
const express = require('express'),
    health = require('./routes/health'),
    doc = require('./routes/doc'),
    business = require('./routes/business'),
    log = require('nmlvhub-node-logger'),
    memwatch = require('memwatch-next'),
    newrelic = require('newrelic');
const app = express(),
    basePath = '/api/v1/business/groups';

// Disable per IRM
app.disable('x-powered-by');

memwatch.on('leak', (info) => {
    log.warn(info, 'Memory leak was detected');
});

// Logging incoming request
app.use((req, res, next) => {
    req.log = log.child({
        requestPath: req.url,
        environment: process.env.NODE_APP_INSTANCE || process.env.NODE_ENV,
        correlationId: req.headers['x-nmlvhub-corid'],
        httpVerb: req.method,
        params: req.params,
        headers: req.headers
    });
    req.log.info('Request received');
    next();
});

// Health check route used to validate service is up and healthly

app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
        const duration = Date.now() - start;
        req.log.info('Service Response Time: ' + duration);
    });
    next();
});

app.use((req, res, next) => {
    newrelic.addCustomParameter('nmUniqueId', req.headers['x-nm-nm_uid'] || 'no_user');
    newrelic.addCustomParameter('employeeType', req.headers['x-nm-user-type'] || 'no_user_type');
    next();
});

app.use(basePath + '/health', health);
app.use(basePath + '/doc', doc);
app.use(basePath + '/', business);

// catch 404 and forward to error handler
app.use((req, res, next) => {
    const err = new Error('InvalidUri or InvalidHttpVerb');
    err.status = 400;
    next(err);
});

// production error handler
// sends empty body and 500 error
app.use((err, req, res, next) => {
    if (req && req.log) {
        req.log.error(err);
    } else {
        log.error(err);
    }
    res.status(err.status || 500);
    res.json({ msg: 'test error' });
    next(err);
});

module.exports = app;
