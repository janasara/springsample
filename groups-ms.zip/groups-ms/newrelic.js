'use strict';

/* jshint ignore:start */
var fs = require('fs');

var pjson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
var environment = process.env.NODE_APP_INSTANCE || process.env.NODE_ENV;

/**
 * New Relic agent configuration.
 *
 * See lib/config.defaults.js in the agent distribution for a more complete
 * description of configuration variables and their potential values.
 */
exports.config = {

    /*jscs:disable requireCamelCaseOrUpperCaseIdentifiers*/
    agent_enabled: environment === 'int' || environment === 'qa' || environment === 'perf' || environment === 'prod',
    /**
    * Array of application names.
    */
    app_name: [`${pjson.name} [${process.env.NODE_ENV}${ process.env.NODE_APP_INSTANCE ? '-' + process.env.NODE_APP_INSTANCE : '' }]`],
    /**
    * Your New Relic license key.
    */
    license_key: '37bf12d705baa0bb40675f90d3f6080a3985f8ce',
    logging: {
        /**
        * Level at which to log. 'trace' is most useful to New Relic when diagnosing
        * issues with the agent, 'info' and higher will impose the least overhead on
        * production applications.
        */
        level: 'info'
    },
    transaction_tracer: {
        record_sql: 'obfuscated'
    },
    slow_sql: {
        enabled: true
    },
    capture_params: true
    /*jscs:enable requireCamelCaseOrUpperCaseIdentifiers*/
};
/* jshint ignore:end */
