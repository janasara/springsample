#!/bin/bash

# Build container and run it mapping ports
sudo docker build -t regt.nmlv.nml.com:5000/nmlvhub-ms-groups /vagrant
sudo docker run -d --name nodejs -p 80:80 -p 443:443 -p 8081:8080 regt.nmlv.nml.com:5000/nmlvhub-ms-groups
